<?php

define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASSWORD', 'mysql_native_password');
define('DB_DATABASE', 'touchgrassdb');
?>