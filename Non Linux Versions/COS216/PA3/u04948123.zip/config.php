<?php

define('DB_HOST', 'localhost');
define('DB_USER', 'u04948123');
define('DB_PASSWORD', 'NOUTGANBSI6PCV34ZS2OSZV3HKQSA47A');
define('DB_NAME', 'u04948123_properties');

?>