public enum Label {
    UNIVALENT,
    BIVALENT,
    CRITICAL,
    FINAL,
    INITIAL
}
