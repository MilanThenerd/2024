import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;
import java.util.concurrent.locks.ReentrantLock;

public class OptimisticSet implements Set<Integer> {
    private final Set<Integer> set;
    private final ReentrantLock lock;

    public OptimisticSet() {
        this.set = new HashSet<>();
        this.lock = new ReentrantLock();
    }

    @Override
    public boolean add(Integer item) {
        lock.lock();
        try {
            return set.add(item);
        } finally {
            lock.unlock();
        }
    }

    @Override
    public boolean contains(Object item) {
        lock.lock();
        try {
            return set.contains(item);
        } finally {
            lock.unlock();
        }
    }

    @Override
    public boolean remove(Object item) {
        lock.lock();
        try {
            return set.remove(item);
        } finally {
            lock.unlock();
        }
    }

    @Override
    public void clear() {
        lock.lock();
        try {
            set.clear();
        } finally {
            lock.unlock();
        }
    }

    @Override
    public int size() {
        lock.lock();
        try {
            return set.size();
        } finally {
            lock.unlock();
        }
    }

    @Override
    public boolean isEmpty() {
        lock.lock();
        try {
            return set.isEmpty();
        } finally {
            lock.unlock();
        }
    }

    @Override
    public Iterator<Integer> iterator() {
        lock.lock();
        try {
            return set.iterator();
        } finally {
            lock.unlock();
        }
    }

    @Override
    public Object[] toArray() {
        lock.lock();
        try {
            return set.toArray();
        } finally {
            lock.unlock();
        }
    }

    @Override
    public <T> T[] toArray(T[] a) {
        lock.lock();
        try {
            return set.toArray(a);
        } finally {
            lock.unlock();
        }
    }

    @Override
    public boolean containsAll(java.util.Collection<?> c) {
        lock.lock();
        try {
            return set.containsAll(c);
        } finally {
            lock.unlock();
        }
    }

    @Override
    public boolean addAll(java.util.Collection<? extends Integer> c) {
        lock.lock();
        try {
            return set.addAll(c);
        } finally {
            lock.unlock();
        }
    }

    @Override
    public boolean retainAll(java.util.Collection<?> c) {
        lock.lock();
        try {
            return set.retainAll(c);
        } finally {
            lock.unlock();
        }
    }

    @Override
    public boolean removeAll(java.util.Collection<?> c) {
        lock.lock();
        try {
            return set.removeAll(c);
        } finally {
            lock.unlock();
        }
    }
}
