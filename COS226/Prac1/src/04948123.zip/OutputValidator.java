
public class OutputValidator {
    private final Output output;
   

    public OutputValidator(Output output) {
        this.output = output;
    }

    public boolean validate() {
        return false;
    }

    
}