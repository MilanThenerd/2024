/****************************************************************************
** Meta object code from reading C++ file 'homepage.h'
**
** Created by: The Qt Meta Object Compiler version 68 (Qt 6.6.0)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "C:/Users/seanv/OneDrive - Mahala.Ms/Uni/COS 214/WorksOnMyMachineTeam/COS214_Project_GUI/homepage.h"
#include <QtCore/qmetatype.h>

#if __has_include(<QtCore/qtmochelpers.h>)
#include <QtCore/qtmochelpers.h>
#else
QT_BEGIN_MOC_NAMESPACE
#endif


#include <memory>

#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'homepage.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 68
#error "This file was generated using the moc from 6.6.0. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

#ifndef Q_CONSTINIT
#define Q_CONSTINIT
#endif

QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
QT_WARNING_DISABLE_GCC("-Wuseless-cast")
namespace {

#ifdef QT_MOC_HAS_STRINGDATA
struct qt_meta_stringdata_CLASSHomePageENDCLASS_t {};
static constexpr auto qt_meta_stringdata_CLASSHomePageENDCLASS = QtMocHelpers::stringData(
    "HomePage",
    "on_btnCancelBuilding_clicked",
    "",
    "on_spnBuildingEditX_valueChanged",
    "arg1",
    "on_spnBuildingEditY_valueChanged",
    "on_spnBuildingEditWidth_valueChanged",
    "on_spnBuildingEditHeight_valueChanged",
    "on_cmbBuildingColor_currentIndexChanged",
    "index",
    "on_btnBuildBuilding_clicked",
    "on_btnResFlat_clicked",
    "on_btnResTownHouse_clicked",
    "on_btnResHouse_clicked",
    "on_btnResEstate_clicked",
    "on_btnComShop_clicked",
    "on_btnComOffice_clicked",
    "on_btnComMall_clicked",
    "on_btnIndFactory_clicked",
    "on_btnIndWarehouse_clicked",
    "on_btnIndPlant_clicked",
    "on_btnLandPark_clicked",
    "on_btnLandMonument_clicked",
    "on_btnLandCCenter_clicked",
    "on_btnServHospital_clicked",
    "on_btnServEducation_clicked",
    "on_btnServSecurity_clicked",
    "on_btnServEntertainment_clicked",
    "on_btnUtilPower_clicked",
    "on_btnUtilWater_clicked",
    "on_btnUtilSewage_clicked",
    "on_btnUtilWaste_clicked",
    "on_btnBuildRoad_clicked",
    "on_btnCancelRoad_clicked",
    "on_cmbRoadOrientation_currentIndexChanged",
    "on_spnRoadEditLength_valueChanged",
    "on_spnRoadEditX_valueChanged",
    "on_spnRoadEditY_valueChanged",
    "on_btnRoadRes_clicked",
    "on_btnRoadMain_clicked",
    "on_btnRoadHighway_clicked",
    "on_btnEnactLaw_clicked"
);
#else  // !QT_MOC_HAS_STRING_DATA
struct qt_meta_stringdata_CLASSHomePageENDCLASS_t {
    uint offsetsAndSizes[84];
    char stringdata0[9];
    char stringdata1[29];
    char stringdata2[1];
    char stringdata3[33];
    char stringdata4[5];
    char stringdata5[33];
    char stringdata6[37];
    char stringdata7[38];
    char stringdata8[40];
    char stringdata9[6];
    char stringdata10[28];
    char stringdata11[22];
    char stringdata12[27];
    char stringdata13[23];
    char stringdata14[24];
    char stringdata15[22];
    char stringdata16[24];
    char stringdata17[22];
    char stringdata18[25];
    char stringdata19[27];
    char stringdata20[23];
    char stringdata21[23];
    char stringdata22[27];
    char stringdata23[26];
    char stringdata24[27];
    char stringdata25[28];
    char stringdata26[27];
    char stringdata27[32];
    char stringdata28[24];
    char stringdata29[24];
    char stringdata30[25];
    char stringdata31[24];
    char stringdata32[24];
    char stringdata33[25];
    char stringdata34[42];
    char stringdata35[34];
    char stringdata36[29];
    char stringdata37[29];
    char stringdata38[22];
    char stringdata39[23];
    char stringdata40[26];
    char stringdata41[23];
};
#define QT_MOC_LITERAL(ofs, len) \
    uint(sizeof(qt_meta_stringdata_CLASSHomePageENDCLASS_t::offsetsAndSizes) + ofs), len 
Q_CONSTINIT static const qt_meta_stringdata_CLASSHomePageENDCLASS_t qt_meta_stringdata_CLASSHomePageENDCLASS = {
    {
        QT_MOC_LITERAL(0, 8),  // "HomePage"
        QT_MOC_LITERAL(9, 28),  // "on_btnCancelBuilding_clicked"
        QT_MOC_LITERAL(38, 0),  // ""
        QT_MOC_LITERAL(39, 32),  // "on_spnBuildingEditX_valueChanged"
        QT_MOC_LITERAL(72, 4),  // "arg1"
        QT_MOC_LITERAL(77, 32),  // "on_spnBuildingEditY_valueChanged"
        QT_MOC_LITERAL(110, 36),  // "on_spnBuildingEditWidth_value..."
        QT_MOC_LITERAL(147, 37),  // "on_spnBuildingEditHeight_valu..."
        QT_MOC_LITERAL(185, 39),  // "on_cmbBuildingColor_currentIn..."
        QT_MOC_LITERAL(225, 5),  // "index"
        QT_MOC_LITERAL(231, 27),  // "on_btnBuildBuilding_clicked"
        QT_MOC_LITERAL(259, 21),  // "on_btnResFlat_clicked"
        QT_MOC_LITERAL(281, 26),  // "on_btnResTownHouse_clicked"
        QT_MOC_LITERAL(308, 22),  // "on_btnResHouse_clicked"
        QT_MOC_LITERAL(331, 23),  // "on_btnResEstate_clicked"
        QT_MOC_LITERAL(355, 21),  // "on_btnComShop_clicked"
        QT_MOC_LITERAL(377, 23),  // "on_btnComOffice_clicked"
        QT_MOC_LITERAL(401, 21),  // "on_btnComMall_clicked"
        QT_MOC_LITERAL(423, 24),  // "on_btnIndFactory_clicked"
        QT_MOC_LITERAL(448, 26),  // "on_btnIndWarehouse_clicked"
        QT_MOC_LITERAL(475, 22),  // "on_btnIndPlant_clicked"
        QT_MOC_LITERAL(498, 22),  // "on_btnLandPark_clicked"
        QT_MOC_LITERAL(521, 26),  // "on_btnLandMonument_clicked"
        QT_MOC_LITERAL(548, 25),  // "on_btnLandCCenter_clicked"
        QT_MOC_LITERAL(574, 26),  // "on_btnServHospital_clicked"
        QT_MOC_LITERAL(601, 27),  // "on_btnServEducation_clicked"
        QT_MOC_LITERAL(629, 26),  // "on_btnServSecurity_clicked"
        QT_MOC_LITERAL(656, 31),  // "on_btnServEntertainment_clicked"
        QT_MOC_LITERAL(688, 23),  // "on_btnUtilPower_clicked"
        QT_MOC_LITERAL(712, 23),  // "on_btnUtilWater_clicked"
        QT_MOC_LITERAL(736, 24),  // "on_btnUtilSewage_clicked"
        QT_MOC_LITERAL(761, 23),  // "on_btnUtilWaste_clicked"
        QT_MOC_LITERAL(785, 23),  // "on_btnBuildRoad_clicked"
        QT_MOC_LITERAL(809, 24),  // "on_btnCancelRoad_clicked"
        QT_MOC_LITERAL(834, 41),  // "on_cmbRoadOrientation_current..."
        QT_MOC_LITERAL(876, 33),  // "on_spnRoadEditLength_valueCha..."
        QT_MOC_LITERAL(910, 28),  // "on_spnRoadEditX_valueChanged"
        QT_MOC_LITERAL(939, 28),  // "on_spnRoadEditY_valueChanged"
        QT_MOC_LITERAL(968, 21),  // "on_btnRoadRes_clicked"
        QT_MOC_LITERAL(990, 22),  // "on_btnRoadMain_clicked"
        QT_MOC_LITERAL(1013, 25),  // "on_btnRoadHighway_clicked"
        QT_MOC_LITERAL(1039, 22)   // "on_btnEnactLaw_clicked"
    },
    "HomePage",
    "on_btnCancelBuilding_clicked",
    "",
    "on_spnBuildingEditX_valueChanged",
    "arg1",
    "on_spnBuildingEditY_valueChanged",
    "on_spnBuildingEditWidth_valueChanged",
    "on_spnBuildingEditHeight_valueChanged",
    "on_cmbBuildingColor_currentIndexChanged",
    "index",
    "on_btnBuildBuilding_clicked",
    "on_btnResFlat_clicked",
    "on_btnResTownHouse_clicked",
    "on_btnResHouse_clicked",
    "on_btnResEstate_clicked",
    "on_btnComShop_clicked",
    "on_btnComOffice_clicked",
    "on_btnComMall_clicked",
    "on_btnIndFactory_clicked",
    "on_btnIndWarehouse_clicked",
    "on_btnIndPlant_clicked",
    "on_btnLandPark_clicked",
    "on_btnLandMonument_clicked",
    "on_btnLandCCenter_clicked",
    "on_btnServHospital_clicked",
    "on_btnServEducation_clicked",
    "on_btnServSecurity_clicked",
    "on_btnServEntertainment_clicked",
    "on_btnUtilPower_clicked",
    "on_btnUtilWater_clicked",
    "on_btnUtilSewage_clicked",
    "on_btnUtilWaste_clicked",
    "on_btnBuildRoad_clicked",
    "on_btnCancelRoad_clicked",
    "on_cmbRoadOrientation_currentIndexChanged",
    "on_spnRoadEditLength_valueChanged",
    "on_spnRoadEditX_valueChanged",
    "on_spnRoadEditY_valueChanged",
    "on_btnRoadRes_clicked",
    "on_btnRoadMain_clicked",
    "on_btnRoadHighway_clicked",
    "on_btnEnactLaw_clicked"
};
#undef QT_MOC_LITERAL
#endif // !QT_MOC_HAS_STRING_DATA
} // unnamed namespace

Q_CONSTINIT static const uint qt_meta_data_CLASSHomePageENDCLASS[] = {

 // content:
      12,       // revision
       0,       // classname
       0,    0, // classinfo
      38,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags, initial metatype offsets
       1,    0,  242,    2, 0x08,    1 /* Private */,
       3,    1,  243,    2, 0x08,    2 /* Private */,
       5,    1,  246,    2, 0x08,    4 /* Private */,
       6,    1,  249,    2, 0x08,    6 /* Private */,
       7,    1,  252,    2, 0x08,    8 /* Private */,
       8,    1,  255,    2, 0x08,   10 /* Private */,
      10,    0,  258,    2, 0x08,   12 /* Private */,
      11,    0,  259,    2, 0x08,   13 /* Private */,
      12,    0,  260,    2, 0x08,   14 /* Private */,
      13,    0,  261,    2, 0x08,   15 /* Private */,
      14,    0,  262,    2, 0x08,   16 /* Private */,
      15,    0,  263,    2, 0x08,   17 /* Private */,
      16,    0,  264,    2, 0x08,   18 /* Private */,
      17,    0,  265,    2, 0x08,   19 /* Private */,
      18,    0,  266,    2, 0x08,   20 /* Private */,
      19,    0,  267,    2, 0x08,   21 /* Private */,
      20,    0,  268,    2, 0x08,   22 /* Private */,
      21,    0,  269,    2, 0x08,   23 /* Private */,
      22,    0,  270,    2, 0x08,   24 /* Private */,
      23,    0,  271,    2, 0x08,   25 /* Private */,
      24,    0,  272,    2, 0x08,   26 /* Private */,
      25,    0,  273,    2, 0x08,   27 /* Private */,
      26,    0,  274,    2, 0x08,   28 /* Private */,
      27,    0,  275,    2, 0x08,   29 /* Private */,
      28,    0,  276,    2, 0x08,   30 /* Private */,
      29,    0,  277,    2, 0x08,   31 /* Private */,
      30,    0,  278,    2, 0x08,   32 /* Private */,
      31,    0,  279,    2, 0x08,   33 /* Private */,
      32,    0,  280,    2, 0x08,   34 /* Private */,
      33,    0,  281,    2, 0x08,   35 /* Private */,
      34,    1,  282,    2, 0x08,   36 /* Private */,
      35,    1,  285,    2, 0x08,   38 /* Private */,
      36,    1,  288,    2, 0x08,   40 /* Private */,
      37,    1,  291,    2, 0x08,   42 /* Private */,
      38,    0,  294,    2, 0x08,   44 /* Private */,
      39,    0,  295,    2, 0x08,   45 /* Private */,
      40,    0,  296,    2, 0x08,   46 /* Private */,
      41,    0,  297,    2, 0x08,   47 /* Private */,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,    4,
    QMetaType::Void, QMetaType::Int,    4,
    QMetaType::Void, QMetaType::Int,    4,
    QMetaType::Void, QMetaType::Int,    4,
    QMetaType::Void, QMetaType::Int,    9,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,    9,
    QMetaType::Void, QMetaType::Int,    4,
    QMetaType::Void, QMetaType::Int,    4,
    QMetaType::Void, QMetaType::Int,    4,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

Q_CONSTINIT const QMetaObject HomePage::staticMetaObject = { {
    QMetaObject::SuperData::link<QMainWindow::staticMetaObject>(),
    qt_meta_stringdata_CLASSHomePageENDCLASS.offsetsAndSizes,
    qt_meta_data_CLASSHomePageENDCLASS,
    qt_static_metacall,
    nullptr,
    qt_incomplete_metaTypeArray<qt_meta_stringdata_CLASSHomePageENDCLASS_t,
        // Q_OBJECT / Q_GADGET
        QtPrivate::TypeAndForceComplete<HomePage, std::true_type>,
        // method 'on_btnCancelBuilding_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_spnBuildingEditX_valueChanged'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<int, std::false_type>,
        // method 'on_spnBuildingEditY_valueChanged'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<int, std::false_type>,
        // method 'on_spnBuildingEditWidth_valueChanged'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<int, std::false_type>,
        // method 'on_spnBuildingEditHeight_valueChanged'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<int, std::false_type>,
        // method 'on_cmbBuildingColor_currentIndexChanged'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<int, std::false_type>,
        // method 'on_btnBuildBuilding_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_btnResFlat_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_btnResTownHouse_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_btnResHouse_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_btnResEstate_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_btnComShop_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_btnComOffice_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_btnComMall_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_btnIndFactory_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_btnIndWarehouse_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_btnIndPlant_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_btnLandPark_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_btnLandMonument_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_btnLandCCenter_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_btnServHospital_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_btnServEducation_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_btnServSecurity_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_btnServEntertainment_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_btnUtilPower_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_btnUtilWater_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_btnUtilSewage_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_btnUtilWaste_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_btnBuildRoad_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_btnCancelRoad_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_cmbRoadOrientation_currentIndexChanged'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<int, std::false_type>,
        // method 'on_spnRoadEditLength_valueChanged'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<int, std::false_type>,
        // method 'on_spnRoadEditX_valueChanged'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<int, std::false_type>,
        // method 'on_spnRoadEditY_valueChanged'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<int, std::false_type>,
        // method 'on_btnRoadRes_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_btnRoadMain_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_btnRoadHighway_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_btnEnactLaw_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>
    >,
    nullptr
} };

void HomePage::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<HomePage *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->on_btnCancelBuilding_clicked(); break;
        case 1: _t->on_spnBuildingEditX_valueChanged((*reinterpret_cast< std::add_pointer_t<int>>(_a[1]))); break;
        case 2: _t->on_spnBuildingEditY_valueChanged((*reinterpret_cast< std::add_pointer_t<int>>(_a[1]))); break;
        case 3: _t->on_spnBuildingEditWidth_valueChanged((*reinterpret_cast< std::add_pointer_t<int>>(_a[1]))); break;
        case 4: _t->on_spnBuildingEditHeight_valueChanged((*reinterpret_cast< std::add_pointer_t<int>>(_a[1]))); break;
        case 5: _t->on_cmbBuildingColor_currentIndexChanged((*reinterpret_cast< std::add_pointer_t<int>>(_a[1]))); break;
        case 6: _t->on_btnBuildBuilding_clicked(); break;
        case 7: _t->on_btnResFlat_clicked(); break;
        case 8: _t->on_btnResTownHouse_clicked(); break;
        case 9: _t->on_btnResHouse_clicked(); break;
        case 10: _t->on_btnResEstate_clicked(); break;
        case 11: _t->on_btnComShop_clicked(); break;
        case 12: _t->on_btnComOffice_clicked(); break;
        case 13: _t->on_btnComMall_clicked(); break;
        case 14: _t->on_btnIndFactory_clicked(); break;
        case 15: _t->on_btnIndWarehouse_clicked(); break;
        case 16: _t->on_btnIndPlant_clicked(); break;
        case 17: _t->on_btnLandPark_clicked(); break;
        case 18: _t->on_btnLandMonument_clicked(); break;
        case 19: _t->on_btnLandCCenter_clicked(); break;
        case 20: _t->on_btnServHospital_clicked(); break;
        case 21: _t->on_btnServEducation_clicked(); break;
        case 22: _t->on_btnServSecurity_clicked(); break;
        case 23: _t->on_btnServEntertainment_clicked(); break;
        case 24: _t->on_btnUtilPower_clicked(); break;
        case 25: _t->on_btnUtilWater_clicked(); break;
        case 26: _t->on_btnUtilSewage_clicked(); break;
        case 27: _t->on_btnUtilWaste_clicked(); break;
        case 28: _t->on_btnBuildRoad_clicked(); break;
        case 29: _t->on_btnCancelRoad_clicked(); break;
        case 30: _t->on_cmbRoadOrientation_currentIndexChanged((*reinterpret_cast< std::add_pointer_t<int>>(_a[1]))); break;
        case 31: _t->on_spnRoadEditLength_valueChanged((*reinterpret_cast< std::add_pointer_t<int>>(_a[1]))); break;
        case 32: _t->on_spnRoadEditX_valueChanged((*reinterpret_cast< std::add_pointer_t<int>>(_a[1]))); break;
        case 33: _t->on_spnRoadEditY_valueChanged((*reinterpret_cast< std::add_pointer_t<int>>(_a[1]))); break;
        case 34: _t->on_btnRoadRes_clicked(); break;
        case 35: _t->on_btnRoadMain_clicked(); break;
        case 36: _t->on_btnRoadHighway_clicked(); break;
        case 37: _t->on_btnEnactLaw_clicked(); break;
        default: ;
        }
    }
}

const QMetaObject *HomePage::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *HomePage::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_CLASSHomePageENDCLASS.stringdata0))
        return static_cast<void*>(this);
    return QMainWindow::qt_metacast(_clname);
}

int HomePage::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 38)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 38;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 38)
            *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType();
        _id -= 38;
    }
    return _id;
}
QT_WARNING_POP
