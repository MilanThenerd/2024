/********************************************************************************
** Form generated from reading UI file 'homepage.ui'
**
** Created by: Qt User Interface Compiler version 6.6.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_HOMEPAGE_H
#define UI_HOMEPAGE_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QDoubleSpinBox>
#include <QtWidgets/QFrame>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QProgressBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QScrollArea>
#include <QtWidgets/QSpinBox>
#include <QtWidgets/QTabWidget>
#include <QtWidgets/QTextBrowser>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>
#include "MovingFrame.h"

QT_BEGIN_NAMESPACE

class Ui_HomePage
{
public:
    QWidget *centralwidget;
    QHBoxLayout *horizontalLayout_14;
    QVBoxLayout *verticalLayout_3;
    QFrame *frmEditRoadPos;
    QPushButton *btnCancelRoad;
    QSpinBox *spnRoadEditX;
    QLabel *label_174;
    QLabel *label_175;
    QLabel *label_176;
    QLabel *label_178;
    QSpinBox *spnRoadEditY;
    QComboBox *cmbRoadOrientation;
    QPushButton *btnBuildRoad;
    QLabel *label_177;
    QSpinBox *spnRoadEditLength;
    QFrame *frmInfo;
    QDoubleSpinBox *dspnCash;
    QProgressBar *progWater;
    QLabel *label_23;
    QLabel *label_3;
    QProgressBar *progHappiness;
    QLabel *label_2;
    QLabel *label;
    QLabel *label_22;
    QProgressBar *progElectricity;
    QSpinBox *spnPopulation;
    QLabel *label_12;
    QLabel *label_25;
    QLabel *label_26;
    QSpinBox *spnWood;
    QSpinBox *spnConcrete;
    QSpinBox *spnSteel;
    QLabel *lblTitle;
    QFrame *frmEditRoadPos_2;
    QLabel *label_179;
    QComboBox *cmbLawType;
    QLabel *label_180;
    QPushButton *btnEnactLaw;
    QFrame *frmEditBuildingPos;
    QPushButton *btnCancelBuilding;
    QPushButton *btnBuildBuilding;
    QLabel *label_14;
    QLabel *label_7;
    QLabel *label_15;
    QLabel *label_16;
    QSpinBox *spnBuildingEditX;
    QSpinBox *spnBuildingEditHeight;
    QSpinBox *spnBuildingEditY;
    QSpinBox *spnBuildingEditWidth;
    QLabel *label_17;
    QComboBox *cmbBuildingColor;
    QLabel *label_24;
    QVBoxLayout *verticalLayout_2;
    MovingFrame *scAreaMainMap;
    QTabWidget *tabBuildCity;
    QWidget *tab;
    QVBoxLayout *verticalLayout;
    QTabWidget *tabBuildBuildings;
    QWidget *tab_7;
    QHBoxLayout *horizontalLayout;
    QScrollArea *scrollArea;
    QWidget *scrollAreaWidgetContents_2;
    QHBoxLayout *horizontalLayout_2;
    QFrame *frmResFlat;
    QPushButton *btnResFlat;
    QLabel *label_4;
    QLabel *label_5;
    QSpinBox *spnResFlatWood;
    QLabel *label_13;
    QSpinBox *spnResFlatSteel;
    QLabel *label_18;
    QLabel *label_19;
    QSpinBox *spnResFlatConcrete;
    QSpinBox *spnResFlatCash;
    QLabel *label_20;
    QLabel *label_6;
    QFrame *frmResTownHouse;
    QPushButton *btnResTownHouse;
    QLabel *label_21;
    QLabel *label_27;
    QSpinBox *spnResTownHouseWood;
    QLabel *label_28;
    QSpinBox *spnResTownHouseSteel;
    QLabel *label_29;
    QLabel *label_30;
    QSpinBox *spnResTownHouseConcrete;
    QSpinBox *spnResTownHouseCash;
    QLabel *label_31;
    QLabel *label_32;
    QFrame *frmResHouse;
    QPushButton *btnResHouse;
    QLabel *label_33;
    QLabel *label_34;
    QSpinBox *spnResHouseWood;
    QLabel *label_35;
    QSpinBox *spnResHouseSteel;
    QLabel *label_36;
    QLabel *label_37;
    QSpinBox *spnResHouseConcrete;
    QSpinBox *spnResHouseCash;
    QLabel *label_38;
    QLabel *label_39;
    QFrame *frmResEstate;
    QPushButton *btnResEstate;
    QLabel *label_40;
    QLabel *label_41;
    QSpinBox *spnResEstateWood;
    QLabel *label_42;
    QSpinBox *spnResEstateSteel;
    QLabel *label_43;
    QLabel *label_44;
    QSpinBox *spnResEstateConcrete;
    QSpinBox *spnResEstateCash;
    QLabel *label_45;
    QLabel *label_46;
    QWidget *tab_8;
    QHBoxLayout *horizontalLayout_4;
    QScrollArea *scrollArea_2;
    QWidget *scrollAreaWidgetContents_3;
    QHBoxLayout *horizontalLayout_3;
    QFrame *frmComShop;
    QPushButton *btnComShop;
    QLabel *label_54;
    QLabel *label_55;
    QSpinBox *spnComShopWood;
    QLabel *label_56;
    QSpinBox *spnComShopSteel;
    QLabel *label_57;
    QLabel *label_58;
    QSpinBox *spnComShopConcrete;
    QSpinBox *spnComShopCash;
    QLabel *label_59;
    QLabel *label_60;
    QLabel *label_76;
    QFrame *frmComOffice;
    QPushButton *btnComOffice;
    QLabel *label_61;
    QLabel *label_62;
    QSpinBox *spnComOfficeWood;
    QLabel *label_63;
    QSpinBox *spnComOfficeSteel;
    QLabel *label_64;
    QLabel *label_65;
    QSpinBox *spnComOfficeConcrete;
    QSpinBox *spnComOfficeCash;
    QLabel *label_66;
    QLabel *label_67;
    QLabel *label_77;
    QFrame *frmComMall;
    QPushButton *btnComMall;
    QLabel *label_47;
    QLabel *label_48;
    QSpinBox *spnComMallWood;
    QLabel *label_49;
    QSpinBox *spnComMallSteel;
    QLabel *label_50;
    QLabel *label_51;
    QSpinBox *spnComMallConcrete;
    QSpinBox *spnComMallCash;
    QLabel *label_52;
    QLabel *label_53;
    QLabel *label_75;
    QWidget *tab_9;
    QHBoxLayout *horizontalLayout_6;
    QScrollArea *scrollArea_3;
    QWidget *scrollAreaWidgetContents_4;
    QHBoxLayout *horizontalLayout_5;
    QFrame *frmIndFactory;
    QPushButton *btnIndFactory;
    QLabel *label_68;
    QLabel *label_69;
    QSpinBox *spnIndFactoryWood;
    QLabel *label_70;
    QSpinBox *spnIndFactorySteel;
    QLabel *label_71;
    QLabel *label_72;
    QSpinBox *spnIndFactoryConcrete;
    QSpinBox *spnIndFactoryCash;
    QLabel *label_73;
    QLabel *label_74;
    QLabel *label_78;
    QFrame *frmIndWarehouse;
    QPushButton *btnIndWarehouse;
    QLabel *label_79;
    QLabel *label_80;
    QSpinBox *spnIndWarehouseWood;
    QLabel *label_81;
    QSpinBox *spnIndWarehouseSteel;
    QLabel *label_82;
    QLabel *label_83;
    QSpinBox *spnIndWarehouseConcrete;
    QSpinBox *spnIndWarehouseCash;
    QLabel *label_84;
    QLabel *label_85;
    QLabel *label_86;
    QFrame *frmIndPlant;
    QPushButton *btnIndPlant;
    QLabel *label_87;
    QLabel *label_88;
    QSpinBox *spnIndPlantWood;
    QLabel *label_89;
    QSpinBox *spnIndPlantSteel;
    QLabel *label_90;
    QLabel *label_91;
    QSpinBox *spnIndPlantConcrete;
    QSpinBox *spnIndPlantCash;
    QLabel *label_92;
    QLabel *label_93;
    QLabel *label_94;
    QWidget *tab_10;
    QHBoxLayout *horizontalLayout_9;
    QScrollArea *scrollArea_4;
    QWidget *scrollAreaWidgetContents_5;
    QHBoxLayout *horizontalLayout_7;
    QFrame *frmLandPark;
    QPushButton *btnLandPark;
    QLabel *label_95;
    QLabel *label_96;
    QSpinBox *spnLandParkWood;
    QLabel *label_97;
    QSpinBox *spnLandParkSteel;
    QLabel *label_98;
    QLabel *label_99;
    QSpinBox *spnLandParkConcrete;
    QSpinBox *spnLandParkCash;
    QLabel *label_100;
    QLabel *label_101;
    QLabel *label_102;
    QFrame *frmLandMonument;
    QPushButton *btnLandMonument;
    QLabel *label_103;
    QLabel *label_104;
    QSpinBox *spnLandMonumentWood;
    QLabel *label_105;
    QSpinBox *spnLandMonumentSteel;
    QLabel *label_106;
    QLabel *label_107;
    QSpinBox *spnLandMonumentConcrete;
    QSpinBox *spnLandMonumentCash;
    QLabel *label_108;
    QLabel *label_109;
    QLabel *label_110;
    QFrame *frmLandComCenter;
    QPushButton *btnLandCCenter;
    QLabel *label_111;
    QLabel *label_112;
    QSpinBox *spnLandCCenterWood;
    QLabel *label_113;
    QSpinBox *spnLandCCenterSteel;
    QLabel *label_114;
    QLabel *label_115;
    QSpinBox *spnLandCCenterConcrete;
    QSpinBox *spnLandCCenterCash;
    QLabel *label_116;
    QLabel *label_117;
    QLabel *label_118;
    QWidget *tab_11;
    QHBoxLayout *horizontalLayout_10;
    QScrollArea *scrollArea_5;
    QWidget *scrollAreaWidgetContents_6;
    QHBoxLayout *horizontalLayout_8;
    QFrame *frmServHospital;
    QPushButton *btnServHospital;
    QLabel *label_119;
    QLabel *label_120;
    QSpinBox *spnServHospitalWood;
    QLabel *label_121;
    QSpinBox *spnServHospitalSteel;
    QLabel *label_122;
    QLabel *label_123;
    QSpinBox *spnServHospitalConcrete;
    QSpinBox *spnServHospitalCash;
    QLabel *label_124;
    QLabel *label_152;
    QLabel *label_149;
    QLabel *label_150;
    QFrame *frmServEducation;
    QPushButton *btnServEducation;
    QLabel *label_127;
    QLabel *label_128;
    QSpinBox *spnServEducationWood;
    QLabel *label_129;
    QSpinBox *spnServEducationSteel;
    QLabel *label_130;
    QLabel *label_131;
    QSpinBox *spnServEducationConcrete;
    QSpinBox *spnServEducationCash;
    QLabel *label_132;
    QLabel *label_153;
    QLabel *label_154;
    QLabel *label_155;
    QFrame *frmServSecurity;
    QPushButton *btnServSecurity;
    QLabel *label_143;
    QLabel *label_144;
    QSpinBox *spnServSecurityWood;
    QLabel *label_145;
    QSpinBox *spnServSecuritySteel;
    QLabel *label_146;
    QLabel *label_147;
    QSpinBox *spnServSecurityConcrete;
    QSpinBox *spnServSecurityCash;
    QLabel *label_148;
    QLabel *label_156;
    QLabel *label_157;
    QLabel *label_158;
    QFrame *frmServEntertainment;
    QPushButton *btnServEntertainment;
    QLabel *label_135;
    QLabel *label_136;
    QSpinBox *spnServEntertainmentWood;
    QLabel *label_137;
    QSpinBox *spnServEntertainmentSteel;
    QLabel *label_138;
    QLabel *label_139;
    QSpinBox *spnServEntertainmentConcrete;
    QSpinBox *spnServEntertainmentCash;
    QLabel *label_140;
    QLabel *label_141;
    QLabel *label_142;
    QLabel *label_151;
    QWidget *tab_2;
    QHBoxLayout *horizontalLayout_11;
    QScrollArea *scrollArea_7;
    QWidget *scrollAreaWidgetContents_8;
    QHBoxLayout *horizontalLayout_13;
    QFrame *frmUtilPower;
    QPushButton *btnUtilPower;
    QLabel *label_162;
    QLabel *label_163;
    QSpinBox *spnUtilPowerWood;
    QLabel *label_164;
    QSpinBox *spnUtilPowerSteel;
    QLabel *label_165;
    QLabel *label_166;
    QSpinBox *spnUtilPowerConcrete;
    QSpinBox *spnUtilPowerCost;
    QLabel *label_167;
    QLabel *label_168;
    QFrame *frmUtilWater;
    QPushButton *btnUtilWater;
    QLabel *label_333;
    QLabel *label_334;
    QSpinBox *spnUtilWaterWood;
    QLabel *label_335;
    QSpinBox *spnUtilWaterSteel;
    QLabel *label_336;
    QLabel *label_337;
    QSpinBox *spnUtilWaterConcrete;
    QSpinBox *spnUtilWaterCost;
    QLabel *label_338;
    QLabel *label_339;
    QFrame *frmUtilSewage;
    QPushButton *btnUtilSewage;
    QLabel *label_319;
    QLabel *label_320;
    QSpinBox *spnUtilSewageWood;
    QLabel *label_321;
    QSpinBox *spnUtilSewageSteel;
    QLabel *label_322;
    QLabel *label_323;
    QSpinBox *spnUtilSewageConcrete;
    QSpinBox *spnUtilSewageCost;
    QLabel *label_324;
    QFrame *frmUtilWaste;
    QPushButton *btnUtilWaste;
    QLabel *label_125;
    QLabel *label_126;
    QSpinBox *spnUtilWasteWood;
    QLabel *label_133;
    QSpinBox *spnUtilWasteSteel;
    QLabel *label_134;
    QLabel *label_159;
    QSpinBox *spnUtilWasteConcrete;
    QSpinBox *spnUtilWasteCost;
    QLabel *label_160;
    QWidget *tab_5;
    QHBoxLayout *horizontalLayout_23;
    QScrollArea *scrollArea_6;
    QWidget *scrollAreaWidgetContents_7;
    QHBoxLayout *horizontalLayout_12;
    QFrame *frmRoadRes;
    QPushButton *btnRoadRes;
    QLabel *label_345;
    QLabel *label_346;
    QSpinBox *spnRoadResWood;
    QLabel *label_347;
    QSpinBox *spnRoadResSteel;
    QLabel *label_348;
    QLabel *label_349;
    QSpinBox *spnRoadResConcrete;
    QSpinBox *spnRoadResCost;
    QLabel *label_350;
    QFrame *frmRoadMain;
    QPushButton *btnRoadMain;
    QLabel *label_352;
    QLabel *label_353;
    QSpinBox *spnRoadMainWood;
    QLabel *label_354;
    QSpinBox *spnRoadMainSteel;
    QLabel *label_355;
    QLabel *label_356;
    QSpinBox *spnRoadMainConcrete;
    QSpinBox *spnRoadMainCost;
    QLabel *label_357;
    QFrame *frmRoadHighway;
    QPushButton *btnRoadHighway;
    QLabel *lblRoadHighway;
    QLabel *label_340;
    QSpinBox *spnRoadHighwayWood;
    QLabel *label_341;
    QSpinBox *spnRoadHighwaySteel;
    QLabel *label_342;
    QLabel *label_343;
    QSpinBox *spnRoadHighwayConcrete;
    QSpinBox *spnRoadHighwayCost;
    QLabel *label_344;
    QTextBrowser *tbConsoleOut;

    void setupUi(QMainWindow *HomePage)
    {
        if (HomePage->objectName().isEmpty())
            HomePage->setObjectName("HomePage");
        HomePage->resize(1926, 1141);
        HomePage->setDocumentMode(false);
        HomePage->setUnifiedTitleAndToolBarOnMac(false);
        centralwidget = new QWidget(HomePage);
        centralwidget->setObjectName("centralwidget");
        horizontalLayout_14 = new QHBoxLayout(centralwidget);
        horizontalLayout_14->setObjectName("horizontalLayout_14");
        verticalLayout_3 = new QVBoxLayout();
        verticalLayout_3->setObjectName("verticalLayout_3");
        frmEditRoadPos = new QFrame(centralwidget);
        frmEditRoadPos->setObjectName("frmEditRoadPos");
        frmEditRoadPos->setMinimumSize(QSize(271, 0));
        frmEditRoadPos->setMaximumSize(QSize(271, 16777215));
        frmEditRoadPos->setStyleSheet(QString::fromUtf8("#frmEditRoadPos {\n"
"    background-color: rgb(121, 219, 172); /* Light gray background */\n"
"    color: black; /* Default text color */\n"
"    border: 4px solid #05668D; /* Darker and thicker border */\n"
"    border-radius: 12px; /* Slightly larger rounded corners */\n"
"    padding: 8px; /* More padding for spacing */\n"
"}\n"
"\n"
"/* Button styles with enhanced borders */\n"
"QPushButton {\n"
"    background-color: #02C39A; /* Dark background for contrast */\n"
"    color: black;\n"
"    border: 2px solid #00A896; /* Thicker border around buttons */\n"
"    border-radius: 6px;\n"
"    padding: 6px;\n"
"    font-weight: bold;\n"
"}\n"
"\n"
"/* Hover and pressed states for buttons */\n"
"QPushButton:hover {\n"
"    background-color: #F0F3BD;\n"
"}\n"
"QPushButton:pressed {\n"
"    background-color: #02C39A;\n"
"}\n"
"\n"
"/* Label styles with a larger font size */\n"
"QLabel {\n"
"    color: black;\n"
"    font-size: 13px;\n"
"    font-weight: bold;\n"
"    padding: 2px;\n"
"}\n"
"/* SpinBox styling with"
                        " an enhanced border */\n"
"QSpinBox {\n"
"    background-color: #ffffff;\n"
"    border: 2px solid #028090;\n"
"    border-radius: 5px;\n"
"    padding: 3px;\n"
"}\n"
"\n"
"/* Up and down button customization */\n"
"QSpinBox::up-button, QSpinBox::down-button {\n"
"    background-color: #00A896;\n"
"    width: 12px;\n"
"    height: 12px;\n"
"}\n"
"\n"
"QSpinBox::up-arrow {\n"
"    width: 8px;\n"
"    height: 8px;\n"
"    image: url(:/images/arrow-up.png); \n"
"}\n"
"QSpinBox::down-arrow {\n"
"	width: 8px;\n"
"    height: 8px;\n"
"    image: url(:/images/arrow-down.png); \n"
"}\n"
"\n"
"/* ComboBox styling with a bolder border */\n"
"QComboBox {\n"
"    background-color: #ffffff;\n"
"    border: 2px solid #028090;\n"
"    border-radius: 5px;\n"
"    padding: 3px;\n"
"}\n"
"\n"
"QComboBox::drop-down {\n"
"    border: none;\n"
"    background-color: #00A896;\n"
"    width: 18px;\n"
"}\n"
"\n"
"QComboBox QAbstractItemView {\n"
"    background-color: #e0e0e0;\n"
"    selection-background-color: #444444;\n"
"    sele"
                        "ction-color: white;\n"
"}\n"
"\n"
"/* ComboBox popup list */\n"
"QComboBox::down-arrow {\n"
"	width: 8px;\n"
"    height: 8px;\n"
"    image: url(:/images/arrow-down.png); /* Replace with down arrow icon if needed */\n"
"}\n"
"\n"
""));
        frmEditRoadPos->setFrameShape(QFrame::StyledPanel);
        frmEditRoadPos->setFrameShadow(QFrame::Raised);
        btnCancelRoad = new QPushButton(frmEditRoadPos);
        btnCancelRoad->setObjectName("btnCancelRoad");
        btnCancelRoad->setGeometry(QRect(190, 10, 71, 31));
        spnRoadEditX = new QSpinBox(frmEditRoadPos);
        spnRoadEditX->setObjectName("spnRoadEditX");
        spnRoadEditX->setGeometry(QRect(150, 250, 61, 25));
        spnRoadEditX->setButtonSymbols(QAbstractSpinBox::UpDownArrows);
        spnRoadEditX->setMaximum(1616);
        label_174 = new QLabel(frmEditRoadPos);
        label_174->setObjectName("label_174");
        label_174->setGeometry(QRect(60, 180, 141, 31));
        label_175 = new QLabel(frmEditRoadPos);
        label_175->setObjectName("label_175");
        label_175->setGeometry(QRect(40, 310, 61, 21));
        label_175->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignVCenter);
        label_176 = new QLabel(frmEditRoadPos);
        label_176->setObjectName("label_176");
        label_176->setGeometry(QRect(40, 340, 81, 21));
        label_178 = new QLabel(frmEditRoadPos);
        label_178->setObjectName("label_178");
        label_178->setGeometry(QRect(40, 280, 81, 21));
        spnRoadEditY = new QSpinBox(frmEditRoadPos);
        spnRoadEditY->setObjectName("spnRoadEditY");
        spnRoadEditY->setGeometry(QRect(150, 280, 61, 25));
        spnRoadEditY->setButtonSymbols(QAbstractSpinBox::UpDownArrows);
        spnRoadEditY->setMaximum(1056);
        cmbRoadOrientation = new QComboBox(frmEditRoadPos);
        cmbRoadOrientation->addItem(QString());
        cmbRoadOrientation->addItem(QString());
        cmbRoadOrientation->setObjectName("cmbRoadOrientation");
        cmbRoadOrientation->setGeometry(QRect(150, 340, 72, 24));
        btnBuildRoad = new QPushButton(frmEditRoadPos);
        btnBuildRoad->setObjectName("btnBuildRoad");
        btnBuildRoad->setGeometry(QRect(105, 390, 60, 31));
        label_177 = new QLabel(frmEditRoadPos);
        label_177->setObjectName("label_177");
        label_177->setGeometry(QRect(40, 250, 81, 21));
        spnRoadEditLength = new QSpinBox(frmEditRoadPos);
        spnRoadEditLength->setObjectName("spnRoadEditLength");
        spnRoadEditLength->setGeometry(QRect(150, 310, 61, 25));
        spnRoadEditLength->setButtonSymbols(QAbstractSpinBox::UpDownArrows);
        spnRoadEditLength->setMinimum(50);
        spnRoadEditLength->setMaximum(1056);
        spnRoadEditLength->setValue(120);

        verticalLayout_3->addWidget(frmEditRoadPos);

        frmInfo = new QFrame(centralwidget);
        frmInfo->setObjectName("frmInfo");
        frmInfo->setMinimumSize(QSize(271, 0));
        frmInfo->setMaximumSize(QSize(271, 16777215));
        frmInfo->setStyleSheet(QString::fromUtf8("\n"
"QSpinBox:disabled{\n"
"	background-color: rgb(255, 255, 255);\n"
"	color: black;\n"
"}\n"
"\n"
"QDoubleSpinBox:disabled{\n"
"	background-color: rgb(255, 255, 255);\n"
"	color: black;\n"
"}\n"
"\n"
"#frmInfo{\n"
"	background-color: rgb(255, 255, 255);\n"
"}\n"
""));
        frmInfo->setFrameShape(QFrame::StyledPanel);
        frmInfo->setFrameShadow(QFrame::Raised);
        dspnCash = new QDoubleSpinBox(frmInfo);
        dspnCash->setObjectName("dspnCash");
        dspnCash->setEnabled(false);
        dspnCash->setGeometry(QRect(120, 100, 91, 25));
        dspnCash->setButtonSymbols(QAbstractSpinBox::NoButtons);
        dspnCash->setDecimals(0);
        dspnCash->setMaximum(99999999.000000000000000);
        progWater = new QProgressBar(frmInfo);
        progWater->setObjectName("progWater");
        progWater->setGeometry(QRect(120, 260, 118, 23));
        progWater->setValue(50);
        label_23 = new QLabel(frmInfo);
        label_23->setObjectName("label_23");
        label_23->setGeometry(QRect(10, 260, 101, 16));
        label_3 = new QLabel(frmInfo);
        label_3->setObjectName("label_3");
        label_3->setGeometry(QRect(10, 290, 101, 16));
        progHappiness = new QProgressBar(frmInfo);
        progHappiness->setObjectName("progHappiness");
        progHappiness->setGeometry(QRect(120, 290, 118, 23));
        progHappiness->setValue(100);
        label_2 = new QLabel(frmInfo);
        label_2->setObjectName("label_2");
        label_2->setGeometry(QRect(10, 320, 61, 16));
        label = new QLabel(frmInfo);
        label->setObjectName("label");
        label->setGeometry(QRect(10, 100, 49, 16));
        label_22 = new QLabel(frmInfo);
        label_22->setObjectName("label_22");
        label_22->setGeometry(QRect(10, 230, 101, 16));
        progElectricity = new QProgressBar(frmInfo);
        progElectricity->setObjectName("progElectricity");
        progElectricity->setGeometry(QRect(120, 230, 118, 23));
        progElectricity->setValue(50);
        spnPopulation = new QSpinBox(frmInfo);
        spnPopulation->setObjectName("spnPopulation");
        spnPopulation->setEnabled(false);
        spnPopulation->setGeometry(QRect(120, 320, 91, 25));
        spnPopulation->setButtonSymbols(QAbstractSpinBox::NoButtons);
        label_12 = new QLabel(frmInfo);
        label_12->setObjectName("label_12");
        label_12->setGeometry(QRect(10, 190, 101, 16));
        label_25 = new QLabel(frmInfo);
        label_25->setObjectName("label_25");
        label_25->setGeometry(QRect(10, 160, 101, 16));
        label_26 = new QLabel(frmInfo);
        label_26->setObjectName("label_26");
        label_26->setGeometry(QRect(10, 130, 101, 16));
        spnWood = new QSpinBox(frmInfo);
        spnWood->setObjectName("spnWood");
        spnWood->setEnabled(false);
        spnWood->setGeometry(QRect(120, 130, 91, 25));
        spnWood->setButtonSymbols(QAbstractSpinBox::NoButtons);
        spnWood->setMaximum(99999999);
        spnConcrete = new QSpinBox(frmInfo);
        spnConcrete->setObjectName("spnConcrete");
        spnConcrete->setEnabled(false);
        spnConcrete->setGeometry(QRect(120, 160, 91, 25));
        spnConcrete->setButtonSymbols(QAbstractSpinBox::NoButtons);
        spnConcrete->setMaximum(99999999);
        spnSteel = new QSpinBox(frmInfo);
        spnSteel->setObjectName("spnSteel");
        spnSteel->setEnabled(false);
        spnSteel->setGeometry(QRect(120, 190, 91, 25));
        spnSteel->setButtonSymbols(QAbstractSpinBox::NoButtons);
        spnSteel->setMaximum(99999999);
        lblTitle = new QLabel(frmInfo);
        lblTitle->setObjectName("lblTitle");
        lblTitle->setGeometry(QRect(0, 40, 270, 41));
        QFont font;
        font.setFamilies({QString::fromUtf8("NSimSun")});
        font.setPointSize(26);
        lblTitle->setFont(font);
        lblTitle->setStyleSheet(QString::fromUtf8("color: rgb(0, 157, 255)"));
        lblTitle->setAlignment(Qt::AlignCenter);
        frmEditRoadPos_2 = new QFrame(frmInfo);
        frmEditRoadPos_2->setObjectName("frmEditRoadPos_2");
        frmEditRoadPos_2->setGeometry(QRect(5, 390, 260, 181));
        frmEditRoadPos_2->setMinimumSize(QSize(260, 0));
        frmEditRoadPos_2->setMaximumSize(QSize(260, 16777215));
        frmEditRoadPos_2->setStyleSheet(QString::fromUtf8("#frmEditRoadPos_2 {\n"
"    background-color: rgb(121, 219, 172); /* Light gray background */\n"
"    color: black; /* Default text color */\n"
"    border: 4px solid #05668D; /* Darker and thicker border */\n"
"    border-radius: 12px; /* Slightly larger rounded corners */\n"
"    padding: 8px; /* More padding for spacing */\n"
"}\n"
"\n"
"/* Button styles with enhanced borders */\n"
"QPushButton {\n"
"    background-color: #02C39A; /* Dark background for contrast */\n"
"    color: black;\n"
"    border: 2px solid #00A896; /* Thicker border around buttons */\n"
"    border-radius: 6px;\n"
"    padding: 6px;\n"
"    font-weight: bold;\n"
"}\n"
"\n"
"/* Hover and pressed states for buttons */\n"
"QPushButton:hover {\n"
"    background-color: #F0F3BD;\n"
"}\n"
"QPushButton:pressed {\n"
"    background-color: #02C39A;\n"
"}\n"
"\n"
"/* Label styles with a larger font size */\n"
"QLabel {\n"
"    color: black;\n"
"    font-size: 13px;\n"
"    font-weight: bold;\n"
"    padding: 2px;\n"
"}\n"
"/* SpinBox styling wi"
                        "th an enhanced border */\n"
"QSpinBox {\n"
"    background-color: #ffffff;\n"
"    border: 2px solid #028090;\n"
"    border-radius: 5px;\n"
"    padding: 3px;\n"
"}\n"
"\n"
"/* Up and down button customization */\n"
"QSpinBox::up-button, QSpinBox::down-button {\n"
"    background-color: #00A896;\n"
"    width: 12px;\n"
"    height: 12px;\n"
"}\n"
"\n"
"QSpinBox::up-arrow {\n"
"    width: 8px;\n"
"    height: 8px;\n"
"    image: url(:/images/arrow-up.png); \n"
"}\n"
"QSpinBox::down-arrow {\n"
"	width: 8px;\n"
"    height: 8px;\n"
"    image: url(:/images/arrow-down.png); \n"
"}\n"
"\n"
"/* ComboBox styling with a bolder border */\n"
"QComboBox {\n"
"    background-color: #ffffff;\n"
"    border: 2px solid #028090;\n"
"    border-radius: 5px;\n"
"    padding: 3px;\n"
"}\n"
"\n"
"QComboBox::drop-down {\n"
"    border: none;\n"
"    background-color: #00A896;\n"
"    width: 18px;\n"
"}\n"
"\n"
"QComboBox QAbstractItemView {\n"
"    background-color: #e0e0e0;\n"
"    selection-background-color: #444444;\n"
"    se"
                        "lection-color: white;\n"
"}\n"
"\n"
"/* ComboBox popup list */\n"
"QComboBox::down-arrow {\n"
"	width: 8px;\n"
"    height: 8px;\n"
"    image: url(:/images/arrow-down.png); /* Replace with down arrow icon if needed */\n"
"}\n"
"\n"
""));
        frmEditRoadPos_2->setFrameShape(QFrame::StyledPanel);
        frmEditRoadPos_2->setFrameShadow(QFrame::Raised);
        label_179 = new QLabel(frmEditRoadPos_2);
        label_179->setObjectName("label_179");
        label_179->setGeometry(QRect(90, 10, 91, 31));
        cmbLawType = new QComboBox(frmEditRoadPos_2);
        cmbLawType->addItem(QString());
        cmbLawType->addItem(QString());
        cmbLawType->addItem(QString());
        cmbLawType->addItem(QString());
        cmbLawType->addItem(QString());
        cmbLawType->setObjectName("cmbLawType");
        cmbLawType->setGeometry(QRect(50, 80, 160, 24));
        label_180 = new QLabel(frmEditRoadPos_2);
        label_180->setObjectName("label_180");
        label_180->setGeometry(QRect(110, 50, 51, 31));
        btnEnactLaw = new QPushButton(frmEditRoadPos_2);
        btnEnactLaw->setObjectName("btnEnactLaw");
        btnEnactLaw->setGeometry(QRect(95, 120, 70, 41));

        verticalLayout_3->addWidget(frmInfo);

        frmEditBuildingPos = new QFrame(centralwidget);
        frmEditBuildingPos->setObjectName("frmEditBuildingPos");
        frmEditBuildingPos->setMinimumSize(QSize(271, 0));
        frmEditBuildingPos->setMaximumSize(QSize(271, 16777215));
        frmEditBuildingPos->setStyleSheet(QString::fromUtf8("#frmEditBuildingPos {\n"
"    background-color: rgb(121, 219, 172); /* Light gray background */\n"
"    color: black; /* Default text color */\n"
"    border: 4px solid #05668D; /* Darker and thicker border */\n"
"    border-radius: 12px; /* Slightly larger rounded corners */\n"
"    padding: 8px; /* More padding for spacing */\n"
"}\n"
"\n"
"/* Button styles with enhanced borders */\n"
"QPushButton {\n"
"    background-color: #02C39A; /* Dark background for contrast */\n"
"    color: black;\n"
"    border: 2px solid #00A896; /* Thicker border around buttons */\n"
"    border-radius: 6px;\n"
"    padding: 6px;\n"
"    font-weight: bold;\n"
"}\n"
"\n"
"/* Hover and pressed states for buttons */\n"
"QPushButton:hover {\n"
"    background-color: #F0F3BD;\n"
"}\n"
"QPushButton:pressed {\n"
"    background-color: #02C39A;\n"
"}\n"
"\n"
"/* Label styles with a larger font size */\n"
"QLabel {\n"
"    color: black;\n"
"    font-size: 13px;\n"
"    font-weight: bold;\n"
"    padding: 2px;\n"
"}\n"
"/* SpinBox styling "
                        "with an enhanced border */\n"
"QSpinBox {\n"
"    background-color: #ffffff;\n"
"    border: 2px solid #028090;\n"
"    border-radius: 5px;\n"
"    padding: 3px;\n"
"}\n"
"\n"
"/* Up and down button customization */\n"
"QSpinBox::up-button, QSpinBox::down-button {\n"
"    background-color: #00A896;\n"
"    width: 12px;\n"
"    height: 12px;\n"
"}\n"
"\n"
"QSpinBox::up-arrow {\n"
"    width: 8px;\n"
"    height: 8px;\n"
"    image: url(:/images/arrow-up.png); \n"
"}\n"
"QSpinBox::down-arrow {\n"
"	width: 8px;\n"
"    height: 8px;\n"
"    image: url(:/images/arrow-down.png); \n"
"}\n"
"\n"
"/* ComboBox styling with a bolder border */\n"
"QComboBox {\n"
"    background-color: #ffffff;\n"
"    border: 2px solid #028090;\n"
"    border-radius: 5px;\n"
"    padding: 3px;\n"
"}\n"
"\n"
"QComboBox::drop-down {\n"
"    border: none;\n"
"    background-color: #00A896;\n"
"    width: 18px;\n"
"}\n"
"\n"
"QComboBox QAbstractItemView {\n"
"    background-color: #e0e0e0;\n"
"    selection-background-color: #444444;\n"
"    "
                        "selection-color: white;\n"
"}\n"
"\n"
"/* ComboBox popup list */\n"
"QComboBox::down-arrow {\n"
"	width: 8px;\n"
"    height: 8px;\n"
"    image: url(:/images/arrow-down.png); /* Replace with down arrow icon if needed */\n"
"}"));
        frmEditBuildingPos->setFrameShape(QFrame::StyledPanel);
        frmEditBuildingPos->setFrameShadow(QFrame::Raised);
        btnCancelBuilding = new QPushButton(frmEditBuildingPos);
        btnCancelBuilding->setObjectName("btnCancelBuilding");
        btnCancelBuilding->setGeometry(QRect(190, 10, 71, 31));
        btnBuildBuilding = new QPushButton(frmEditBuildingPos);
        btnBuildBuilding->setObjectName("btnBuildBuilding");
        btnBuildBuilding->setGeometry(QRect(105, 440, 60, 31));
        label_14 = new QLabel(frmEditBuildingPos);
        label_14->setObjectName("label_14");
        label_14->setGeometry(QRect(40, 210, 71, 16));
        label_7 = new QLabel(frmEditBuildingPos);
        label_7->setObjectName("label_7");
        label_7->setGeometry(QRect(40, 380, 101, 21));
        label_15 = new QLabel(frmEditBuildingPos);
        label_15->setObjectName("label_15");
        label_15->setGeometry(QRect(40, 250, 71, 16));
        label_16 = new QLabel(frmEditBuildingPos);
        label_16->setObjectName("label_16");
        label_16->setGeometry(QRect(60, 180, 141, 21));
        spnBuildingEditX = new QSpinBox(frmEditBuildingPos);
        spnBuildingEditX->setObjectName("spnBuildingEditX");
        spnBuildingEditX->setGeometry(QRect(150, 210, 61, 25));
        spnBuildingEditX->setButtonSymbols(QAbstractSpinBox::UpDownArrows);
        spnBuildingEditX->setMaximum(1616);
        spnBuildingEditHeight = new QSpinBox(frmEditBuildingPos);
        spnBuildingEditHeight->setObjectName("spnBuildingEditHeight");
        spnBuildingEditHeight->setGeometry(QRect(150, 330, 61, 25));
        spnBuildingEditHeight->setMinimum(35);
        spnBuildingEditHeight->setMaximum(1056);
        spnBuildingEditY = new QSpinBox(frmEditBuildingPos);
        spnBuildingEditY->setObjectName("spnBuildingEditY");
        spnBuildingEditY->setGeometry(QRect(150, 250, 61, 25));
        spnBuildingEditY->setButtonSymbols(QAbstractSpinBox::UpDownArrows);
        spnBuildingEditY->setMaximum(1056);
        spnBuildingEditWidth = new QSpinBox(frmEditBuildingPos);
        spnBuildingEditWidth->setObjectName("spnBuildingEditWidth");
        spnBuildingEditWidth->setGeometry(QRect(150, 290, 61, 25));
        spnBuildingEditWidth->setMinimum(120);
        spnBuildingEditWidth->setMaximum(1616);
        label_17 = new QLabel(frmEditBuildingPos);
        label_17->setObjectName("label_17");
        label_17->setGeometry(QRect(40, 290, 101, 16));
        cmbBuildingColor = new QComboBox(frmEditBuildingPos);
        cmbBuildingColor->addItem(QString());
        cmbBuildingColor->addItem(QString());
        cmbBuildingColor->addItem(QString());
        cmbBuildingColor->addItem(QString());
        cmbBuildingColor->addItem(QString());
        cmbBuildingColor->addItem(QString());
        cmbBuildingColor->addItem(QString());
        cmbBuildingColor->addItem(QString());
        cmbBuildingColor->addItem(QString());
        cmbBuildingColor->setObjectName("cmbBuildingColor");
        cmbBuildingColor->setGeometry(QRect(150, 380, 91, 24));
        label_24 = new QLabel(frmEditBuildingPos);
        label_24->setObjectName("label_24");
        label_24->setGeometry(QRect(40, 330, 111, 21));

        verticalLayout_3->addWidget(frmEditBuildingPos);


        horizontalLayout_14->addLayout(verticalLayout_3);

        verticalLayout_2 = new QVBoxLayout();
        verticalLayout_2->setObjectName("verticalLayout_2");
        scAreaMainMap = new MovingFrame(centralwidget);
        scAreaMainMap->setObjectName("scAreaMainMap");
        scAreaMainMap->setMinimumSize(QSize(800, 300));
        scAreaMainMap->setFrameShape(QFrame::StyledPanel);
        scAreaMainMap->setFrameShadow(QFrame::Raised);

        verticalLayout_2->addWidget(scAreaMainMap);

        tabBuildCity = new QTabWidget(centralwidget);
        tabBuildCity->setObjectName("tabBuildCity");
        tabBuildCity->setMinimumSize(QSize(0, 300));
        tabBuildCity->setMaximumSize(QSize(16777215, 300));
        tabBuildCity->setStyleSheet(QString::fromUtf8("QSpinBox:disabled{\n"
"	background-color: rgb(255, 255, 255);\n"
"	color: black;\n"
"}\n"
"\n"
"QDoubleSpinBox:disabled{\n"
"	background-color: rgb(255, 255, 255);\n"
"	color: black;\n"
"}"));
        tab = new QWidget();
        tab->setObjectName("tab");
        verticalLayout = new QVBoxLayout(tab);
        verticalLayout->setObjectName("verticalLayout");
        tabBuildBuildings = new QTabWidget(tab);
        tabBuildBuildings->setObjectName("tabBuildBuildings");
        tabBuildBuildings->setStyleSheet(QString::fromUtf8(""));
        tab_7 = new QWidget();
        tab_7->setObjectName("tab_7");
        horizontalLayout = new QHBoxLayout(tab_7);
        horizontalLayout->setObjectName("horizontalLayout");
        scrollArea = new QScrollArea(tab_7);
        scrollArea->setObjectName("scrollArea");
        scrollArea->setWidgetResizable(true);
        scrollAreaWidgetContents_2 = new QWidget();
        scrollAreaWidgetContents_2->setObjectName("scrollAreaWidgetContents_2");
        scrollAreaWidgetContents_2->setGeometry(QRect(-241, 0, 1516, 188));
        horizontalLayout_2 = new QHBoxLayout(scrollAreaWidgetContents_2);
        horizontalLayout_2->setObjectName("horizontalLayout_2");
        frmResFlat = new QFrame(scrollAreaWidgetContents_2);
        frmResFlat->setObjectName("frmResFlat");
        frmResFlat->setMinimumSize(QSize(370, 0));
        frmResFlat->setMaximumSize(QSize(370, 16777215));
        frmResFlat->setStyleSheet(QString::fromUtf8("#frmResFlat {\n"
"	background-color: rgb(211, 211, 211);\n"
"	border: 2px solid black;\n"
"}"));
        frmResFlat->setFrameShape(QFrame::StyledPanel);
        frmResFlat->setFrameShadow(QFrame::Raised);
        btnResFlat = new QPushButton(frmResFlat);
        btnResFlat->setObjectName("btnResFlat");
        btnResFlat->setGeometry(QRect(145, 135, 80, 24));
        label_4 = new QLabel(frmResFlat);
        label_4->setObjectName("label_4");
        label_4->setGeometry(QRect(10, 10, 51, 31));
        QFont font1;
        font1.setPointSize(18);
        label_4->setFont(font1);
        label_5 = new QLabel(frmResFlat);
        label_5->setObjectName("label_5");
        label_5->setGeometry(QRect(10, 50, 49, 16));
        QFont font2;
        font2.setPointSize(14);
        label_5->setFont(font2);
        spnResFlatWood = new QSpinBox(frmResFlat);
        spnResFlatWood->setObjectName("spnResFlatWood");
        spnResFlatWood->setEnabled(false);
        spnResFlatWood->setGeometry(QRect(90, 100, 71, 25));
        spnResFlatWood->setButtonSymbols(QAbstractSpinBox::NoButtons);
        spnResFlatWood->setMinimum(0);
        spnResFlatWood->setMaximum(1000000);
        label_13 = new QLabel(frmResFlat);
        label_13->setObjectName("label_13");
        label_13->setGeometry(QRect(30, 100, 49, 16));
        QFont font3;
        font3.setPointSize(12);
        label_13->setFont(font3);
        spnResFlatSteel = new QSpinBox(frmResFlat);
        spnResFlatSteel->setObjectName("spnResFlatSteel");
        spnResFlatSteel->setEnabled(false);
        spnResFlatSteel->setGeometry(QRect(250, 70, 71, 25));
        spnResFlatSteel->setButtonSymbols(QAbstractSpinBox::NoButtons);
        spnResFlatSteel->setMinimum(0);
        spnResFlatSteel->setMaximum(1000000);
        label_18 = new QLabel(frmResFlat);
        label_18->setObjectName("label_18");
        label_18->setGeometry(QRect(180, 70, 49, 16));
        label_18->setFont(font3);
        label_19 = new QLabel(frmResFlat);
        label_19->setObjectName("label_19");
        label_19->setGeometry(QRect(180, 100, 71, 16));
        label_19->setFont(font3);
        spnResFlatConcrete = new QSpinBox(frmResFlat);
        spnResFlatConcrete->setObjectName("spnResFlatConcrete");
        spnResFlatConcrete->setEnabled(false);
        spnResFlatConcrete->setGeometry(QRect(250, 100, 71, 25));
        spnResFlatConcrete->setButtonSymbols(QAbstractSpinBox::NoButtons);
        spnResFlatConcrete->setMinimum(0);
        spnResFlatConcrete->setMaximum(1000000);
        spnResFlatCash = new QSpinBox(frmResFlat);
        spnResFlatCash->setObjectName("spnResFlatCash");
        spnResFlatCash->setEnabled(false);
        spnResFlatCash->setGeometry(QRect(90, 70, 71, 25));
        spnResFlatCash->setButtonSymbols(QAbstractSpinBox::NoButtons);
        spnResFlatCash->setMinimum(0);
        spnResFlatCash->setMaximum(1000000);
        label_20 = new QLabel(frmResFlat);
        label_20->setObjectName("label_20");
        label_20->setGeometry(QRect(30, 70, 49, 16));
        label_20->setFont(font3);
        label_6 = new QLabel(frmResFlat);
        label_6->setObjectName("label_6");
        label_6->setGeometry(QRect(230, 0, 141, 41));
        label_6->setFont(font3);

        horizontalLayout_2->addWidget(frmResFlat);

        frmResTownHouse = new QFrame(scrollAreaWidgetContents_2);
        frmResTownHouse->setObjectName("frmResTownHouse");
        frmResTownHouse->setMinimumSize(QSize(370, 0));
        frmResTownHouse->setMaximumSize(QSize(370, 16777215));
        frmResTownHouse->setStyleSheet(QString::fromUtf8("#frmResTownHouse {\n"
"	background-color: rgb(211, 211, 211);\n"
"	border: 2px solid black;\n"
"}"));
        frmResTownHouse->setFrameShape(QFrame::StyledPanel);
        frmResTownHouse->setFrameShadow(QFrame::Raised);
        btnResTownHouse = new QPushButton(frmResTownHouse);
        btnResTownHouse->setObjectName("btnResTownHouse");
        btnResTownHouse->setGeometry(QRect(145, 135, 80, 24));
        label_21 = new QLabel(frmResTownHouse);
        label_21->setObjectName("label_21");
        label_21->setGeometry(QRect(10, 10, 141, 31));
        label_21->setFont(font1);
        label_27 = new QLabel(frmResTownHouse);
        label_27->setObjectName("label_27");
        label_27->setGeometry(QRect(10, 50, 49, 16));
        label_27->setFont(font2);
        spnResTownHouseWood = new QSpinBox(frmResTownHouse);
        spnResTownHouseWood->setObjectName("spnResTownHouseWood");
        spnResTownHouseWood->setEnabled(false);
        spnResTownHouseWood->setGeometry(QRect(90, 100, 71, 25));
        spnResTownHouseWood->setButtonSymbols(QAbstractSpinBox::NoButtons);
        spnResTownHouseWood->setMinimum(0);
        spnResTownHouseWood->setMaximum(1000000);
        label_28 = new QLabel(frmResTownHouse);
        label_28->setObjectName("label_28");
        label_28->setGeometry(QRect(30, 100, 49, 16));
        label_28->setFont(font3);
        spnResTownHouseSteel = new QSpinBox(frmResTownHouse);
        spnResTownHouseSteel->setObjectName("spnResTownHouseSteel");
        spnResTownHouseSteel->setEnabled(false);
        spnResTownHouseSteel->setGeometry(QRect(250, 70, 71, 25));
        spnResTownHouseSteel->setButtonSymbols(QAbstractSpinBox::NoButtons);
        spnResTownHouseSteel->setMinimum(0);
        spnResTownHouseSteel->setMaximum(1000000);
        label_29 = new QLabel(frmResTownHouse);
        label_29->setObjectName("label_29");
        label_29->setGeometry(QRect(180, 70, 49, 16));
        label_29->setFont(font3);
        label_30 = new QLabel(frmResTownHouse);
        label_30->setObjectName("label_30");
        label_30->setGeometry(QRect(180, 100, 71, 16));
        label_30->setFont(font3);
        spnResTownHouseConcrete = new QSpinBox(frmResTownHouse);
        spnResTownHouseConcrete->setObjectName("spnResTownHouseConcrete");
        spnResTownHouseConcrete->setEnabled(false);
        spnResTownHouseConcrete->setGeometry(QRect(250, 100, 71, 25));
        spnResTownHouseConcrete->setButtonSymbols(QAbstractSpinBox::NoButtons);
        spnResTownHouseConcrete->setMinimum(0);
        spnResTownHouseConcrete->setMaximum(1000000);
        spnResTownHouseCash = new QSpinBox(frmResTownHouse);
        spnResTownHouseCash->setObjectName("spnResTownHouseCash");
        spnResTownHouseCash->setEnabled(false);
        spnResTownHouseCash->setGeometry(QRect(90, 70, 71, 25));
        spnResTownHouseCash->setButtonSymbols(QAbstractSpinBox::NoButtons);
        spnResTownHouseCash->setMinimum(0);
        spnResTownHouseCash->setMaximum(1000000);
        label_31 = new QLabel(frmResTownHouse);
        label_31->setObjectName("label_31");
        label_31->setGeometry(QRect(30, 70, 49, 16));
        label_31->setFont(font3);
        label_32 = new QLabel(frmResTownHouse);
        label_32->setObjectName("label_32");
        label_32->setGeometry(QRect(220, 0, 151, 41));
        label_32->setFont(font3);

        horizontalLayout_2->addWidget(frmResTownHouse);

        frmResHouse = new QFrame(scrollAreaWidgetContents_2);
        frmResHouse->setObjectName("frmResHouse");
        frmResHouse->setMinimumSize(QSize(370, 0));
        frmResHouse->setMaximumSize(QSize(370, 16777215));
        frmResHouse->setStyleSheet(QString::fromUtf8("#frmResHouse {\n"
"	background-color: rgb(211, 211, 211);\n"
"	border: 2px solid black;\n"
"}"));
        frmResHouse->setFrameShape(QFrame::StyledPanel);
        frmResHouse->setFrameShadow(QFrame::Raised);
        btnResHouse = new QPushButton(frmResHouse);
        btnResHouse->setObjectName("btnResHouse");
        btnResHouse->setGeometry(QRect(145, 135, 80, 24));
        label_33 = new QLabel(frmResHouse);
        label_33->setObjectName("label_33");
        label_33->setGeometry(QRect(10, 10, 141, 31));
        label_33->setFont(font1);
        label_34 = new QLabel(frmResHouse);
        label_34->setObjectName("label_34");
        label_34->setGeometry(QRect(10, 50, 49, 16));
        label_34->setFont(font2);
        spnResHouseWood = new QSpinBox(frmResHouse);
        spnResHouseWood->setObjectName("spnResHouseWood");
        spnResHouseWood->setEnabled(false);
        spnResHouseWood->setGeometry(QRect(90, 100, 71, 25));
        spnResHouseWood->setButtonSymbols(QAbstractSpinBox::NoButtons);
        spnResHouseWood->setMinimum(0);
        spnResHouseWood->setMaximum(1000000);
        label_35 = new QLabel(frmResHouse);
        label_35->setObjectName("label_35");
        label_35->setGeometry(QRect(30, 100, 49, 16));
        label_35->setFont(font3);
        spnResHouseSteel = new QSpinBox(frmResHouse);
        spnResHouseSteel->setObjectName("spnResHouseSteel");
        spnResHouseSteel->setEnabled(false);
        spnResHouseSteel->setGeometry(QRect(250, 70, 71, 25));
        spnResHouseSteel->setButtonSymbols(QAbstractSpinBox::NoButtons);
        spnResHouseSteel->setMinimum(0);
        spnResHouseSteel->setMaximum(1000000);
        label_36 = new QLabel(frmResHouse);
        label_36->setObjectName("label_36");
        label_36->setGeometry(QRect(180, 70, 49, 16));
        label_36->setFont(font3);
        label_37 = new QLabel(frmResHouse);
        label_37->setObjectName("label_37");
        label_37->setGeometry(QRect(180, 100, 71, 16));
        label_37->setFont(font3);
        spnResHouseConcrete = new QSpinBox(frmResHouse);
        spnResHouseConcrete->setObjectName("spnResHouseConcrete");
        spnResHouseConcrete->setEnabled(false);
        spnResHouseConcrete->setGeometry(QRect(250, 100, 71, 25));
        spnResHouseConcrete->setButtonSymbols(QAbstractSpinBox::NoButtons);
        spnResHouseConcrete->setMinimum(0);
        spnResHouseConcrete->setMaximum(1000000);
        spnResHouseCash = new QSpinBox(frmResHouse);
        spnResHouseCash->setObjectName("spnResHouseCash");
        spnResHouseCash->setEnabled(false);
        spnResHouseCash->setGeometry(QRect(90, 70, 71, 25));
        spnResHouseCash->setButtonSymbols(QAbstractSpinBox::NoButtons);
        spnResHouseCash->setMinimum(0);
        spnResHouseCash->setMaximum(1000000);
        label_38 = new QLabel(frmResHouse);
        label_38->setObjectName("label_38");
        label_38->setGeometry(QRect(30, 70, 49, 16));
        label_38->setFont(font3);
        label_39 = new QLabel(frmResHouse);
        label_39->setObjectName("label_39");
        label_39->setGeometry(QRect(220, 0, 151, 41));
        label_39->setFont(font3);

        horizontalLayout_2->addWidget(frmResHouse);

        frmResEstate = new QFrame(scrollAreaWidgetContents_2);
        frmResEstate->setObjectName("frmResEstate");
        frmResEstate->setMinimumSize(QSize(370, 0));
        frmResEstate->setMaximumSize(QSize(370, 16777215));
        frmResEstate->setStyleSheet(QString::fromUtf8("#frmResEstate{\n"
"	background-color: rgb(211, 211, 211);\n"
"	border: 2px solid black;\n"
"}"));
        frmResEstate->setFrameShape(QFrame::StyledPanel);
        frmResEstate->setFrameShadow(QFrame::Raised);
        btnResEstate = new QPushButton(frmResEstate);
        btnResEstate->setObjectName("btnResEstate");
        btnResEstate->setGeometry(QRect(145, 135, 80, 24));
        label_40 = new QLabel(frmResEstate);
        label_40->setObjectName("label_40");
        label_40->setGeometry(QRect(10, 10, 141, 31));
        label_40->setFont(font1);
        label_41 = new QLabel(frmResEstate);
        label_41->setObjectName("label_41");
        label_41->setGeometry(QRect(10, 50, 49, 16));
        label_41->setFont(font2);
        spnResEstateWood = new QSpinBox(frmResEstate);
        spnResEstateWood->setObjectName("spnResEstateWood");
        spnResEstateWood->setEnabled(false);
        spnResEstateWood->setGeometry(QRect(90, 100, 71, 25));
        spnResEstateWood->setButtonSymbols(QAbstractSpinBox::NoButtons);
        spnResEstateWood->setMinimum(0);
        spnResEstateWood->setMaximum(1000000);
        label_42 = new QLabel(frmResEstate);
        label_42->setObjectName("label_42");
        label_42->setGeometry(QRect(30, 100, 49, 16));
        label_42->setFont(font3);
        spnResEstateSteel = new QSpinBox(frmResEstate);
        spnResEstateSteel->setObjectName("spnResEstateSteel");
        spnResEstateSteel->setEnabled(false);
        spnResEstateSteel->setGeometry(QRect(250, 70, 71, 25));
        spnResEstateSteel->setButtonSymbols(QAbstractSpinBox::NoButtons);
        spnResEstateSteel->setMinimum(0);
        spnResEstateSteel->setMaximum(1000000);
        label_43 = new QLabel(frmResEstate);
        label_43->setObjectName("label_43");
        label_43->setGeometry(QRect(180, 70, 49, 16));
        label_43->setFont(font3);
        label_44 = new QLabel(frmResEstate);
        label_44->setObjectName("label_44");
        label_44->setGeometry(QRect(180, 100, 71, 16));
        label_44->setFont(font3);
        spnResEstateConcrete = new QSpinBox(frmResEstate);
        spnResEstateConcrete->setObjectName("spnResEstateConcrete");
        spnResEstateConcrete->setEnabled(false);
        spnResEstateConcrete->setGeometry(QRect(250, 100, 71, 25));
        spnResEstateConcrete->setButtonSymbols(QAbstractSpinBox::NoButtons);
        spnResEstateConcrete->setMinimum(0);
        spnResEstateConcrete->setMaximum(1000000);
        spnResEstateCash = new QSpinBox(frmResEstate);
        spnResEstateCash->setObjectName("spnResEstateCash");
        spnResEstateCash->setEnabled(false);
        spnResEstateCash->setGeometry(QRect(90, 70, 71, 25));
        spnResEstateCash->setButtonSymbols(QAbstractSpinBox::NoButtons);
        spnResEstateCash->setMinimum(0);
        spnResEstateCash->setMaximum(1000000);
        label_45 = new QLabel(frmResEstate);
        label_45->setObjectName("label_45");
        label_45->setGeometry(QRect(30, 70, 49, 16));
        label_45->setFont(font3);
        label_46 = new QLabel(frmResEstate);
        label_46->setObjectName("label_46");
        label_46->setGeometry(QRect(220, 0, 151, 41));
        label_46->setFont(font3);

        horizontalLayout_2->addWidget(frmResEstate);

        scrollArea->setWidget(scrollAreaWidgetContents_2);

        horizontalLayout->addWidget(scrollArea);

        tabBuildBuildings->addTab(tab_7, QString());
        tab_8 = new QWidget();
        tab_8->setObjectName("tab_8");
        horizontalLayout_4 = new QHBoxLayout(tab_8);
        horizontalLayout_4->setObjectName("horizontalLayout_4");
        scrollArea_2 = new QScrollArea(tab_8);
        scrollArea_2->setObjectName("scrollArea_2");
        scrollArea_2->setWidgetResizable(true);
        scrollAreaWidgetContents_3 = new QWidget();
        scrollAreaWidgetContents_3->setObjectName("scrollAreaWidgetContents_3");
        scrollAreaWidgetContents_3->setGeometry(QRect(0, 0, 1275, 202));
        horizontalLayout_3 = new QHBoxLayout(scrollAreaWidgetContents_3);
        horizontalLayout_3->setObjectName("horizontalLayout_3");
        frmComShop = new QFrame(scrollAreaWidgetContents_3);
        frmComShop->setObjectName("frmComShop");
        frmComShop->setMinimumSize(QSize(370, 0));
        frmComShop->setMaximumSize(QSize(370, 16777215));
        frmComShop->setStyleSheet(QString::fromUtf8("#frmComShop {\n"
"	background-color: rgb(211, 211, 211);\n"
"	border: 2px solid black;\n"
"}"));
        frmComShop->setFrameShape(QFrame::StyledPanel);
        frmComShop->setFrameShadow(QFrame::Raised);
        btnComShop = new QPushButton(frmComShop);
        btnComShop->setObjectName("btnComShop");
        btnComShop->setGeometry(QRect(145, 135, 80, 24));
        label_54 = new QLabel(frmComShop);
        label_54->setObjectName("label_54");
        label_54->setGeometry(QRect(10, 10, 71, 31));
        label_54->setFont(font1);
        label_55 = new QLabel(frmComShop);
        label_55->setObjectName("label_55");
        label_55->setGeometry(QRect(10, 50, 49, 16));
        label_55->setFont(font2);
        spnComShopWood = new QSpinBox(frmComShop);
        spnComShopWood->setObjectName("spnComShopWood");
        spnComShopWood->setEnabled(false);
        spnComShopWood->setGeometry(QRect(90, 100, 71, 25));
        spnComShopWood->setButtonSymbols(QAbstractSpinBox::NoButtons);
        spnComShopWood->setMinimum(0);
        spnComShopWood->setMaximum(1000000);
        label_56 = new QLabel(frmComShop);
        label_56->setObjectName("label_56");
        label_56->setGeometry(QRect(30, 100, 49, 16));
        label_56->setFont(font3);
        spnComShopSteel = new QSpinBox(frmComShop);
        spnComShopSteel->setObjectName("spnComShopSteel");
        spnComShopSteel->setEnabled(false);
        spnComShopSteel->setGeometry(QRect(250, 70, 71, 25));
        spnComShopSteel->setButtonSymbols(QAbstractSpinBox::NoButtons);
        spnComShopSteel->setMinimum(0);
        spnComShopSteel->setMaximum(1000000);
        label_57 = new QLabel(frmComShop);
        label_57->setObjectName("label_57");
        label_57->setGeometry(QRect(180, 70, 49, 16));
        label_57->setFont(font3);
        label_58 = new QLabel(frmComShop);
        label_58->setObjectName("label_58");
        label_58->setGeometry(QRect(180, 100, 71, 16));
        label_58->setFont(font3);
        spnComShopConcrete = new QSpinBox(frmComShop);
        spnComShopConcrete->setObjectName("spnComShopConcrete");
        spnComShopConcrete->setEnabled(false);
        spnComShopConcrete->setGeometry(QRect(250, 100, 71, 25));
        spnComShopConcrete->setButtonSymbols(QAbstractSpinBox::NoButtons);
        spnComShopConcrete->setMinimum(0);
        spnComShopConcrete->setMaximum(1000000);
        spnComShopCash = new QSpinBox(frmComShop);
        spnComShopCash->setObjectName("spnComShopCash");
        spnComShopCash->setEnabled(false);
        spnComShopCash->setGeometry(QRect(90, 70, 71, 25));
        spnComShopCash->setButtonSymbols(QAbstractSpinBox::NoButtons);
        spnComShopCash->setMinimum(0);
        spnComShopCash->setMaximum(1000000);
        label_59 = new QLabel(frmComShop);
        label_59->setObjectName("label_59");
        label_59->setGeometry(QRect(30, 70, 49, 16));
        label_59->setFont(font3);
        label_60 = new QLabel(frmComShop);
        label_60->setObjectName("label_60");
        label_60->setGeometry(QRect(300, 0, 71, 41));
        label_60->setFont(font3);
        label_76 = new QLabel(frmComShop);
        label_76->setObjectName("label_76");
        label_76->setGeometry(QRect(270, 30, 101, 41));
        label_76->setFont(font3);

        horizontalLayout_3->addWidget(frmComShop);

        frmComOffice = new QFrame(scrollAreaWidgetContents_3);
        frmComOffice->setObjectName("frmComOffice");
        frmComOffice->setMinimumSize(QSize(370, 0));
        frmComOffice->setMaximumSize(QSize(370, 16777215));
        frmComOffice->setStyleSheet(QString::fromUtf8("#frmComOffice {\n"
"	background-color: rgb(211, 211, 211);\n"
"	border: 2px solid black;\n"
"}"));
        frmComOffice->setFrameShape(QFrame::StyledPanel);
        frmComOffice->setFrameShadow(QFrame::Raised);
        btnComOffice = new QPushButton(frmComOffice);
        btnComOffice->setObjectName("btnComOffice");
        btnComOffice->setGeometry(QRect(145, 135, 80, 24));
        label_61 = new QLabel(frmComOffice);
        label_61->setObjectName("label_61");
        label_61->setGeometry(QRect(10, 10, 81, 31));
        label_61->setFont(font1);
        label_62 = new QLabel(frmComOffice);
        label_62->setObjectName("label_62");
        label_62->setGeometry(QRect(10, 50, 49, 16));
        label_62->setFont(font2);
        spnComOfficeWood = new QSpinBox(frmComOffice);
        spnComOfficeWood->setObjectName("spnComOfficeWood");
        spnComOfficeWood->setEnabled(false);
        spnComOfficeWood->setGeometry(QRect(90, 100, 71, 25));
        spnComOfficeWood->setButtonSymbols(QAbstractSpinBox::NoButtons);
        spnComOfficeWood->setMinimum(0);
        spnComOfficeWood->setMaximum(1000000);
        label_63 = new QLabel(frmComOffice);
        label_63->setObjectName("label_63");
        label_63->setGeometry(QRect(30, 100, 49, 16));
        label_63->setFont(font3);
        spnComOfficeSteel = new QSpinBox(frmComOffice);
        spnComOfficeSteel->setObjectName("spnComOfficeSteel");
        spnComOfficeSteel->setEnabled(false);
        spnComOfficeSteel->setGeometry(QRect(250, 70, 71, 25));
        spnComOfficeSteel->setButtonSymbols(QAbstractSpinBox::NoButtons);
        spnComOfficeSteel->setMinimum(0);
        spnComOfficeSteel->setMaximum(1000000);
        label_64 = new QLabel(frmComOffice);
        label_64->setObjectName("label_64");
        label_64->setGeometry(QRect(180, 70, 49, 16));
        label_64->setFont(font3);
        label_65 = new QLabel(frmComOffice);
        label_65->setObjectName("label_65");
        label_65->setGeometry(QRect(180, 100, 71, 16));
        label_65->setFont(font3);
        spnComOfficeConcrete = new QSpinBox(frmComOffice);
        spnComOfficeConcrete->setObjectName("spnComOfficeConcrete");
        spnComOfficeConcrete->setEnabled(false);
        spnComOfficeConcrete->setGeometry(QRect(250, 100, 71, 25));
        spnComOfficeConcrete->setButtonSymbols(QAbstractSpinBox::NoButtons);
        spnComOfficeConcrete->setMinimum(0);
        spnComOfficeConcrete->setMaximum(1000000);
        spnComOfficeCash = new QSpinBox(frmComOffice);
        spnComOfficeCash->setObjectName("spnComOfficeCash");
        spnComOfficeCash->setEnabled(false);
        spnComOfficeCash->setGeometry(QRect(90, 70, 71, 25));
        spnComOfficeCash->setButtonSymbols(QAbstractSpinBox::NoButtons);
        spnComOfficeCash->setMinimum(0);
        spnComOfficeCash->setMaximum(1000000);
        label_66 = new QLabel(frmComOffice);
        label_66->setObjectName("label_66");
        label_66->setGeometry(QRect(30, 70, 49, 16));
        label_66->setFont(font3);
        label_67 = new QLabel(frmComOffice);
        label_67->setObjectName("label_67");
        label_67->setGeometry(QRect(300, 0, 71, 41));
        label_67->setFont(font3);
        label_77 = new QLabel(frmComOffice);
        label_77->setObjectName("label_77");
        label_77->setGeometry(QRect(270, 30, 101, 41));
        label_77->setFont(font3);

        horizontalLayout_3->addWidget(frmComOffice);

        frmComMall = new QFrame(scrollAreaWidgetContents_3);
        frmComMall->setObjectName("frmComMall");
        frmComMall->setMinimumSize(QSize(370, 0));
        frmComMall->setMaximumSize(QSize(370, 16777215));
        frmComMall->setStyleSheet(QString::fromUtf8("#frmComMall {\n"
"	background-color: rgb(211, 211, 211);\n"
"	border: 2px solid black;\n"
"}"));
        frmComMall->setFrameShape(QFrame::StyledPanel);
        frmComMall->setFrameShadow(QFrame::Raised);
        btnComMall = new QPushButton(frmComMall);
        btnComMall->setObjectName("btnComMall");
        btnComMall->setGeometry(QRect(145, 135, 80, 24));
        label_47 = new QLabel(frmComMall);
        label_47->setObjectName("label_47");
        label_47->setGeometry(QRect(10, 10, 71, 31));
        label_47->setFont(font1);
        label_48 = new QLabel(frmComMall);
        label_48->setObjectName("label_48");
        label_48->setGeometry(QRect(10, 50, 49, 16));
        label_48->setFont(font2);
        spnComMallWood = new QSpinBox(frmComMall);
        spnComMallWood->setObjectName("spnComMallWood");
        spnComMallWood->setEnabled(false);
        spnComMallWood->setGeometry(QRect(90, 100, 71, 25));
        spnComMallWood->setButtonSymbols(QAbstractSpinBox::NoButtons);
        spnComMallWood->setMinimum(0);
        spnComMallWood->setMaximum(1000000);
        label_49 = new QLabel(frmComMall);
        label_49->setObjectName("label_49");
        label_49->setGeometry(QRect(30, 100, 49, 16));
        label_49->setFont(font3);
        spnComMallSteel = new QSpinBox(frmComMall);
        spnComMallSteel->setObjectName("spnComMallSteel");
        spnComMallSteel->setEnabled(false);
        spnComMallSteel->setGeometry(QRect(250, 70, 71, 25));
        spnComMallSteel->setButtonSymbols(QAbstractSpinBox::NoButtons);
        spnComMallSteel->setMinimum(0);
        spnComMallSteel->setMaximum(1000000);
        label_50 = new QLabel(frmComMall);
        label_50->setObjectName("label_50");
        label_50->setGeometry(QRect(180, 70, 49, 16));
        label_50->setFont(font3);
        label_51 = new QLabel(frmComMall);
        label_51->setObjectName("label_51");
        label_51->setGeometry(QRect(180, 100, 71, 16));
        label_51->setFont(font3);
        spnComMallConcrete = new QSpinBox(frmComMall);
        spnComMallConcrete->setObjectName("spnComMallConcrete");
        spnComMallConcrete->setEnabled(false);
        spnComMallConcrete->setGeometry(QRect(250, 100, 71, 25));
        spnComMallConcrete->setButtonSymbols(QAbstractSpinBox::NoButtons);
        spnComMallConcrete->setMinimum(0);
        spnComMallConcrete->setMaximum(1000000);
        spnComMallCash = new QSpinBox(frmComMall);
        spnComMallCash->setObjectName("spnComMallCash");
        spnComMallCash->setEnabled(false);
        spnComMallCash->setGeometry(QRect(90, 70, 71, 25));
        spnComMallCash->setButtonSymbols(QAbstractSpinBox::NoButtons);
        spnComMallCash->setMinimum(0);
        spnComMallCash->setMaximum(1000000);
        label_52 = new QLabel(frmComMall);
        label_52->setObjectName("label_52");
        label_52->setGeometry(QRect(30, 70, 49, 16));
        label_52->setFont(font3);
        label_53 = new QLabel(frmComMall);
        label_53->setObjectName("label_53");
        label_53->setGeometry(QRect(290, 0, 81, 41));
        label_53->setFont(font3);
        label_75 = new QLabel(frmComMall);
        label_75->setObjectName("label_75");
        label_75->setGeometry(QRect(270, 30, 101, 41));
        label_75->setFont(font3);

        horizontalLayout_3->addWidget(frmComMall);

        scrollArea_2->setWidget(scrollAreaWidgetContents_3);

        horizontalLayout_4->addWidget(scrollArea_2);

        tabBuildBuildings->addTab(tab_8, QString());
        tab_9 = new QWidget();
        tab_9->setObjectName("tab_9");
        horizontalLayout_6 = new QHBoxLayout(tab_9);
        horizontalLayout_6->setObjectName("horizontalLayout_6");
        scrollArea_3 = new QScrollArea(tab_9);
        scrollArea_3->setObjectName("scrollArea_3");
        scrollArea_3->setWidgetResizable(true);
        scrollAreaWidgetContents_4 = new QWidget();
        scrollAreaWidgetContents_4->setObjectName("scrollAreaWidgetContents_4");
        scrollAreaWidgetContents_4->setGeometry(QRect(0, 0, 1275, 202));
        horizontalLayout_5 = new QHBoxLayout(scrollAreaWidgetContents_4);
        horizontalLayout_5->setObjectName("horizontalLayout_5");
        frmIndFactory = new QFrame(scrollAreaWidgetContents_4);
        frmIndFactory->setObjectName("frmIndFactory");
        frmIndFactory->setMinimumSize(QSize(370, 0));
        frmIndFactory->setMaximumSize(QSize(370, 16777215));
        frmIndFactory->setStyleSheet(QString::fromUtf8("#frmIndFactory {\n"
"	background-color: rgb(211, 211, 211);\n"
"	border: 2px solid black;\n"
"}"));
        frmIndFactory->setFrameShape(QFrame::StyledPanel);
        frmIndFactory->setFrameShadow(QFrame::Raised);
        btnIndFactory = new QPushButton(frmIndFactory);
        btnIndFactory->setObjectName("btnIndFactory");
        btnIndFactory->setGeometry(QRect(145, 135, 80, 24));
        label_68 = new QLabel(frmIndFactory);
        label_68->setObjectName("label_68");
        label_68->setGeometry(QRect(10, 10, 101, 31));
        label_68->setFont(font1);
        label_69 = new QLabel(frmIndFactory);
        label_69->setObjectName("label_69");
        label_69->setGeometry(QRect(10, 50, 49, 16));
        label_69->setFont(font2);
        spnIndFactoryWood = new QSpinBox(frmIndFactory);
        spnIndFactoryWood->setObjectName("spnIndFactoryWood");
        spnIndFactoryWood->setGeometry(QRect(90, 100, 71, 25));
        spnIndFactoryWood->setButtonSymbols(QAbstractSpinBox::NoButtons);
        spnIndFactoryWood->setMinimum(0);
        spnIndFactoryWood->setMaximum(1000000);
        label_70 = new QLabel(frmIndFactory);
        label_70->setObjectName("label_70");
        label_70->setGeometry(QRect(30, 100, 49, 16));
        label_70->setFont(font3);
        spnIndFactorySteel = new QSpinBox(frmIndFactory);
        spnIndFactorySteel->setObjectName("spnIndFactorySteel");
        spnIndFactorySteel->setGeometry(QRect(250, 70, 71, 25));
        spnIndFactorySteel->setButtonSymbols(QAbstractSpinBox::NoButtons);
        spnIndFactorySteel->setMinimum(0);
        spnIndFactorySteel->setMaximum(1000000);
        label_71 = new QLabel(frmIndFactory);
        label_71->setObjectName("label_71");
        label_71->setGeometry(QRect(180, 70, 49, 16));
        label_71->setFont(font3);
        label_72 = new QLabel(frmIndFactory);
        label_72->setObjectName("label_72");
        label_72->setGeometry(QRect(180, 100, 71, 16));
        label_72->setFont(font3);
        spnIndFactoryConcrete = new QSpinBox(frmIndFactory);
        spnIndFactoryConcrete->setObjectName("spnIndFactoryConcrete");
        spnIndFactoryConcrete->setGeometry(QRect(250, 100, 71, 25));
        spnIndFactoryConcrete->setButtonSymbols(QAbstractSpinBox::NoButtons);
        spnIndFactoryConcrete->setMinimum(0);
        spnIndFactoryConcrete->setMaximum(1000000);
        spnIndFactoryCash = new QSpinBox(frmIndFactory);
        spnIndFactoryCash->setObjectName("spnIndFactoryCash");
        spnIndFactoryCash->setGeometry(QRect(90, 70, 71, 25));
        spnIndFactoryCash->setButtonSymbols(QAbstractSpinBox::NoButtons);
        spnIndFactoryCash->setMinimum(0);
        spnIndFactoryCash->setMaximum(1000000);
        label_73 = new QLabel(frmIndFactory);
        label_73->setObjectName("label_73");
        label_73->setGeometry(QRect(30, 70, 49, 16));
        label_73->setFont(font3);
        label_74 = new QLabel(frmIndFactory);
        label_74->setObjectName("label_74");
        label_74->setGeometry(QRect(240, 0, 131, 41));
        label_74->setFont(font3);
        label_78 = new QLabel(frmIndFactory);
        label_78->setObjectName("label_78");
        label_78->setGeometry(QRect(300, 30, 71, 41));
        label_78->setFont(font3);

        horizontalLayout_5->addWidget(frmIndFactory);

        frmIndWarehouse = new QFrame(scrollAreaWidgetContents_4);
        frmIndWarehouse->setObjectName("frmIndWarehouse");
        frmIndWarehouse->setMinimumSize(QSize(370, 0));
        frmIndWarehouse->setMaximumSize(QSize(370, 16777215));
        frmIndWarehouse->setStyleSheet(QString::fromUtf8("#frmIndWarehouse {\n"
"	background-color: rgb(211, 211, 211);\n"
"	border: 2px solid black;\n"
"}"));
        frmIndWarehouse->setFrameShape(QFrame::StyledPanel);
        frmIndWarehouse->setFrameShadow(QFrame::Raised);
        btnIndWarehouse = new QPushButton(frmIndWarehouse);
        btnIndWarehouse->setObjectName("btnIndWarehouse");
        btnIndWarehouse->setGeometry(QRect(145, 135, 80, 24));
        label_79 = new QLabel(frmIndWarehouse);
        label_79->setObjectName("label_79");
        label_79->setGeometry(QRect(10, 10, 131, 31));
        label_79->setFont(font1);
        label_80 = new QLabel(frmIndWarehouse);
        label_80->setObjectName("label_80");
        label_80->setGeometry(QRect(10, 50, 49, 16));
        label_80->setFont(font2);
        spnIndWarehouseWood = new QSpinBox(frmIndWarehouse);
        spnIndWarehouseWood->setObjectName("spnIndWarehouseWood");
        spnIndWarehouseWood->setGeometry(QRect(90, 100, 71, 25));
        spnIndWarehouseWood->setButtonSymbols(QAbstractSpinBox::NoButtons);
        spnIndWarehouseWood->setMinimum(0);
        spnIndWarehouseWood->setMaximum(1000000);
        label_81 = new QLabel(frmIndWarehouse);
        label_81->setObjectName("label_81");
        label_81->setGeometry(QRect(30, 100, 49, 16));
        label_81->setFont(font3);
        spnIndWarehouseSteel = new QSpinBox(frmIndWarehouse);
        spnIndWarehouseSteel->setObjectName("spnIndWarehouseSteel");
        spnIndWarehouseSteel->setGeometry(QRect(250, 70, 71, 25));
        spnIndWarehouseSteel->setButtonSymbols(QAbstractSpinBox::NoButtons);
        spnIndWarehouseSteel->setMinimum(0);
        spnIndWarehouseSteel->setMaximum(1000000);
        label_82 = new QLabel(frmIndWarehouse);
        label_82->setObjectName("label_82");
        label_82->setGeometry(QRect(180, 70, 49, 16));
        label_82->setFont(font3);
        label_83 = new QLabel(frmIndWarehouse);
        label_83->setObjectName("label_83");
        label_83->setGeometry(QRect(180, 100, 71, 16));
        label_83->setFont(font3);
        spnIndWarehouseConcrete = new QSpinBox(frmIndWarehouse);
        spnIndWarehouseConcrete->setObjectName("spnIndWarehouseConcrete");
        spnIndWarehouseConcrete->setGeometry(QRect(250, 100, 71, 25));
        spnIndWarehouseConcrete->setButtonSymbols(QAbstractSpinBox::NoButtons);
        spnIndWarehouseConcrete->setMinimum(0);
        spnIndWarehouseConcrete->setMaximum(1000000);
        spnIndWarehouseCash = new QSpinBox(frmIndWarehouse);
        spnIndWarehouseCash->setObjectName("spnIndWarehouseCash");
        spnIndWarehouseCash->setGeometry(QRect(90, 70, 71, 25));
        spnIndWarehouseCash->setButtonSymbols(QAbstractSpinBox::NoButtons);
        spnIndWarehouseCash->setMinimum(0);
        spnIndWarehouseCash->setMaximum(1000000);
        label_84 = new QLabel(frmIndWarehouse);
        label_84->setObjectName("label_84");
        label_84->setGeometry(QRect(30, 70, 49, 16));
        label_84->setFont(font3);
        label_85 = new QLabel(frmIndWarehouse);
        label_85->setObjectName("label_85");
        label_85->setGeometry(QRect(220, 0, 151, 41));
        label_85->setFont(font3);
        label_86 = new QLabel(frmIndWarehouse);
        label_86->setObjectName("label_86");
        label_86->setGeometry(QRect(300, 30, 71, 41));
        label_86->setFont(font3);

        horizontalLayout_5->addWidget(frmIndWarehouse);

        frmIndPlant = new QFrame(scrollAreaWidgetContents_4);
        frmIndPlant->setObjectName("frmIndPlant");
        frmIndPlant->setMinimumSize(QSize(370, 0));
        frmIndPlant->setMaximumSize(QSize(370, 16777215));
        frmIndPlant->setStyleSheet(QString::fromUtf8("#frmIndPlant {\n"
"	background-color: rgb(211, 211, 211);\n"
"	border: 2px solid black;\n"
"}"));
        frmIndPlant->setFrameShape(QFrame::StyledPanel);
        frmIndPlant->setFrameShadow(QFrame::Raised);
        btnIndPlant = new QPushButton(frmIndPlant);
        btnIndPlant->setObjectName("btnIndPlant");
        btnIndPlant->setGeometry(QRect(145, 135, 80, 24));
        label_87 = new QLabel(frmIndPlant);
        label_87->setObjectName("label_87");
        label_87->setGeometry(QRect(10, 10, 181, 31));
        label_87->setFont(font1);
        label_88 = new QLabel(frmIndPlant);
        label_88->setObjectName("label_88");
        label_88->setGeometry(QRect(10, 50, 49, 16));
        label_88->setFont(font2);
        spnIndPlantWood = new QSpinBox(frmIndPlant);
        spnIndPlantWood->setObjectName("spnIndPlantWood");
        spnIndPlantWood->setGeometry(QRect(90, 100, 71, 25));
        spnIndPlantWood->setButtonSymbols(QAbstractSpinBox::NoButtons);
        spnIndPlantWood->setMinimum(0);
        spnIndPlantWood->setMaximum(1000000);
        label_89 = new QLabel(frmIndPlant);
        label_89->setObjectName("label_89");
        label_89->setGeometry(QRect(30, 100, 49, 16));
        label_89->setFont(font3);
        spnIndPlantSteel = new QSpinBox(frmIndPlant);
        spnIndPlantSteel->setObjectName("spnIndPlantSteel");
        spnIndPlantSteel->setGeometry(QRect(250, 70, 71, 25));
        spnIndPlantSteel->setButtonSymbols(QAbstractSpinBox::NoButtons);
        spnIndPlantSteel->setMinimum(0);
        spnIndPlantSteel->setMaximum(1000000);
        label_90 = new QLabel(frmIndPlant);
        label_90->setObjectName("label_90");
        label_90->setGeometry(QRect(180, 70, 49, 16));
        label_90->setFont(font3);
        label_91 = new QLabel(frmIndPlant);
        label_91->setObjectName("label_91");
        label_91->setGeometry(QRect(180, 100, 71, 16));
        label_91->setFont(font3);
        spnIndPlantConcrete = new QSpinBox(frmIndPlant);
        spnIndPlantConcrete->setObjectName("spnIndPlantConcrete");
        spnIndPlantConcrete->setGeometry(QRect(250, 100, 71, 25));
        spnIndPlantConcrete->setButtonSymbols(QAbstractSpinBox::NoButtons);
        spnIndPlantConcrete->setMinimum(0);
        spnIndPlantConcrete->setMaximum(1000000);
        spnIndPlantCash = new QSpinBox(frmIndPlant);
        spnIndPlantCash->setObjectName("spnIndPlantCash");
        spnIndPlantCash->setGeometry(QRect(90, 70, 71, 25));
        spnIndPlantCash->setButtonSymbols(QAbstractSpinBox::NoButtons);
        spnIndPlantCash->setMinimum(0);
        spnIndPlantCash->setMaximum(1000000);
        label_92 = new QLabel(frmIndPlant);
        label_92->setObjectName("label_92");
        label_92->setGeometry(QRect(30, 70, 49, 16));
        label_92->setFont(font3);
        label_93 = new QLabel(frmIndPlant);
        label_93->setObjectName("label_93");
        label_93->setGeometry(QRect(250, 0, 121, 41));
        label_93->setFont(font3);
        label_94 = new QLabel(frmIndPlant);
        label_94->setObjectName("label_94");
        label_94->setGeometry(QRect(300, 30, 71, 41));
        label_94->setFont(font3);

        horizontalLayout_5->addWidget(frmIndPlant);

        scrollArea_3->setWidget(scrollAreaWidgetContents_4);

        horizontalLayout_6->addWidget(scrollArea_3);

        tabBuildBuildings->addTab(tab_9, QString());
        tab_10 = new QWidget();
        tab_10->setObjectName("tab_10");
        horizontalLayout_9 = new QHBoxLayout(tab_10);
        horizontalLayout_9->setObjectName("horizontalLayout_9");
        scrollArea_4 = new QScrollArea(tab_10);
        scrollArea_4->setObjectName("scrollArea_4");
        scrollArea_4->setWidgetResizable(true);
        scrollAreaWidgetContents_5 = new QWidget();
        scrollAreaWidgetContents_5->setObjectName("scrollAreaWidgetContents_5");
        scrollAreaWidgetContents_5->setGeometry(QRect(0, 0, 1275, 202));
        horizontalLayout_7 = new QHBoxLayout(scrollAreaWidgetContents_5);
        horizontalLayout_7->setObjectName("horizontalLayout_7");
        frmLandPark = new QFrame(scrollAreaWidgetContents_5);
        frmLandPark->setObjectName("frmLandPark");
        frmLandPark->setMinimumSize(QSize(370, 0));
        frmLandPark->setMaximumSize(QSize(370, 16777215));
        frmLandPark->setStyleSheet(QString::fromUtf8("#frmLandPark {\n"
"	background-color: rgb(211, 211, 211);\n"
"	border: 2px solid black;\n"
"}"));
        frmLandPark->setFrameShape(QFrame::StyledPanel);
        frmLandPark->setFrameShadow(QFrame::Raised);
        btnLandPark = new QPushButton(frmLandPark);
        btnLandPark->setObjectName("btnLandPark");
        btnLandPark->setGeometry(QRect(145, 135, 80, 24));
        label_95 = new QLabel(frmLandPark);
        label_95->setObjectName("label_95");
        label_95->setGeometry(QRect(10, 10, 71, 31));
        label_95->setFont(font1);
        label_96 = new QLabel(frmLandPark);
        label_96->setObjectName("label_96");
        label_96->setGeometry(QRect(10, 50, 49, 16));
        label_96->setFont(font2);
        spnLandParkWood = new QSpinBox(frmLandPark);
        spnLandParkWood->setObjectName("spnLandParkWood");
        spnLandParkWood->setGeometry(QRect(90, 100, 71, 25));
        spnLandParkWood->setButtonSymbols(QAbstractSpinBox::NoButtons);
        spnLandParkWood->setMinimum(0);
        spnLandParkWood->setMaximum(1000000);
        label_97 = new QLabel(frmLandPark);
        label_97->setObjectName("label_97");
        label_97->setGeometry(QRect(30, 100, 49, 16));
        label_97->setFont(font3);
        spnLandParkSteel = new QSpinBox(frmLandPark);
        spnLandParkSteel->setObjectName("spnLandParkSteel");
        spnLandParkSteel->setGeometry(QRect(250, 70, 71, 25));
        spnLandParkSteel->setButtonSymbols(QAbstractSpinBox::NoButtons);
        spnLandParkSteel->setMinimum(0);
        spnLandParkSteel->setMaximum(1000000);
        label_98 = new QLabel(frmLandPark);
        label_98->setObjectName("label_98");
        label_98->setGeometry(QRect(180, 70, 49, 16));
        label_98->setFont(font3);
        label_99 = new QLabel(frmLandPark);
        label_99->setObjectName("label_99");
        label_99->setGeometry(QRect(180, 100, 71, 16));
        label_99->setFont(font3);
        spnLandParkConcrete = new QSpinBox(frmLandPark);
        spnLandParkConcrete->setObjectName("spnLandParkConcrete");
        spnLandParkConcrete->setGeometry(QRect(250, 100, 71, 25));
        spnLandParkConcrete->setButtonSymbols(QAbstractSpinBox::NoButtons);
        spnLandParkConcrete->setMinimum(0);
        spnLandParkConcrete->setMaximum(1000000);
        spnLandParkCash = new QSpinBox(frmLandPark);
        spnLandParkCash->setObjectName("spnLandParkCash");
        spnLandParkCash->setGeometry(QRect(90, 70, 71, 25));
        spnLandParkCash->setButtonSymbols(QAbstractSpinBox::NoButtons);
        spnLandParkCash->setMinimum(0);
        spnLandParkCash->setMaximum(1000000);
        label_100 = new QLabel(frmLandPark);
        label_100->setObjectName("label_100");
        label_100->setGeometry(QRect(30, 70, 49, 16));
        label_100->setFont(font3);
        label_101 = new QLabel(frmLandPark);
        label_101->setObjectName("label_101");
        label_101->setGeometry(QRect(270, 0, 101, 41));
        label_101->setFont(font3);
        label_102 = new QLabel(frmLandPark);
        label_102->setObjectName("label_102");
        label_102->setGeometry(QRect(300, 30, 71, 41));
        label_102->setFont(font3);

        horizontalLayout_7->addWidget(frmLandPark);

        frmLandMonument = new QFrame(scrollAreaWidgetContents_5);
        frmLandMonument->setObjectName("frmLandMonument");
        frmLandMonument->setMinimumSize(QSize(370, 0));
        frmLandMonument->setMaximumSize(QSize(370, 16777215));
        frmLandMonument->setStyleSheet(QString::fromUtf8("#frmLandMonument {\n"
"	background-color: rgb(211, 211, 211);\n"
"	border: 2px solid black;\n"
"}"));
        frmLandMonument->setFrameShape(QFrame::StyledPanel);
        frmLandMonument->setFrameShadow(QFrame::Raised);
        btnLandMonument = new QPushButton(frmLandMonument);
        btnLandMonument->setObjectName("btnLandMonument");
        btnLandMonument->setGeometry(QRect(145, 135, 80, 24));
        label_103 = new QLabel(frmLandMonument);
        label_103->setObjectName("label_103");
        label_103->setGeometry(QRect(10, 10, 131, 31));
        label_103->setFont(font1);
        label_104 = new QLabel(frmLandMonument);
        label_104->setObjectName("label_104");
        label_104->setGeometry(QRect(10, 50, 49, 16));
        label_104->setFont(font2);
        spnLandMonumentWood = new QSpinBox(frmLandMonument);
        spnLandMonumentWood->setObjectName("spnLandMonumentWood");
        spnLandMonumentWood->setGeometry(QRect(90, 100, 71, 25));
        spnLandMonumentWood->setButtonSymbols(QAbstractSpinBox::NoButtons);
        spnLandMonumentWood->setMinimum(0);
        spnLandMonumentWood->setMaximum(1000000);
        label_105 = new QLabel(frmLandMonument);
        label_105->setObjectName("label_105");
        label_105->setGeometry(QRect(30, 100, 49, 16));
        label_105->setFont(font3);
        spnLandMonumentSteel = new QSpinBox(frmLandMonument);
        spnLandMonumentSteel->setObjectName("spnLandMonumentSteel");
        spnLandMonumentSteel->setGeometry(QRect(250, 70, 71, 25));
        spnLandMonumentSteel->setButtonSymbols(QAbstractSpinBox::NoButtons);
        spnLandMonumentSteel->setMinimum(0);
        spnLandMonumentSteel->setMaximum(1000000);
        label_106 = new QLabel(frmLandMonument);
        label_106->setObjectName("label_106");
        label_106->setGeometry(QRect(180, 70, 49, 16));
        label_106->setFont(font3);
        label_107 = new QLabel(frmLandMonument);
        label_107->setObjectName("label_107");
        label_107->setGeometry(QRect(180, 100, 71, 16));
        label_107->setFont(font3);
        spnLandMonumentConcrete = new QSpinBox(frmLandMonument);
        spnLandMonumentConcrete->setObjectName("spnLandMonumentConcrete");
        spnLandMonumentConcrete->setGeometry(QRect(250, 100, 71, 25));
        spnLandMonumentConcrete->setButtonSymbols(QAbstractSpinBox::NoButtons);
        spnLandMonumentConcrete->setMinimum(0);
        spnLandMonumentConcrete->setMaximum(1000000);
        spnLandMonumentCash = new QSpinBox(frmLandMonument);
        spnLandMonumentCash->setObjectName("spnLandMonumentCash");
        spnLandMonumentCash->setGeometry(QRect(90, 70, 71, 25));
        spnLandMonumentCash->setButtonSymbols(QAbstractSpinBox::NoButtons);
        spnLandMonumentCash->setMinimum(0);
        spnLandMonumentCash->setMaximum(1000000);
        label_108 = new QLabel(frmLandMonument);
        label_108->setObjectName("label_108");
        label_108->setGeometry(QRect(30, 70, 49, 16));
        label_108->setFont(font3);
        label_109 = new QLabel(frmLandMonument);
        label_109->setObjectName("label_109");
        label_109->setGeometry(QRect(260, 0, 111, 41));
        label_109->setFont(font3);
        label_110 = new QLabel(frmLandMonument);
        label_110->setObjectName("label_110");
        label_110->setGeometry(QRect(300, 30, 71, 41));
        label_110->setFont(font3);

        horizontalLayout_7->addWidget(frmLandMonument);

        frmLandComCenter = new QFrame(scrollAreaWidgetContents_5);
        frmLandComCenter->setObjectName("frmLandComCenter");
        frmLandComCenter->setMinimumSize(QSize(370, 0));
        frmLandComCenter->setMaximumSize(QSize(370, 16777215));
        frmLandComCenter->setStyleSheet(QString::fromUtf8("#frmLandComCenter {\n"
"	background-color: rgb(211, 211, 211);\n"
"	border: 2px solid black;\n"
"}"));
        frmLandComCenter->setFrameShape(QFrame::StyledPanel);
        frmLandComCenter->setFrameShadow(QFrame::Raised);
        btnLandCCenter = new QPushButton(frmLandComCenter);
        btnLandCCenter->setObjectName("btnLandCCenter");
        btnLandCCenter->setGeometry(QRect(145, 135, 80, 24));
        label_111 = new QLabel(frmLandComCenter);
        label_111->setObjectName("label_111");
        label_111->setGeometry(QRect(10, 10, 211, 31));
        label_111->setFont(font1);
        label_112 = new QLabel(frmLandComCenter);
        label_112->setObjectName("label_112");
        label_112->setGeometry(QRect(10, 50, 49, 16));
        label_112->setFont(font2);
        spnLandCCenterWood = new QSpinBox(frmLandComCenter);
        spnLandCCenterWood->setObjectName("spnLandCCenterWood");
        spnLandCCenterWood->setGeometry(QRect(90, 100, 71, 25));
        spnLandCCenterWood->setButtonSymbols(QAbstractSpinBox::NoButtons);
        spnLandCCenterWood->setMinimum(0);
        spnLandCCenterWood->setMaximum(1000000);
        label_113 = new QLabel(frmLandComCenter);
        label_113->setObjectName("label_113");
        label_113->setGeometry(QRect(30, 100, 49, 16));
        label_113->setFont(font3);
        spnLandCCenterSteel = new QSpinBox(frmLandComCenter);
        spnLandCCenterSteel->setObjectName("spnLandCCenterSteel");
        spnLandCCenterSteel->setGeometry(QRect(250, 70, 71, 25));
        spnLandCCenterSteel->setButtonSymbols(QAbstractSpinBox::NoButtons);
        spnLandCCenterSteel->setMinimum(0);
        spnLandCCenterSteel->setMaximum(1000000);
        label_114 = new QLabel(frmLandComCenter);
        label_114->setObjectName("label_114");
        label_114->setGeometry(QRect(180, 70, 49, 16));
        label_114->setFont(font3);
        label_115 = new QLabel(frmLandComCenter);
        label_115->setObjectName("label_115");
        label_115->setGeometry(QRect(180, 100, 71, 16));
        label_115->setFont(font3);
        spnLandCCenterConcrete = new QSpinBox(frmLandComCenter);
        spnLandCCenterConcrete->setObjectName("spnLandCCenterConcrete");
        spnLandCCenterConcrete->setGeometry(QRect(250, 100, 71, 25));
        spnLandCCenterConcrete->setButtonSymbols(QAbstractSpinBox::NoButtons);
        spnLandCCenterConcrete->setMinimum(0);
        spnLandCCenterConcrete->setMaximum(1000000);
        spnLandCCenterCash = new QSpinBox(frmLandComCenter);
        spnLandCCenterCash->setObjectName("spnLandCCenterCash");
        spnLandCCenterCash->setGeometry(QRect(90, 70, 71, 25));
        spnLandCCenterCash->setButtonSymbols(QAbstractSpinBox::NoButtons);
        spnLandCCenterCash->setMinimum(0);
        spnLandCCenterCash->setMaximum(1000000);
        label_116 = new QLabel(frmLandComCenter);
        label_116->setObjectName("label_116");
        label_116->setGeometry(QRect(30, 70, 49, 16));
        label_116->setFont(font3);
        label_117 = new QLabel(frmLandComCenter);
        label_117->setObjectName("label_117");
        label_117->setGeometry(QRect(260, 0, 111, 41));
        label_117->setFont(font3);
        label_118 = new QLabel(frmLandComCenter);
        label_118->setObjectName("label_118");
        label_118->setGeometry(QRect(300, 30, 71, 41));
        label_118->setFont(font3);

        horizontalLayout_7->addWidget(frmLandComCenter);

        scrollArea_4->setWidget(scrollAreaWidgetContents_5);

        horizontalLayout_9->addWidget(scrollArea_4);

        tabBuildBuildings->addTab(tab_10, QString());
        tab_11 = new QWidget();
        tab_11->setObjectName("tab_11");
        horizontalLayout_10 = new QHBoxLayout(tab_11);
        horizontalLayout_10->setObjectName("horizontalLayout_10");
        scrollArea_5 = new QScrollArea(tab_11);
        scrollArea_5->setObjectName("scrollArea_5");
        scrollArea_5->setWidgetResizable(true);
        scrollAreaWidgetContents_6 = new QWidget();
        scrollAreaWidgetContents_6->setObjectName("scrollAreaWidgetContents_6");
        scrollAreaWidgetContents_6->setGeometry(QRect(0, 0, 1516, 188));
        horizontalLayout_8 = new QHBoxLayout(scrollAreaWidgetContents_6);
        horizontalLayout_8->setObjectName("horizontalLayout_8");
        frmServHospital = new QFrame(scrollAreaWidgetContents_6);
        frmServHospital->setObjectName("frmServHospital");
        frmServHospital->setMinimumSize(QSize(370, 0));
        frmServHospital->setMaximumSize(QSize(370, 16777215));
        frmServHospital->setStyleSheet(QString::fromUtf8("#frmServHospital {\n"
"	background-color: rgb(211, 211, 211);\n"
"	border: 2px solid black;\n"
"}"));
        frmServHospital->setFrameShape(QFrame::StyledPanel);
        frmServHospital->setFrameShadow(QFrame::Raised);
        btnServHospital = new QPushButton(frmServHospital);
        btnServHospital->setObjectName("btnServHospital");
        btnServHospital->setGeometry(QRect(145, 135, 80, 24));
        label_119 = new QLabel(frmServHospital);
        label_119->setObjectName("label_119");
        label_119->setGeometry(QRect(10, 10, 101, 31));
        label_119->setFont(font1);
        label_120 = new QLabel(frmServHospital);
        label_120->setObjectName("label_120");
        label_120->setGeometry(QRect(10, 50, 49, 16));
        label_120->setFont(font2);
        spnServHospitalWood = new QSpinBox(frmServHospital);
        spnServHospitalWood->setObjectName("spnServHospitalWood");
        spnServHospitalWood->setGeometry(QRect(90, 100, 71, 25));
        spnServHospitalWood->setButtonSymbols(QAbstractSpinBox::NoButtons);
        spnServHospitalWood->setMinimum(0);
        spnServHospitalWood->setMaximum(1000000);
        label_121 = new QLabel(frmServHospital);
        label_121->setObjectName("label_121");
        label_121->setGeometry(QRect(30, 100, 49, 16));
        label_121->setFont(font3);
        spnServHospitalSteel = new QSpinBox(frmServHospital);
        spnServHospitalSteel->setObjectName("spnServHospitalSteel");
        spnServHospitalSteel->setGeometry(QRect(250, 70, 71, 25));
        spnServHospitalSteel->setButtonSymbols(QAbstractSpinBox::NoButtons);
        spnServHospitalSteel->setMinimum(0);
        spnServHospitalSteel->setMaximum(1000000);
        label_122 = new QLabel(frmServHospital);
        label_122->setObjectName("label_122");
        label_122->setGeometry(QRect(180, 70, 49, 16));
        label_122->setFont(font3);
        label_123 = new QLabel(frmServHospital);
        label_123->setObjectName("label_123");
        label_123->setGeometry(QRect(180, 100, 71, 16));
        label_123->setFont(font3);
        spnServHospitalConcrete = new QSpinBox(frmServHospital);
        spnServHospitalConcrete->setObjectName("spnServHospitalConcrete");
        spnServHospitalConcrete->setGeometry(QRect(250, 100, 71, 25));
        spnServHospitalConcrete->setButtonSymbols(QAbstractSpinBox::NoButtons);
        spnServHospitalConcrete->setMinimum(0);
        spnServHospitalConcrete->setMaximum(1000000);
        spnServHospitalCash = new QSpinBox(frmServHospital);
        spnServHospitalCash->setObjectName("spnServHospitalCash");
        spnServHospitalCash->setGeometry(QRect(90, 70, 71, 25));
        spnServHospitalCash->setButtonSymbols(QAbstractSpinBox::NoButtons);
        spnServHospitalCash->setMinimum(0);
        spnServHospitalCash->setMaximum(1000000);
        label_124 = new QLabel(frmServHospital);
        label_124->setObjectName("label_124");
        label_124->setGeometry(QRect(30, 70, 49, 16));
        label_124->setFont(font3);
        label_152 = new QLabel(frmServHospital);
        label_152->setObjectName("label_152");
        label_152->setGeometry(QRect(268, 20, 101, 41));
        label_152->setFont(font3);
        label_149 = new QLabel(frmServHospital);
        label_149->setObjectName("label_149");
        label_149->setGeometry(QRect(299, 0, 71, 41));
        label_149->setFont(font3);
        label_150 = new QLabel(frmServHospital);
        label_150->setObjectName("label_150");
        label_150->setGeometry(QRect(279, 40, 91, 41));
        label_150->setFont(font3);

        horizontalLayout_8->addWidget(frmServHospital);

        frmServEducation = new QFrame(scrollAreaWidgetContents_6);
        frmServEducation->setObjectName("frmServEducation");
        frmServEducation->setMinimumSize(QSize(370, 0));
        frmServEducation->setMaximumSize(QSize(370, 16777215));
        frmServEducation->setStyleSheet(QString::fromUtf8("#frmServEducation {\n"
"	background-color: rgb(211, 211, 211);\n"
"	border: 2px solid black;\n"
"}"));
        frmServEducation->setFrameShape(QFrame::StyledPanel);
        frmServEducation->setFrameShadow(QFrame::Raised);
        btnServEducation = new QPushButton(frmServEducation);
        btnServEducation->setObjectName("btnServEducation");
        btnServEducation->setGeometry(QRect(145, 135, 80, 24));
        label_127 = new QLabel(frmServEducation);
        label_127->setObjectName("label_127");
        label_127->setGeometry(QRect(10, 10, 111, 31));
        label_127->setFont(font1);
        label_128 = new QLabel(frmServEducation);
        label_128->setObjectName("label_128");
        label_128->setGeometry(QRect(10, 50, 49, 16));
        label_128->setFont(font2);
        spnServEducationWood = new QSpinBox(frmServEducation);
        spnServEducationWood->setObjectName("spnServEducationWood");
        spnServEducationWood->setGeometry(QRect(90, 100, 71, 25));
        spnServEducationWood->setButtonSymbols(QAbstractSpinBox::NoButtons);
        spnServEducationWood->setMinimum(0);
        spnServEducationWood->setMaximum(1000000);
        label_129 = new QLabel(frmServEducation);
        label_129->setObjectName("label_129");
        label_129->setGeometry(QRect(30, 100, 49, 16));
        label_129->setFont(font3);
        spnServEducationSteel = new QSpinBox(frmServEducation);
        spnServEducationSteel->setObjectName("spnServEducationSteel");
        spnServEducationSteel->setGeometry(QRect(250, 70, 71, 25));
        spnServEducationSteel->setButtonSymbols(QAbstractSpinBox::NoButtons);
        spnServEducationSteel->setMinimum(0);
        spnServEducationSteel->setMaximum(1000000);
        label_130 = new QLabel(frmServEducation);
        label_130->setObjectName("label_130");
        label_130->setGeometry(QRect(180, 70, 49, 16));
        label_130->setFont(font3);
        label_131 = new QLabel(frmServEducation);
        label_131->setObjectName("label_131");
        label_131->setGeometry(QRect(180, 100, 71, 16));
        label_131->setFont(font3);
        spnServEducationConcrete = new QSpinBox(frmServEducation);
        spnServEducationConcrete->setObjectName("spnServEducationConcrete");
        spnServEducationConcrete->setGeometry(QRect(250, 100, 71, 25));
        spnServEducationConcrete->setButtonSymbols(QAbstractSpinBox::NoButtons);
        spnServEducationConcrete->setMinimum(0);
        spnServEducationConcrete->setMaximum(1000000);
        spnServEducationCash = new QSpinBox(frmServEducation);
        spnServEducationCash->setObjectName("spnServEducationCash");
        spnServEducationCash->setGeometry(QRect(90, 70, 71, 25));
        spnServEducationCash->setButtonSymbols(QAbstractSpinBox::NoButtons);
        spnServEducationCash->setMinimum(0);
        spnServEducationCash->setMaximum(1000000);
        label_132 = new QLabel(frmServEducation);
        label_132->setObjectName("label_132");
        label_132->setGeometry(QRect(30, 70, 49, 16));
        label_132->setFont(font3);
        label_153 = new QLabel(frmServEducation);
        label_153->setObjectName("label_153");
        label_153->setGeometry(QRect(268, 20, 101, 41));
        label_153->setFont(font3);
        label_154 = new QLabel(frmServEducation);
        label_154->setObjectName("label_154");
        label_154->setGeometry(QRect(299, 0, 71, 41));
        label_154->setFont(font3);
        label_155 = new QLabel(frmServEducation);
        label_155->setObjectName("label_155");
        label_155->setGeometry(QRect(279, 40, 91, 41));
        label_155->setFont(font3);

        horizontalLayout_8->addWidget(frmServEducation);

        frmServSecurity = new QFrame(scrollAreaWidgetContents_6);
        frmServSecurity->setObjectName("frmServSecurity");
        frmServSecurity->setMinimumSize(QSize(370, 0));
        frmServSecurity->setMaximumSize(QSize(370, 16777215));
        frmServSecurity->setStyleSheet(QString::fromUtf8("#frmServSecurity {\n"
"	background-color: rgb(211, 211, 211);\n"
"	border: 2px solid black;\n"
"}"));
        frmServSecurity->setFrameShape(QFrame::StyledPanel);
        frmServSecurity->setFrameShadow(QFrame::Raised);
        btnServSecurity = new QPushButton(frmServSecurity);
        btnServSecurity->setObjectName("btnServSecurity");
        btnServSecurity->setGeometry(QRect(145, 135, 80, 24));
        label_143 = new QLabel(frmServSecurity);
        label_143->setObjectName("label_143");
        label_143->setGeometry(QRect(10, 10, 101, 31));
        label_143->setFont(font1);
        label_144 = new QLabel(frmServSecurity);
        label_144->setObjectName("label_144");
        label_144->setGeometry(QRect(10, 50, 49, 16));
        label_144->setFont(font2);
        spnServSecurityWood = new QSpinBox(frmServSecurity);
        spnServSecurityWood->setObjectName("spnServSecurityWood");
        spnServSecurityWood->setGeometry(QRect(90, 100, 71, 25));
        spnServSecurityWood->setButtonSymbols(QAbstractSpinBox::NoButtons);
        spnServSecurityWood->setMinimum(0);
        spnServSecurityWood->setMaximum(1000000);
        label_145 = new QLabel(frmServSecurity);
        label_145->setObjectName("label_145");
        label_145->setGeometry(QRect(30, 100, 49, 16));
        label_145->setFont(font3);
        spnServSecuritySteel = new QSpinBox(frmServSecurity);
        spnServSecuritySteel->setObjectName("spnServSecuritySteel");
        spnServSecuritySteel->setGeometry(QRect(250, 70, 71, 25));
        spnServSecuritySteel->setButtonSymbols(QAbstractSpinBox::NoButtons);
        spnServSecuritySteel->setMinimum(0);
        spnServSecuritySteel->setMaximum(1000000);
        label_146 = new QLabel(frmServSecurity);
        label_146->setObjectName("label_146");
        label_146->setGeometry(QRect(180, 70, 49, 16));
        label_146->setFont(font3);
        label_147 = new QLabel(frmServSecurity);
        label_147->setObjectName("label_147");
        label_147->setGeometry(QRect(180, 100, 71, 16));
        label_147->setFont(font3);
        spnServSecurityConcrete = new QSpinBox(frmServSecurity);
        spnServSecurityConcrete->setObjectName("spnServSecurityConcrete");
        spnServSecurityConcrete->setGeometry(QRect(250, 100, 71, 25));
        spnServSecurityConcrete->setButtonSymbols(QAbstractSpinBox::NoButtons);
        spnServSecurityConcrete->setMinimum(0);
        spnServSecurityConcrete->setMaximum(1000000);
        spnServSecurityCash = new QSpinBox(frmServSecurity);
        spnServSecurityCash->setObjectName("spnServSecurityCash");
        spnServSecurityCash->setGeometry(QRect(90, 70, 71, 25));
        spnServSecurityCash->setButtonSymbols(QAbstractSpinBox::NoButtons);
        spnServSecurityCash->setMinimum(0);
        spnServSecurityCash->setMaximum(1000000);
        label_148 = new QLabel(frmServSecurity);
        label_148->setObjectName("label_148");
        label_148->setGeometry(QRect(30, 70, 49, 16));
        label_148->setFont(font3);
        label_156 = new QLabel(frmServSecurity);
        label_156->setObjectName("label_156");
        label_156->setGeometry(QRect(268, 20, 101, 41));
        label_156->setFont(font3);
        label_157 = new QLabel(frmServSecurity);
        label_157->setObjectName("label_157");
        label_157->setGeometry(QRect(299, 0, 71, 41));
        label_157->setFont(font3);
        label_158 = new QLabel(frmServSecurity);
        label_158->setObjectName("label_158");
        label_158->setGeometry(QRect(279, 40, 91, 41));
        label_158->setFont(font3);

        horizontalLayout_8->addWidget(frmServSecurity);

        frmServEntertainment = new QFrame(scrollAreaWidgetContents_6);
        frmServEntertainment->setObjectName("frmServEntertainment");
        frmServEntertainment->setMinimumSize(QSize(370, 0));
        frmServEntertainment->setMaximumSize(QSize(370, 16777215));
        frmServEntertainment->setStyleSheet(QString::fromUtf8("#frmServEntertainment {\n"
"	background-color: rgb(211, 211, 211);\n"
"	border: 2px solid black;\n"
"}"));
        frmServEntertainment->setFrameShape(QFrame::StyledPanel);
        frmServEntertainment->setFrameShadow(QFrame::Raised);
        btnServEntertainment = new QPushButton(frmServEntertainment);
        btnServEntertainment->setObjectName("btnServEntertainment");
        btnServEntertainment->setGeometry(QRect(145, 135, 80, 24));
        label_135 = new QLabel(frmServEntertainment);
        label_135->setObjectName("label_135");
        label_135->setGeometry(QRect(10, 10, 161, 31));
        label_135->setFont(font1);
        label_136 = new QLabel(frmServEntertainment);
        label_136->setObjectName("label_136");
        label_136->setGeometry(QRect(10, 50, 49, 16));
        label_136->setFont(font2);
        spnServEntertainmentWood = new QSpinBox(frmServEntertainment);
        spnServEntertainmentWood->setObjectName("spnServEntertainmentWood");
        spnServEntertainmentWood->setGeometry(QRect(90, 100, 71, 25));
        spnServEntertainmentWood->setButtonSymbols(QAbstractSpinBox::NoButtons);
        spnServEntertainmentWood->setMinimum(0);
        spnServEntertainmentWood->setMaximum(1000000);
        label_137 = new QLabel(frmServEntertainment);
        label_137->setObjectName("label_137");
        label_137->setGeometry(QRect(30, 100, 49, 16));
        label_137->setFont(font3);
        spnServEntertainmentSteel = new QSpinBox(frmServEntertainment);
        spnServEntertainmentSteel->setObjectName("spnServEntertainmentSteel");
        spnServEntertainmentSteel->setGeometry(QRect(250, 70, 71, 25));
        spnServEntertainmentSteel->setButtonSymbols(QAbstractSpinBox::NoButtons);
        spnServEntertainmentSteel->setMinimum(0);
        spnServEntertainmentSteel->setMaximum(1000000);
        label_138 = new QLabel(frmServEntertainment);
        label_138->setObjectName("label_138");
        label_138->setGeometry(QRect(180, 70, 49, 16));
        label_138->setFont(font3);
        label_139 = new QLabel(frmServEntertainment);
        label_139->setObjectName("label_139");
        label_139->setGeometry(QRect(180, 100, 71, 16));
        label_139->setFont(font3);
        spnServEntertainmentConcrete = new QSpinBox(frmServEntertainment);
        spnServEntertainmentConcrete->setObjectName("spnServEntertainmentConcrete");
        spnServEntertainmentConcrete->setGeometry(QRect(250, 100, 71, 25));
        spnServEntertainmentConcrete->setButtonSymbols(QAbstractSpinBox::NoButtons);
        spnServEntertainmentConcrete->setMinimum(0);
        spnServEntertainmentConcrete->setMaximum(1000000);
        spnServEntertainmentCash = new QSpinBox(frmServEntertainment);
        spnServEntertainmentCash->setObjectName("spnServEntertainmentCash");
        spnServEntertainmentCash->setGeometry(QRect(90, 70, 71, 25));
        spnServEntertainmentCash->setButtonSymbols(QAbstractSpinBox::NoButtons);
        spnServEntertainmentCash->setMinimum(0);
        spnServEntertainmentCash->setMaximum(1000000);
        label_140 = new QLabel(frmServEntertainment);
        label_140->setObjectName("label_140");
        label_140->setGeometry(QRect(30, 70, 49, 16));
        label_140->setFont(font3);
        label_141 = new QLabel(frmServEntertainment);
        label_141->setObjectName("label_141");
        label_141->setGeometry(QRect(301, 0, 71, 41));
        label_141->setFont(font3);
        label_142 = new QLabel(frmServEntertainment);
        label_142->setObjectName("label_142");
        label_142->setGeometry(QRect(272, 40, 100, 41));
        label_142->setFont(font3);
        label_151 = new QLabel(frmServEntertainment);
        label_151->setObjectName("label_151");
        label_151->setGeometry(QRect(260, 20, 111, 41));
        label_151->setFont(font3);

        horizontalLayout_8->addWidget(frmServEntertainment);

        scrollArea_5->setWidget(scrollAreaWidgetContents_6);

        horizontalLayout_10->addWidget(scrollArea_5);

        tabBuildBuildings->addTab(tab_11, QString());

        verticalLayout->addWidget(tabBuildBuildings);

        tabBuildCity->addTab(tab, QString());
        tab_2 = new QWidget();
        tab_2->setObjectName("tab_2");
        horizontalLayout_11 = new QHBoxLayout(tab_2);
        horizontalLayout_11->setObjectName("horizontalLayout_11");
        scrollArea_7 = new QScrollArea(tab_2);
        scrollArea_7->setObjectName("scrollArea_7");
        scrollArea_7->setWidgetResizable(true);
        scrollAreaWidgetContents_8 = new QWidget();
        scrollAreaWidgetContents_8->setObjectName("scrollAreaWidgetContents_8");
        scrollAreaWidgetContents_8->setGeometry(QRect(0, 0, 1516, 236));
        horizontalLayout_13 = new QHBoxLayout(scrollAreaWidgetContents_8);
        horizontalLayout_13->setObjectName("horizontalLayout_13");
        frmUtilPower = new QFrame(scrollAreaWidgetContents_8);
        frmUtilPower->setObjectName("frmUtilPower");
        frmUtilPower->setMinimumSize(QSize(370, 0));
        frmUtilPower->setMaximumSize(QSize(370, 16777215));
        frmUtilPower->setStyleSheet(QString::fromUtf8("#frmUtilPower {\n"
"	background-color: rgb(211, 211, 211);\n"
"	border: 2px solid black;\n"
"}"));
        frmUtilPower->setFrameShape(QFrame::StyledPanel);
        frmUtilPower->setFrameShadow(QFrame::Raised);
        btnUtilPower = new QPushButton(frmUtilPower);
        btnUtilPower->setObjectName("btnUtilPower");
        btnUtilPower->setGeometry(QRect(140, 170, 80, 24));
        label_162 = new QLabel(frmUtilPower);
        label_162->setObjectName("label_162");
        label_162->setGeometry(QRect(10, 10, 131, 35));
        label_162->setFont(font1);
        label_163 = new QLabel(frmUtilPower);
        label_163->setObjectName("label_163");
        label_163->setGeometry(QRect(10, 55, 49, 16));
        label_163->setFont(font2);
        spnUtilPowerWood = new QSpinBox(frmUtilPower);
        spnUtilPowerWood->setObjectName("spnUtilPowerWood");
        spnUtilPowerWood->setEnabled(false);
        spnUtilPowerWood->setGeometry(QRect(90, 120, 71, 25));
        spnUtilPowerWood->setButtonSymbols(QAbstractSpinBox::NoButtons);
        spnUtilPowerWood->setMinimum(0);
        spnUtilPowerWood->setMaximum(1000000);
        label_164 = new QLabel(frmUtilPower);
        label_164->setObjectName("label_164");
        label_164->setGeometry(QRect(30, 120, 49, 16));
        label_164->setFont(font3);
        spnUtilPowerSteel = new QSpinBox(frmUtilPower);
        spnUtilPowerSteel->setObjectName("spnUtilPowerSteel");
        spnUtilPowerSteel->setEnabled(false);
        spnUtilPowerSteel->setGeometry(QRect(250, 90, 71, 25));
        spnUtilPowerSteel->setButtonSymbols(QAbstractSpinBox::NoButtons);
        spnUtilPowerSteel->setMinimum(0);
        spnUtilPowerSteel->setMaximum(1000000);
        label_165 = new QLabel(frmUtilPower);
        label_165->setObjectName("label_165");
        label_165->setGeometry(QRect(180, 90, 49, 16));
        label_165->setFont(font3);
        label_166 = new QLabel(frmUtilPower);
        label_166->setObjectName("label_166");
        label_166->setGeometry(QRect(180, 120, 71, 16));
        label_166->setFont(font3);
        spnUtilPowerConcrete = new QSpinBox(frmUtilPower);
        spnUtilPowerConcrete->setObjectName("spnUtilPowerConcrete");
        spnUtilPowerConcrete->setEnabled(false);
        spnUtilPowerConcrete->setGeometry(QRect(250, 120, 71, 25));
        spnUtilPowerConcrete->setButtonSymbols(QAbstractSpinBox::NoButtons);
        spnUtilPowerConcrete->setMinimum(0);
        spnUtilPowerConcrete->setMaximum(1000000);
        spnUtilPowerCost = new QSpinBox(frmUtilPower);
        spnUtilPowerCost->setObjectName("spnUtilPowerCost");
        spnUtilPowerCost->setEnabled(false);
        spnUtilPowerCost->setGeometry(QRect(90, 90, 71, 25));
        spnUtilPowerCost->setButtonSymbols(QAbstractSpinBox::NoButtons);
        spnUtilPowerCost->setMinimum(0);
        spnUtilPowerCost->setMaximum(1000000);
        label_167 = new QLabel(frmUtilPower);
        label_167->setObjectName("label_167");
        label_167->setGeometry(QRect(30, 90, 49, 16));
        label_167->setFont(font3);
        label_168 = new QLabel(frmUtilPower);
        label_168->setObjectName("label_168");
        label_168->setGeometry(QRect(170, 0, 201, 41));
        label_168->setFont(font3);

        horizontalLayout_13->addWidget(frmUtilPower);

        frmUtilWater = new QFrame(scrollAreaWidgetContents_8);
        frmUtilWater->setObjectName("frmUtilWater");
        frmUtilWater->setMinimumSize(QSize(370, 0));
        frmUtilWater->setMaximumSize(QSize(370, 16777215));
        frmUtilWater->setStyleSheet(QString::fromUtf8("#frmUtilWater {\n"
"	background-color: rgb(211, 211, 211);\n"
"	border: 2px solid black;\n"
"}"));
        frmUtilWater->setFrameShape(QFrame::StyledPanel);
        frmUtilWater->setFrameShadow(QFrame::Raised);
        btnUtilWater = new QPushButton(frmUtilWater);
        btnUtilWater->setObjectName("btnUtilWater");
        btnUtilWater->setGeometry(QRect(140, 170, 80, 24));
        label_333 = new QLabel(frmUtilWater);
        label_333->setObjectName("label_333");
        label_333->setGeometry(QRect(10, 10, 151, 35));
        label_333->setFont(font1);
        label_334 = new QLabel(frmUtilWater);
        label_334->setObjectName("label_334");
        label_334->setGeometry(QRect(10, 55, 49, 16));
        label_334->setFont(font2);
        spnUtilWaterWood = new QSpinBox(frmUtilWater);
        spnUtilWaterWood->setObjectName("spnUtilWaterWood");
        spnUtilWaterWood->setEnabled(false);
        spnUtilWaterWood->setGeometry(QRect(90, 120, 71, 25));
        spnUtilWaterWood->setButtonSymbols(QAbstractSpinBox::NoButtons);
        spnUtilWaterWood->setMinimum(0);
        spnUtilWaterWood->setMaximum(1000000);
        label_335 = new QLabel(frmUtilWater);
        label_335->setObjectName("label_335");
        label_335->setGeometry(QRect(30, 120, 49, 16));
        label_335->setFont(font3);
        spnUtilWaterSteel = new QSpinBox(frmUtilWater);
        spnUtilWaterSteel->setObjectName("spnUtilWaterSteel");
        spnUtilWaterSteel->setEnabled(false);
        spnUtilWaterSteel->setGeometry(QRect(250, 90, 71, 25));
        spnUtilWaterSteel->setButtonSymbols(QAbstractSpinBox::NoButtons);
        spnUtilWaterSteel->setMinimum(0);
        spnUtilWaterSteel->setMaximum(1000000);
        label_336 = new QLabel(frmUtilWater);
        label_336->setObjectName("label_336");
        label_336->setGeometry(QRect(180, 90, 49, 16));
        label_336->setFont(font3);
        label_337 = new QLabel(frmUtilWater);
        label_337->setObjectName("label_337");
        label_337->setGeometry(QRect(180, 120, 71, 16));
        label_337->setFont(font3);
        spnUtilWaterConcrete = new QSpinBox(frmUtilWater);
        spnUtilWaterConcrete->setObjectName("spnUtilWaterConcrete");
        spnUtilWaterConcrete->setEnabled(false);
        spnUtilWaterConcrete->setGeometry(QRect(250, 120, 71, 25));
        spnUtilWaterConcrete->setButtonSymbols(QAbstractSpinBox::NoButtons);
        spnUtilWaterConcrete->setMinimum(0);
        spnUtilWaterConcrete->setMaximum(1000000);
        spnUtilWaterCost = new QSpinBox(frmUtilWater);
        spnUtilWaterCost->setObjectName("spnUtilWaterCost");
        spnUtilWaterCost->setEnabled(false);
        spnUtilWaterCost->setGeometry(QRect(90, 90, 71, 25));
        spnUtilWaterCost->setButtonSymbols(QAbstractSpinBox::NoButtons);
        spnUtilWaterCost->setMinimum(0);
        spnUtilWaterCost->setMaximum(1000000);
        label_338 = new QLabel(frmUtilWater);
        label_338->setObjectName("label_338");
        label_338->setGeometry(QRect(30, 90, 49, 16));
        label_338->setFont(font3);
        label_339 = new QLabel(frmUtilWater);
        label_339->setObjectName("label_339");
        label_339->setGeometry(QRect(200, 0, 171, 41));
        label_339->setFont(font3);

        horizontalLayout_13->addWidget(frmUtilWater);

        frmUtilSewage = new QFrame(scrollAreaWidgetContents_8);
        frmUtilSewage->setObjectName("frmUtilSewage");
        frmUtilSewage->setMinimumSize(QSize(370, 0));
        frmUtilSewage->setMaximumSize(QSize(370, 16777215));
        frmUtilSewage->setStyleSheet(QString::fromUtf8("#frmUtilSewage{\n"
"	background-color: rgb(211, 211, 211);\n"
"	border: 2px solid black;\n"
"}"));
        frmUtilSewage->setFrameShape(QFrame::StyledPanel);
        frmUtilSewage->setFrameShadow(QFrame::Raised);
        btnUtilSewage = new QPushButton(frmUtilSewage);
        btnUtilSewage->setObjectName("btnUtilSewage");
        btnUtilSewage->setGeometry(QRect(140, 170, 80, 24));
        label_319 = new QLabel(frmUtilSewage);
        label_319->setObjectName("label_319");
        label_319->setGeometry(QRect(10, 10, 171, 35));
        label_319->setFont(font1);
        label_320 = new QLabel(frmUtilSewage);
        label_320->setObjectName("label_320");
        label_320->setGeometry(QRect(10, 55, 49, 16));
        label_320->setFont(font2);
        spnUtilSewageWood = new QSpinBox(frmUtilSewage);
        spnUtilSewageWood->setObjectName("spnUtilSewageWood");
        spnUtilSewageWood->setEnabled(false);
        spnUtilSewageWood->setGeometry(QRect(90, 120, 71, 25));
        spnUtilSewageWood->setButtonSymbols(QAbstractSpinBox::NoButtons);
        spnUtilSewageWood->setMinimum(0);
        spnUtilSewageWood->setMaximum(1000000);
        label_321 = new QLabel(frmUtilSewage);
        label_321->setObjectName("label_321");
        label_321->setGeometry(QRect(30, 120, 49, 16));
        label_321->setFont(font3);
        spnUtilSewageSteel = new QSpinBox(frmUtilSewage);
        spnUtilSewageSteel->setObjectName("spnUtilSewageSteel");
        spnUtilSewageSteel->setEnabled(false);
        spnUtilSewageSteel->setGeometry(QRect(250, 90, 71, 25));
        spnUtilSewageSteel->setButtonSymbols(QAbstractSpinBox::NoButtons);
        spnUtilSewageSteel->setMinimum(0);
        spnUtilSewageSteel->setMaximum(1000000);
        label_322 = new QLabel(frmUtilSewage);
        label_322->setObjectName("label_322");
        label_322->setGeometry(QRect(180, 90, 49, 16));
        label_322->setFont(font3);
        label_323 = new QLabel(frmUtilSewage);
        label_323->setObjectName("label_323");
        label_323->setGeometry(QRect(180, 120, 71, 16));
        label_323->setFont(font3);
        spnUtilSewageConcrete = new QSpinBox(frmUtilSewage);
        spnUtilSewageConcrete->setObjectName("spnUtilSewageConcrete");
        spnUtilSewageConcrete->setEnabled(false);
        spnUtilSewageConcrete->setGeometry(QRect(250, 120, 71, 25));
        spnUtilSewageConcrete->setButtonSymbols(QAbstractSpinBox::NoButtons);
        spnUtilSewageConcrete->setMinimum(0);
        spnUtilSewageConcrete->setMaximum(1000000);
        spnUtilSewageCost = new QSpinBox(frmUtilSewage);
        spnUtilSewageCost->setObjectName("spnUtilSewageCost");
        spnUtilSewageCost->setEnabled(false);
        spnUtilSewageCost->setGeometry(QRect(90, 90, 71, 25));
        spnUtilSewageCost->setButtonSymbols(QAbstractSpinBox::NoButtons);
        spnUtilSewageCost->setMinimum(0);
        spnUtilSewageCost->setMaximum(1000000);
        label_324 = new QLabel(frmUtilSewage);
        label_324->setObjectName("label_324");
        label_324->setGeometry(QRect(30, 90, 49, 16));
        label_324->setFont(font3);

        horizontalLayout_13->addWidget(frmUtilSewage);

        frmUtilWaste = new QFrame(scrollAreaWidgetContents_8);
        frmUtilWaste->setObjectName("frmUtilWaste");
        frmUtilWaste->setMinimumSize(QSize(370, 0));
        frmUtilWaste->setMaximumSize(QSize(370, 16777215));
        frmUtilWaste->setStyleSheet(QString::fromUtf8("#frmUtilWaste {\n"
"	background-color: rgb(211, 211, 211);\n"
"	border: 2px solid black;\n"
"}"));
        frmUtilWaste->setFrameShape(QFrame::StyledPanel);
        frmUtilWaste->setFrameShadow(QFrame::Raised);
        btnUtilWaste = new QPushButton(frmUtilWaste);
        btnUtilWaste->setObjectName("btnUtilWaste");
        btnUtilWaste->setGeometry(QRect(140, 170, 80, 24));
        label_125 = new QLabel(frmUtilWaste);
        label_125->setObjectName("label_125");
        label_125->setGeometry(QRect(10, 10, 221, 35));
        label_125->setFont(font1);
        label_126 = new QLabel(frmUtilWaste);
        label_126->setObjectName("label_126");
        label_126->setGeometry(QRect(10, 55, 49, 16));
        label_126->setFont(font2);
        spnUtilWasteWood = new QSpinBox(frmUtilWaste);
        spnUtilWasteWood->setObjectName("spnUtilWasteWood");
        spnUtilWasteWood->setEnabled(false);
        spnUtilWasteWood->setGeometry(QRect(90, 120, 71, 25));
        spnUtilWasteWood->setButtonSymbols(QAbstractSpinBox::NoButtons);
        spnUtilWasteWood->setMinimum(0);
        spnUtilWasteWood->setMaximum(1000000);
        label_133 = new QLabel(frmUtilWaste);
        label_133->setObjectName("label_133");
        label_133->setGeometry(QRect(30, 120, 49, 16));
        label_133->setFont(font3);
        spnUtilWasteSteel = new QSpinBox(frmUtilWaste);
        spnUtilWasteSteel->setObjectName("spnUtilWasteSteel");
        spnUtilWasteSteel->setEnabled(false);
        spnUtilWasteSteel->setGeometry(QRect(250, 90, 71, 25));
        spnUtilWasteSteel->setButtonSymbols(QAbstractSpinBox::NoButtons);
        spnUtilWasteSteel->setMinimum(0);
        spnUtilWasteSteel->setMaximum(1000000);
        label_134 = new QLabel(frmUtilWaste);
        label_134->setObjectName("label_134");
        label_134->setGeometry(QRect(180, 90, 49, 16));
        label_134->setFont(font3);
        label_159 = new QLabel(frmUtilWaste);
        label_159->setObjectName("label_159");
        label_159->setGeometry(QRect(180, 120, 71, 16));
        label_159->setFont(font3);
        spnUtilWasteConcrete = new QSpinBox(frmUtilWaste);
        spnUtilWasteConcrete->setObjectName("spnUtilWasteConcrete");
        spnUtilWasteConcrete->setEnabled(false);
        spnUtilWasteConcrete->setGeometry(QRect(250, 120, 71, 25));
        spnUtilWasteConcrete->setButtonSymbols(QAbstractSpinBox::NoButtons);
        spnUtilWasteConcrete->setMinimum(0);
        spnUtilWasteConcrete->setMaximum(1000000);
        spnUtilWasteCost = new QSpinBox(frmUtilWaste);
        spnUtilWasteCost->setObjectName("spnUtilWasteCost");
        spnUtilWasteCost->setEnabled(false);
        spnUtilWasteCost->setGeometry(QRect(90, 90, 71, 25));
        spnUtilWasteCost->setButtonSymbols(QAbstractSpinBox::NoButtons);
        spnUtilWasteCost->setMinimum(0);
        spnUtilWasteCost->setMaximum(1000000);
        label_160 = new QLabel(frmUtilWaste);
        label_160->setObjectName("label_160");
        label_160->setGeometry(QRect(30, 90, 49, 16));
        label_160->setFont(font3);

        horizontalLayout_13->addWidget(frmUtilWaste);

        scrollArea_7->setWidget(scrollAreaWidgetContents_8);

        horizontalLayout_11->addWidget(scrollArea_7);

        tabBuildCity->addTab(tab_2, QString());
        tab_5 = new QWidget();
        tab_5->setObjectName("tab_5");
        horizontalLayout_23 = new QHBoxLayout(tab_5);
        horizontalLayout_23->setObjectName("horizontalLayout_23");
        scrollArea_6 = new QScrollArea(tab_5);
        scrollArea_6->setObjectName("scrollArea_6");
        scrollArea_6->setWidgetResizable(true);
        scrollAreaWidgetContents_7 = new QWidget();
        scrollAreaWidgetContents_7->setObjectName("scrollAreaWidgetContents_7");
        scrollAreaWidgetContents_7->setGeometry(QRect(0, 0, 1297, 250));
        horizontalLayout_12 = new QHBoxLayout(scrollAreaWidgetContents_7);
        horizontalLayout_12->setObjectName("horizontalLayout_12");
        frmRoadRes = new QFrame(scrollAreaWidgetContents_7);
        frmRoadRes->setObjectName("frmRoadRes");
        frmRoadRes->setMinimumSize(QSize(370, 0));
        frmRoadRes->setMaximumSize(QSize(370, 16777215));
        frmRoadRes->setStyleSheet(QString::fromUtf8("#frmRoadRes {\n"
"	background-color: rgb(211, 211, 211);\n"
"	border: 2px solid black;\n"
"}"));
        frmRoadRes->setFrameShape(QFrame::StyledPanel);
        frmRoadRes->setFrameShadow(QFrame::Raised);
        btnRoadRes = new QPushButton(frmRoadRes);
        btnRoadRes->setObjectName("btnRoadRes");
        btnRoadRes->setGeometry(QRect(140, 170, 80, 24));
        label_345 = new QLabel(frmRoadRes);
        label_345->setObjectName("label_345");
        label_345->setGeometry(QRect(10, 10, 191, 35));
        label_345->setFont(font1);
        label_346 = new QLabel(frmRoadRes);
        label_346->setObjectName("label_346");
        label_346->setGeometry(QRect(10, 55, 49, 16));
        label_346->setFont(font2);
        spnRoadResWood = new QSpinBox(frmRoadRes);
        spnRoadResWood->setObjectName("spnRoadResWood");
        spnRoadResWood->setEnabled(false);
        spnRoadResWood->setGeometry(QRect(90, 120, 71, 25));
        spnRoadResWood->setButtonSymbols(QAbstractSpinBox::NoButtons);
        spnRoadResWood->setMinimum(0);
        spnRoadResWood->setMaximum(1000000);
        label_347 = new QLabel(frmRoadRes);
        label_347->setObjectName("label_347");
        label_347->setGeometry(QRect(30, 120, 49, 16));
        label_347->setFont(font3);
        spnRoadResSteel = new QSpinBox(frmRoadRes);
        spnRoadResSteel->setObjectName("spnRoadResSteel");
        spnRoadResSteel->setEnabled(false);
        spnRoadResSteel->setGeometry(QRect(250, 90, 71, 25));
        spnRoadResSteel->setButtonSymbols(QAbstractSpinBox::NoButtons);
        spnRoadResSteel->setMinimum(0);
        spnRoadResSteel->setMaximum(1000000);
        label_348 = new QLabel(frmRoadRes);
        label_348->setObjectName("label_348");
        label_348->setGeometry(QRect(180, 90, 49, 16));
        label_348->setFont(font3);
        label_349 = new QLabel(frmRoadRes);
        label_349->setObjectName("label_349");
        label_349->setGeometry(QRect(180, 120, 71, 16));
        label_349->setFont(font3);
        spnRoadResConcrete = new QSpinBox(frmRoadRes);
        spnRoadResConcrete->setObjectName("spnRoadResConcrete");
        spnRoadResConcrete->setEnabled(false);
        spnRoadResConcrete->setGeometry(QRect(250, 120, 71, 25));
        spnRoadResConcrete->setButtonSymbols(QAbstractSpinBox::NoButtons);
        spnRoadResConcrete->setMinimum(0);
        spnRoadResConcrete->setMaximum(1000000);
        spnRoadResCost = new QSpinBox(frmRoadRes);
        spnRoadResCost->setObjectName("spnRoadResCost");
        spnRoadResCost->setEnabled(false);
        spnRoadResCost->setGeometry(QRect(90, 90, 71, 25));
        spnRoadResCost->setButtonSymbols(QAbstractSpinBox::NoButtons);
        spnRoadResCost->setMinimum(0);
        spnRoadResCost->setMaximum(1000000);
        label_350 = new QLabel(frmRoadRes);
        label_350->setObjectName("label_350");
        label_350->setGeometry(QRect(30, 90, 49, 16));
        label_350->setFont(font3);

        horizontalLayout_12->addWidget(frmRoadRes);

        frmRoadMain = new QFrame(scrollAreaWidgetContents_7);
        frmRoadMain->setObjectName("frmRoadMain");
        frmRoadMain->setMinimumSize(QSize(370, 0));
        frmRoadMain->setMaximumSize(QSize(370, 16777215));
        frmRoadMain->setStyleSheet(QString::fromUtf8("#frmRoadMain {\n"
"	background-color: rgb(211, 211, 211);\n"
"	border: 2px solid black;\n"
"}"));
        frmRoadMain->setFrameShape(QFrame::StyledPanel);
        frmRoadMain->setFrameShadow(QFrame::Raised);
        btnRoadMain = new QPushButton(frmRoadMain);
        btnRoadMain->setObjectName("btnRoadMain");
        btnRoadMain->setGeometry(QRect(140, 170, 80, 24));
        label_352 = new QLabel(frmRoadMain);
        label_352->setObjectName("label_352");
        label_352->setGeometry(QRect(10, 10, 151, 35));
        label_352->setFont(font1);
        label_353 = new QLabel(frmRoadMain);
        label_353->setObjectName("label_353");
        label_353->setGeometry(QRect(10, 55, 49, 16));
        label_353->setFont(font2);
        spnRoadMainWood = new QSpinBox(frmRoadMain);
        spnRoadMainWood->setObjectName("spnRoadMainWood");
        spnRoadMainWood->setEnabled(false);
        spnRoadMainWood->setGeometry(QRect(90, 120, 71, 25));
        spnRoadMainWood->setButtonSymbols(QAbstractSpinBox::NoButtons);
        spnRoadMainWood->setMinimum(0);
        spnRoadMainWood->setMaximum(1000000);
        label_354 = new QLabel(frmRoadMain);
        label_354->setObjectName("label_354");
        label_354->setGeometry(QRect(30, 120, 49, 16));
        label_354->setFont(font3);
        spnRoadMainSteel = new QSpinBox(frmRoadMain);
        spnRoadMainSteel->setObjectName("spnRoadMainSteel");
        spnRoadMainSteel->setEnabled(false);
        spnRoadMainSteel->setGeometry(QRect(250, 90, 71, 25));
        spnRoadMainSteel->setButtonSymbols(QAbstractSpinBox::NoButtons);
        spnRoadMainSteel->setMinimum(0);
        spnRoadMainSteel->setMaximum(1000000);
        label_355 = new QLabel(frmRoadMain);
        label_355->setObjectName("label_355");
        label_355->setGeometry(QRect(180, 90, 49, 16));
        label_355->setFont(font3);
        label_356 = new QLabel(frmRoadMain);
        label_356->setObjectName("label_356");
        label_356->setGeometry(QRect(180, 120, 71, 16));
        label_356->setFont(font3);
        spnRoadMainConcrete = new QSpinBox(frmRoadMain);
        spnRoadMainConcrete->setObjectName("spnRoadMainConcrete");
        spnRoadMainConcrete->setEnabled(false);
        spnRoadMainConcrete->setGeometry(QRect(250, 120, 71, 25));
        spnRoadMainConcrete->setButtonSymbols(QAbstractSpinBox::NoButtons);
        spnRoadMainConcrete->setMinimum(0);
        spnRoadMainConcrete->setMaximum(1000000);
        spnRoadMainCost = new QSpinBox(frmRoadMain);
        spnRoadMainCost->setObjectName("spnRoadMainCost");
        spnRoadMainCost->setEnabled(false);
        spnRoadMainCost->setGeometry(QRect(90, 90, 71, 25));
        spnRoadMainCost->setButtonSymbols(QAbstractSpinBox::NoButtons);
        spnRoadMainCost->setMinimum(0);
        spnRoadMainCost->setMaximum(1000000);
        label_357 = new QLabel(frmRoadMain);
        label_357->setObjectName("label_357");
        label_357->setGeometry(QRect(30, 90, 49, 16));
        label_357->setFont(font3);

        horizontalLayout_12->addWidget(frmRoadMain);

        frmRoadHighway = new QFrame(scrollAreaWidgetContents_7);
        frmRoadHighway->setObjectName("frmRoadHighway");
        frmRoadHighway->setMinimumSize(QSize(370, 0));
        frmRoadHighway->setMaximumSize(QSize(370, 16777215));
        frmRoadHighway->setStyleSheet(QString::fromUtf8("#frmRoadHighway{\n"
"	background-color: rgb(211, 211, 211);\n"
"	border: 2px solid black;\n"
"}"));
        frmRoadHighway->setFrameShape(QFrame::StyledPanel);
        frmRoadHighway->setFrameShadow(QFrame::Raised);
        btnRoadHighway = new QPushButton(frmRoadHighway);
        btnRoadHighway->setObjectName("btnRoadHighway");
        btnRoadHighway->setGeometry(QRect(140, 170, 80, 24));
        lblRoadHighway = new QLabel(frmRoadHighway);
        lblRoadHighway->setObjectName("lblRoadHighway");
        lblRoadHighway->setGeometry(QRect(10, 10, 171, 35));
        lblRoadHighway->setFont(font1);
        label_340 = new QLabel(frmRoadHighway);
        label_340->setObjectName("label_340");
        label_340->setGeometry(QRect(10, 55, 49, 16));
        label_340->setFont(font2);
        spnRoadHighwayWood = new QSpinBox(frmRoadHighway);
        spnRoadHighwayWood->setObjectName("spnRoadHighwayWood");
        spnRoadHighwayWood->setEnabled(false);
        spnRoadHighwayWood->setGeometry(QRect(90, 120, 71, 25));
        spnRoadHighwayWood->setButtonSymbols(QAbstractSpinBox::NoButtons);
        spnRoadHighwayWood->setMinimum(0);
        spnRoadHighwayWood->setMaximum(1000000);
        label_341 = new QLabel(frmRoadHighway);
        label_341->setObjectName("label_341");
        label_341->setGeometry(QRect(30, 120, 49, 16));
        label_341->setFont(font3);
        spnRoadHighwaySteel = new QSpinBox(frmRoadHighway);
        spnRoadHighwaySteel->setObjectName("spnRoadHighwaySteel");
        spnRoadHighwaySteel->setEnabled(false);
        spnRoadHighwaySteel->setGeometry(QRect(250, 90, 71, 25));
        spnRoadHighwaySteel->setButtonSymbols(QAbstractSpinBox::NoButtons);
        spnRoadHighwaySteel->setMinimum(0);
        spnRoadHighwaySteel->setMaximum(1000000);
        label_342 = new QLabel(frmRoadHighway);
        label_342->setObjectName("label_342");
        label_342->setGeometry(QRect(180, 90, 49, 16));
        label_342->setFont(font3);
        label_343 = new QLabel(frmRoadHighway);
        label_343->setObjectName("label_343");
        label_343->setGeometry(QRect(180, 120, 71, 16));
        label_343->setFont(font3);
        spnRoadHighwayConcrete = new QSpinBox(frmRoadHighway);
        spnRoadHighwayConcrete->setObjectName("spnRoadHighwayConcrete");
        spnRoadHighwayConcrete->setEnabled(false);
        spnRoadHighwayConcrete->setGeometry(QRect(250, 120, 71, 25));
        spnRoadHighwayConcrete->setButtonSymbols(QAbstractSpinBox::NoButtons);
        spnRoadHighwayConcrete->setMinimum(0);
        spnRoadHighwayConcrete->setMaximum(1000000);
        spnRoadHighwayCost = new QSpinBox(frmRoadHighway);
        spnRoadHighwayCost->setObjectName("spnRoadHighwayCost");
        spnRoadHighwayCost->setEnabled(false);
        spnRoadHighwayCost->setGeometry(QRect(90, 90, 71, 25));
        spnRoadHighwayCost->setButtonSymbols(QAbstractSpinBox::NoButtons);
        spnRoadHighwayCost->setMinimum(0);
        spnRoadHighwayCost->setMaximum(1000000);
        label_344 = new QLabel(frmRoadHighway);
        label_344->setObjectName("label_344");
        label_344->setGeometry(QRect(30, 90, 49, 16));
        label_344->setFont(font3);

        horizontalLayout_12->addWidget(frmRoadHighway);

        scrollArea_6->setWidget(scrollAreaWidgetContents_7);

        horizontalLayout_23->addWidget(scrollArea_6);

        tabBuildCity->addTab(tab_5, QString());

        verticalLayout_2->addWidget(tabBuildCity);


        horizontalLayout_14->addLayout(verticalLayout_2);

        tbConsoleOut = new QTextBrowser(centralwidget);
        tbConsoleOut->setObjectName("tbConsoleOut");
        tbConsoleOut->setMinimumSize(QSize(300, 0));
        tbConsoleOut->setMaximumSize(QSize(300, 16777215));
        tbConsoleOut->setStyleSheet(QString::fromUtf8("background-color: rgb(24, 24, 24);"));

        horizontalLayout_14->addWidget(tbConsoleOut);

        HomePage->setCentralWidget(centralwidget);

        retranslateUi(HomePage);

        tabBuildCity->setCurrentIndex(0);
        tabBuildBuildings->setCurrentIndex(0);


        QMetaObject::connectSlotsByName(HomePage);
    } // setupUi

    void retranslateUi(QMainWindow *HomePage)
    {
        HomePage->setWindowTitle(QCoreApplication::translate("HomePage", "HomePage", nullptr));
        btnCancelRoad->setText(QCoreApplication::translate("HomePage", "Cancel", nullptr));
        label_174->setText(QCoreApplication::translate("HomePage", "Position Fine Tuning:", nullptr));
        label_175->setText(QCoreApplication::translate("HomePage", "Length:", nullptr));
        label_176->setText(QCoreApplication::translate("HomePage", "Orientation:", nullptr));
        label_178->setText(QCoreApplication::translate("HomePage", "Current Y:", nullptr));
        cmbRoadOrientation->setItemText(0, QCoreApplication::translate("HomePage", "Horizontal", nullptr));
        cmbRoadOrientation->setItemText(1, QCoreApplication::translate("HomePage", "Vertical", nullptr));

        btnBuildRoad->setText(QCoreApplication::translate("HomePage", "Done", nullptr));
        label_177->setText(QCoreApplication::translate("HomePage", "Current X:", nullptr));
        progWater->setFormat(QCoreApplication::translate("HomePage", "%p%", nullptr));
        label_23->setText(QCoreApplication::translate("HomePage", "Water Usage:", nullptr));
        label_3->setText(QCoreApplication::translate("HomePage", "Overall Happiness:", nullptr));
        progHappiness->setFormat(QCoreApplication::translate("HomePage", "%p%", nullptr));
        label_2->setText(QCoreApplication::translate("HomePage", "Population:", nullptr));
        label->setText(QCoreApplication::translate("HomePage", "Cash:", nullptr));
        label_22->setText(QCoreApplication::translate("HomePage", "Electricity Usage:", nullptr));
        progElectricity->setFormat(QCoreApplication::translate("HomePage", "%p%", nullptr));
        label_12->setText(QCoreApplication::translate("HomePage", "Steel Units:", nullptr));
        label_25->setText(QCoreApplication::translate("HomePage", "Concrete Units:", nullptr));
        label_26->setText(QCoreApplication::translate("HomePage", "Wood Units:", nullptr));
        lblTitle->setText(QCoreApplication::translate("HomePage", "City Builder", nullptr));
        label_179->setText(QCoreApplication::translate("HomePage", "Government:", nullptr));
        cmbLawType->setItemText(0, QCoreApplication::translate("HomePage", "Money Law", nullptr));
        cmbLawType->setItemText(1, QCoreApplication::translate("HomePage", "Happiness Law", nullptr));
        cmbLawType->setItemText(2, QCoreApplication::translate("HomePage", "Bus Law", nullptr));
        cmbLawType->setItemText(3, QCoreApplication::translate("HomePage", "No Tax Law", nullptr));
        cmbLawType->setItemText(4, QCoreApplication::translate("HomePage", "Services Law", nullptr));

        label_180->setText(QCoreApplication::translate("HomePage", "Laws:", nullptr));
        btnEnactLaw->setText(QCoreApplication::translate("HomePage", "Toggle", nullptr));
        btnCancelBuilding->setText(QCoreApplication::translate("HomePage", "Cancel", nullptr));
        btnBuildBuilding->setText(QCoreApplication::translate("HomePage", "Done", nullptr));
        label_14->setText(QCoreApplication::translate("HomePage", "Current X:", nullptr));
        label_7->setText(QCoreApplication::translate("HomePage", "Building Color:", nullptr));
        label_15->setText(QCoreApplication::translate("HomePage", "Current Y:", nullptr));
        label_16->setText(QCoreApplication::translate("HomePage", "Position Fine Tuning:", nullptr));
        label_17->setText(QCoreApplication::translate("HomePage", "Current Width:", nullptr));
        cmbBuildingColor->setItemText(0, QCoreApplication::translate("HomePage", "Red", nullptr));
        cmbBuildingColor->setItemText(1, QCoreApplication::translate("HomePage", "Green", nullptr));
        cmbBuildingColor->setItemText(2, QCoreApplication::translate("HomePage", "Blue", nullptr));
        cmbBuildingColor->setItemText(3, QCoreApplication::translate("HomePage", "Orange", nullptr));
        cmbBuildingColor->setItemText(4, QCoreApplication::translate("HomePage", "Yellow", nullptr));
        cmbBuildingColor->setItemText(5, QCoreApplication::translate("HomePage", "Black", nullptr));
        cmbBuildingColor->setItemText(6, QCoreApplication::translate("HomePage", "White", nullptr));
        cmbBuildingColor->setItemText(7, QCoreApplication::translate("HomePage", "Grey", nullptr));
        cmbBuildingColor->setItemText(8, QCoreApplication::translate("HomePage", "Cream", nullptr));

        label_24->setText(QCoreApplication::translate("HomePage", "Current Height:", nullptr));
        btnResFlat->setText(QCoreApplication::translate("HomePage", "Create", nullptr));
        label_4->setText(QCoreApplication::translate("HomePage", "Flat:", nullptr));
        label_5->setText(QCoreApplication::translate("HomePage", "Cost:", nullptr));
        label_13->setText(QCoreApplication::translate("HomePage", "Wood:", nullptr));
        label_18->setText(QCoreApplication::translate("HomePage", "Steel:", nullptr));
        label_19->setText(QCoreApplication::translate("HomePage", "Concrete:", nullptr));
        label_20->setText(QCoreApplication::translate("HomePage", "Cash:", nullptr));
        label_6->setText(QCoreApplication::translate("HomePage", "Max population +5", nullptr));
        btnResTownHouse->setText(QCoreApplication::translate("HomePage", "Create", nullptr));
        label_21->setText(QCoreApplication::translate("HomePage", "Town House:", nullptr));
        label_27->setText(QCoreApplication::translate("HomePage", "Cost:", nullptr));
        label_28->setText(QCoreApplication::translate("HomePage", "Wood:", nullptr));
        label_29->setText(QCoreApplication::translate("HomePage", "Steel:", nullptr));
        label_30->setText(QCoreApplication::translate("HomePage", "Concrete:", nullptr));
        label_31->setText(QCoreApplication::translate("HomePage", "Cash:", nullptr));
        label_32->setText(QCoreApplication::translate("HomePage", "Max population +10", nullptr));
        btnResHouse->setText(QCoreApplication::translate("HomePage", "Create", nullptr));
        label_33->setText(QCoreApplication::translate("HomePage", "House:", nullptr));
        label_34->setText(QCoreApplication::translate("HomePage", "Cost:", nullptr));
        label_35->setText(QCoreApplication::translate("HomePage", "Wood:", nullptr));
        label_36->setText(QCoreApplication::translate("HomePage", "Steel:", nullptr));
        label_37->setText(QCoreApplication::translate("HomePage", "Concrete:", nullptr));
        label_38->setText(QCoreApplication::translate("HomePage", "Cash:", nullptr));
        label_39->setText(QCoreApplication::translate("HomePage", "Max population +20", nullptr));
        btnResEstate->setText(QCoreApplication::translate("HomePage", "Create", nullptr));
        label_40->setText(QCoreApplication::translate("HomePage", "Estate:", nullptr));
        label_41->setText(QCoreApplication::translate("HomePage", "Cost:", nullptr));
        label_42->setText(QCoreApplication::translate("HomePage", "Wood:", nullptr));
        label_43->setText(QCoreApplication::translate("HomePage", "Steel:", nullptr));
        label_44->setText(QCoreApplication::translate("HomePage", "Concrete:", nullptr));
        label_45->setText(QCoreApplication::translate("HomePage", "Cash:", nullptr));
        label_46->setText(QCoreApplication::translate("HomePage", "Max population +50", nullptr));
        tabBuildBuildings->setTabText(tabBuildBuildings->indexOf(tab_7), QCoreApplication::translate("HomePage", "Residential", nullptr));
        btnComShop->setText(QCoreApplication::translate("HomePage", "Create", nullptr));
        label_54->setText(QCoreApplication::translate("HomePage", "Shop:", nullptr));
        label_55->setText(QCoreApplication::translate("HomePage", "Cost:", nullptr));
        label_56->setText(QCoreApplication::translate("HomePage", "Wood:", nullptr));
        label_57->setText(QCoreApplication::translate("HomePage", "Steel:", nullptr));
        label_58->setText(QCoreApplication::translate("HomePage", "Concrete:", nullptr));
        label_59->setText(QCoreApplication::translate("HomePage", "Cash:", nullptr));
        label_60->setText(QCoreApplication::translate("HomePage", "Jobs +10", nullptr));
        label_76->setText(QCoreApplication::translate("HomePage", "Income +100", nullptr));
        btnComOffice->setText(QCoreApplication::translate("HomePage", "Create", nullptr));
        label_61->setText(QCoreApplication::translate("HomePage", "Office:", nullptr));
        label_62->setText(QCoreApplication::translate("HomePage", "Cost:", nullptr));
        label_63->setText(QCoreApplication::translate("HomePage", "Wood:", nullptr));
        label_64->setText(QCoreApplication::translate("HomePage", "Steel:", nullptr));
        label_65->setText(QCoreApplication::translate("HomePage", "Concrete:", nullptr));
        label_66->setText(QCoreApplication::translate("HomePage", "Cash:", nullptr));
        label_67->setText(QCoreApplication::translate("HomePage", "Jobs +20", nullptr));
        label_77->setText(QCoreApplication::translate("HomePage", "Income +200", nullptr));
        btnComMall->setText(QCoreApplication::translate("HomePage", "Create", nullptr));
        label_47->setText(QCoreApplication::translate("HomePage", "Mall:", nullptr));
        label_48->setText(QCoreApplication::translate("HomePage", "Cost:", nullptr));
        label_49->setText(QCoreApplication::translate("HomePage", "Wood:", nullptr));
        label_50->setText(QCoreApplication::translate("HomePage", "Steel:", nullptr));
        label_51->setText(QCoreApplication::translate("HomePage", "Concrete:", nullptr));
        label_52->setText(QCoreApplication::translate("HomePage", "Cash:", nullptr));
        label_53->setText(QCoreApplication::translate("HomePage", "Jobs +100", nullptr));
        label_75->setText(QCoreApplication::translate("HomePage", "Income +500", nullptr));
        tabBuildBuildings->setTabText(tabBuildBuildings->indexOf(tab_8), QCoreApplication::translate("HomePage", "Commercial", nullptr));
        btnIndFactory->setText(QCoreApplication::translate("HomePage", "Create", nullptr));
        label_68->setText(QCoreApplication::translate("HomePage", "Factory:", nullptr));
        label_69->setText(QCoreApplication::translate("HomePage", "Cost:", nullptr));
        label_70->setText(QCoreApplication::translate("HomePage", "Wood:", nullptr));
        label_71->setText(QCoreApplication::translate("HomePage", "Steel:", nullptr));
        label_72->setText(QCoreApplication::translate("HomePage", "Concrete:", nullptr));
        label_73->setText(QCoreApplication::translate("HomePage", "Cash:", nullptr));
        label_74->setText(QCoreApplication::translate("HomePage", "Wood Per Tick +5", nullptr));
        label_78->setText(QCoreApplication::translate("HomePage", "Jobs +10", nullptr));
        btnIndWarehouse->setText(QCoreApplication::translate("HomePage", "Create", nullptr));
        label_79->setText(QCoreApplication::translate("HomePage", "Warehouse:", nullptr));
        label_80->setText(QCoreApplication::translate("HomePage", "Cost:", nullptr));
        label_81->setText(QCoreApplication::translate("HomePage", "Wood:", nullptr));
        label_82->setText(QCoreApplication::translate("HomePage", "Steel:", nullptr));
        label_83->setText(QCoreApplication::translate("HomePage", "Concrete:", nullptr));
        label_84->setText(QCoreApplication::translate("HomePage", "Cash:", nullptr));
        label_85->setText(QCoreApplication::translate("HomePage", "Concrete Per Tick +5", nullptr));
        label_86->setText(QCoreApplication::translate("HomePage", "Jobs +10", nullptr));
        btnIndPlant->setText(QCoreApplication::translate("HomePage", "Create", nullptr));
        label_87->setText(QCoreApplication::translate("HomePage", "Industrial Plant:", nullptr));
        label_88->setText(QCoreApplication::translate("HomePage", "Cost:", nullptr));
        label_89->setText(QCoreApplication::translate("HomePage", "Wood:", nullptr));
        label_90->setText(QCoreApplication::translate("HomePage", "Steel:", nullptr));
        label_91->setText(QCoreApplication::translate("HomePage", "Concrete:", nullptr));
        label_92->setText(QCoreApplication::translate("HomePage", "Cash:", nullptr));
        label_93->setText(QCoreApplication::translate("HomePage", "Steel Per Tick +5", nullptr));
        label_94->setText(QCoreApplication::translate("HomePage", "Jobs +10", nullptr));
        tabBuildBuildings->setTabText(tabBuildBuildings->indexOf(tab_9), QCoreApplication::translate("HomePage", "Industrial", nullptr));
        btnLandPark->setText(QCoreApplication::translate("HomePage", "Create", nullptr));
        label_95->setText(QCoreApplication::translate("HomePage", "Park:", nullptr));
        label_96->setText(QCoreApplication::translate("HomePage", "Cost:", nullptr));
        label_97->setText(QCoreApplication::translate("HomePage", "Wood:", nullptr));
        label_98->setText(QCoreApplication::translate("HomePage", "Steel:", nullptr));
        label_99->setText(QCoreApplication::translate("HomePage", "Concrete:", nullptr));
        label_100->setText(QCoreApplication::translate("HomePage", "Cash:", nullptr));
        label_101->setText(QCoreApplication::translate("HomePage", "Happiness +5", nullptr));
        label_102->setText(QCoreApplication::translate("HomePage", "Jobs +10", nullptr));
        btnLandMonument->setText(QCoreApplication::translate("HomePage", "Create", nullptr));
        label_103->setText(QCoreApplication::translate("HomePage", "Monument:", nullptr));
        label_104->setText(QCoreApplication::translate("HomePage", "Cost:", nullptr));
        label_105->setText(QCoreApplication::translate("HomePage", "Wood:", nullptr));
        label_106->setText(QCoreApplication::translate("HomePage", "Steel:", nullptr));
        label_107->setText(QCoreApplication::translate("HomePage", "Concrete:", nullptr));
        label_108->setText(QCoreApplication::translate("HomePage", "Cash:", nullptr));
        label_109->setText(QCoreApplication::translate("HomePage", "Happiness +10", nullptr));
        label_110->setText(QCoreApplication::translate("HomePage", "Jobs +10", nullptr));
        btnLandCCenter->setText(QCoreApplication::translate("HomePage", "Create", nullptr));
        label_111->setText(QCoreApplication::translate("HomePage", "Community Center:", nullptr));
        label_112->setText(QCoreApplication::translate("HomePage", "Cost:", nullptr));
        label_113->setText(QCoreApplication::translate("HomePage", "Wood:", nullptr));
        label_114->setText(QCoreApplication::translate("HomePage", "Steel:", nullptr));
        label_115->setText(QCoreApplication::translate("HomePage", "Concrete:", nullptr));
        label_116->setText(QCoreApplication::translate("HomePage", "Cash:", nullptr));
        label_117->setText(QCoreApplication::translate("HomePage", "Happiness +15", nullptr));
        label_118->setText(QCoreApplication::translate("HomePage", "Jobs +10", nullptr));
        tabBuildBuildings->setTabText(tabBuildBuildings->indexOf(tab_10), QCoreApplication::translate("HomePage", "Landmarks", nullptr));
        btnServHospital->setText(QCoreApplication::translate("HomePage", "Create", nullptr));
        label_119->setText(QCoreApplication::translate("HomePage", "Hospital:", nullptr));
        label_120->setText(QCoreApplication::translate("HomePage", "Cost:", nullptr));
        label_121->setText(QCoreApplication::translate("HomePage", "Wood:", nullptr));
        label_122->setText(QCoreApplication::translate("HomePage", "Steel:", nullptr));
        label_123->setText(QCoreApplication::translate("HomePage", "Concrete:", nullptr));
        label_124->setText(QCoreApplication::translate("HomePage", "Cash:", nullptr));
        label_152->setText(QCoreApplication::translate("HomePage", "Happiness +5", nullptr));
        label_149->setText(QCoreApplication::translate("HomePage", "Jobs +20", nullptr));
        label_150->setText(QCoreApplication::translate("HomePage", "Income +50", nullptr));
        btnServEducation->setText(QCoreApplication::translate("HomePage", "Create", nullptr));
        label_127->setText(QCoreApplication::translate("HomePage", "Education:", nullptr));
        label_128->setText(QCoreApplication::translate("HomePage", "Cost:", nullptr));
        label_129->setText(QCoreApplication::translate("HomePage", "Wood:", nullptr));
        label_130->setText(QCoreApplication::translate("HomePage", "Steel:", nullptr));
        label_131->setText(QCoreApplication::translate("HomePage", "Concrete:", nullptr));
        label_132->setText(QCoreApplication::translate("HomePage", "Cash:", nullptr));
        label_153->setText(QCoreApplication::translate("HomePage", "Happiness +5", nullptr));
        label_154->setText(QCoreApplication::translate("HomePage", "Jobs +20", nullptr));
        label_155->setText(QCoreApplication::translate("HomePage", "Income +50", nullptr));
        btnServSecurity->setText(QCoreApplication::translate("HomePage", "Create", nullptr));
        label_143->setText(QCoreApplication::translate("HomePage", "Security:", nullptr));
        label_144->setText(QCoreApplication::translate("HomePage", "Cost:", nullptr));
        label_145->setText(QCoreApplication::translate("HomePage", "Wood:", nullptr));
        label_146->setText(QCoreApplication::translate("HomePage", "Steel:", nullptr));
        label_147->setText(QCoreApplication::translate("HomePage", "Concrete:", nullptr));
        label_148->setText(QCoreApplication::translate("HomePage", "Cash:", nullptr));
        label_156->setText(QCoreApplication::translate("HomePage", "Happiness +5", nullptr));
        label_157->setText(QCoreApplication::translate("HomePage", "Jobs +10", nullptr));
        label_158->setText(QCoreApplication::translate("HomePage", "Income +50", nullptr));
        btnServEntertainment->setText(QCoreApplication::translate("HomePage", "Create", nullptr));
        label_135->setText(QCoreApplication::translate("HomePage", "Entertainment:", nullptr));
        label_136->setText(QCoreApplication::translate("HomePage", "Cost:", nullptr));
        label_137->setText(QCoreApplication::translate("HomePage", "Wood:", nullptr));
        label_138->setText(QCoreApplication::translate("HomePage", "Steel:", nullptr));
        label_139->setText(QCoreApplication::translate("HomePage", "Concrete:", nullptr));
        label_140->setText(QCoreApplication::translate("HomePage", "Cash:", nullptr));
        label_141->setText(QCoreApplication::translate("HomePage", "Jobs +10", nullptr));
        label_142->setText(QCoreApplication::translate("HomePage", "Income +100", nullptr));
        label_151->setText(QCoreApplication::translate("HomePage", "Happiness +10", nullptr));
        tabBuildBuildings->setTabText(tabBuildBuildings->indexOf(tab_11), QCoreApplication::translate("HomePage", "Services", nullptr));
        tabBuildCity->setTabText(tabBuildCity->indexOf(tab), QCoreApplication::translate("HomePage", "Buildings", nullptr));
        btnUtilPower->setText(QCoreApplication::translate("HomePage", "Create", nullptr));
        label_162->setText(QCoreApplication::translate("HomePage", "Power Plant:", nullptr));
        label_163->setText(QCoreApplication::translate("HomePage", "Cost:", nullptr));
        label_164->setText(QCoreApplication::translate("HomePage", "Wood:", nullptr));
        label_165->setText(QCoreApplication::translate("HomePage", "Steel:", nullptr));
        label_166->setText(QCoreApplication::translate("HomePage", "Concrete:", nullptr));
        label_167->setText(QCoreApplication::translate("HomePage", "Cash:", nullptr));
        label_168->setText(QCoreApplication::translate("HomePage", "Electricity Generation +100", nullptr));
        btnUtilWater->setText(QCoreApplication::translate("HomePage", "Create", nullptr));
        label_333->setText(QCoreApplication::translate("HomePage", "Water Supply:", nullptr));
        label_334->setText(QCoreApplication::translate("HomePage", "Cost:", nullptr));
        label_335->setText(QCoreApplication::translate("HomePage", "Wood:", nullptr));
        label_336->setText(QCoreApplication::translate("HomePage", "Steel:", nullptr));
        label_337->setText(QCoreApplication::translate("HomePage", "Concrete:", nullptr));
        label_338->setText(QCoreApplication::translate("HomePage", "Cash:", nullptr));
        label_339->setText(QCoreApplication::translate("HomePage", "Water Generation +100", nullptr));
        btnUtilSewage->setText(QCoreApplication::translate("HomePage", "Create", nullptr));
        label_319->setText(QCoreApplication::translate("HomePage", "Sewage System:", nullptr));
        label_320->setText(QCoreApplication::translate("HomePage", "Cost:", nullptr));
        label_321->setText(QCoreApplication::translate("HomePage", "Wood:", nullptr));
        label_322->setText(QCoreApplication::translate("HomePage", "Steel:", nullptr));
        label_323->setText(QCoreApplication::translate("HomePage", "Concrete:", nullptr));
        label_324->setText(QCoreApplication::translate("HomePage", "Cash:", nullptr));
        btnUtilWaste->setText(QCoreApplication::translate("HomePage", "Create", nullptr));
        label_125->setText(QCoreApplication::translate("HomePage", "Waste Management:", nullptr));
        label_126->setText(QCoreApplication::translate("HomePage", "Cost:", nullptr));
        label_133->setText(QCoreApplication::translate("HomePage", "Wood:", nullptr));
        label_134->setText(QCoreApplication::translate("HomePage", "Steel:", nullptr));
        label_159->setText(QCoreApplication::translate("HomePage", "Concrete:", nullptr));
        label_160->setText(QCoreApplication::translate("HomePage", "Cash:", nullptr));
        tabBuildCity->setTabText(tabBuildCity->indexOf(tab_2), QCoreApplication::translate("HomePage", "Utilities", nullptr));
        btnRoadRes->setText(QCoreApplication::translate("HomePage", "Create", nullptr));
        label_345->setText(QCoreApplication::translate("HomePage", "Residential Street", nullptr));
        label_346->setText(QCoreApplication::translate("HomePage", "Cost:", nullptr));
        label_347->setText(QCoreApplication::translate("HomePage", "Wood:", nullptr));
        label_348->setText(QCoreApplication::translate("HomePage", "Steel:", nullptr));
        label_349->setText(QCoreApplication::translate("HomePage", "Concrete:", nullptr));
        label_350->setText(QCoreApplication::translate("HomePage", "Cash:", nullptr));
        btnRoadMain->setText(QCoreApplication::translate("HomePage", "Create", nullptr));
        label_352->setText(QCoreApplication::translate("HomePage", "Main Road", nullptr));
        label_353->setText(QCoreApplication::translate("HomePage", "Cost:", nullptr));
        label_354->setText(QCoreApplication::translate("HomePage", "Wood:", nullptr));
        label_355->setText(QCoreApplication::translate("HomePage", "Steel:", nullptr));
        label_356->setText(QCoreApplication::translate("HomePage", "Concrete:", nullptr));
        label_357->setText(QCoreApplication::translate("HomePage", "Cash:", nullptr));
        btnRoadHighway->setText(QCoreApplication::translate("HomePage", "Create", nullptr));
        lblRoadHighway->setText(QCoreApplication::translate("HomePage", "Highway", nullptr));
        label_340->setText(QCoreApplication::translate("HomePage", "Cost:", nullptr));
        label_341->setText(QCoreApplication::translate("HomePage", "Wood:", nullptr));
        label_342->setText(QCoreApplication::translate("HomePage", "Steel:", nullptr));
        label_343->setText(QCoreApplication::translate("HomePage", "Concrete:", nullptr));
        label_344->setText(QCoreApplication::translate("HomePage", "Cash:", nullptr));
        tabBuildCity->setTabText(tabBuildCity->indexOf(tab_5), QCoreApplication::translate("HomePage", "Roads", nullptr));
    } // retranslateUi

};

namespace Ui {
    class HomePage: public Ui_HomePage {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_HOMEPAGE_H
