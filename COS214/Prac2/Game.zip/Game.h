#ifndef GAME_H
#define GAME_H

#include <iostream>
#include <vector>
#include <map>
#include <unordered_set>

#include "CareTaker.h"
#include "InfantryFactory.h"
#include "BoatmanFactory.h"
#include "ShieldBearerFactory.h"

using namespace std;

class Game
{
  private:
    map<string, vector<Soldiers*>> playerSoldiers;
    CareTaker* careTaker;
    vector<Memento> saveState;
    map<string , int> currency;
    map<string, vector<int>> currencyHistory;
    const int playerAmount;
    const int currencyPerTurn;
    int activePlayer = 1;
    bool running = true;
    int turnNumber = 1;
    int maxTurnNumber = 1;
    const int infantryPrice = 50;
    const int shieldBearerPrice = 40;
    const int boatmanPrice = 75;
  private:
    void lowerCase(string& word);
    void Menu();
    void attack();
    void rest();
    void retreat();
    void buy();
    void list();
    void save();
    void undo();
    void redo();
    void load(int turn);
    void clear();
  public:
    Game(int player_amount , int currencyPerTurn);
    void run();
    ~Game();
};

#endif