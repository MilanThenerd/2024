#include "Game.h"

Game::Game(int playerAmount , int currencyPerTurn) : playerAmount(playerAmount) , currencyPerTurn(currencyPerTurn)
{
  for(int i = 1 ; i <= playerAmount ; i++)
  {
    string playerName = "Player " + to_string(i);
    currency[playerName] = 50;
    currencyHistory[playerName].push_back(50);
  }
  careTaker = new CareTaker();
}

void Game::run()
{
  activePlayer = 1;
  cout << "Turn " << turnNumber << endl;
  while(running)
  {
    string playerName = "Player " + to_string(activePlayer);
    currencyHistory[playerName].push_back(currency[playerName]);
    if (currencyHistory[playerName].size() > turnNumber+1)
    {
      currencyHistory[playerName].resize(turnNumber);
    }
    Menu();
    activePlayer++;
    if(activePlayer > playerAmount)
    {
      save();
      activePlayer = 1;
      turnNumber++;
      maxTurnNumber = turnNumber;
      for(int i = 1 ; i <= playerAmount ; i++)
      {
        string playerName = "Player " + to_string(i);
        currency[playerName] += currencyPerTurn; 
      }
      cout << "Turn " << turnNumber << endl;
    }
  }
  cout << "Thanks for playing..." << endl;
}

void Game::Menu()
{
  string playerName = "Player " + to_string(activePlayer);
  while(true)
  {
    cout << playerName << " , you have $" << currency[playerName] << endl;
    cout << playerName << " , what action do you want (Attack,Buy,Retreat,Rest,List,Stop,Save,Undo,Redo): ";
    string response;
    cin >> response;
    lowerCase(response);

    if(response == "attack")
    {
      if(playerSoldiers[playerName].size() < 1)
      {
        cout << playerName << " , does not own any units, consider buying some..." << endl;
      }
      else
      {
        this->attack();
        break;
      }
    }
    else if (response == "buy")
    {
      this->buy();
      break;
    }
    else if(response == "retreat")
    {
      this->retreat();
      break;
    }
    else if(response == "rest")
    {
      this->rest();
      break;
    }
    else if(response == "list")
    {
      this->list();
    }
    else if(response == "save")
    {
      this->save();
      break;
    }
    else if(response == "undo" && turnNumber > 1)
    {
      this->undo();
      break;
    }
    else if(response == "redo" && turnNumber < maxTurnNumber)
    {
      this->redo();
      break;
    }
    else if(response == "stop" || response == "skip")
    {
      running = false;
      break;
    }
    else
    {
      cout << "You did not choose a valid option..." << endl;
    }
  } 
}


void Game::attack()
{
  while(true)
  {
    string playerName = "Player " + to_string(activePlayer);
    cout << playerName << " , which unit do you want to attack with? (";
    unordered_set<string> unitTypes;
    for (auto soldier : playerSoldiers[playerName]) 
    {
      unitTypes.insert(soldier->getUnitName());
    }
    bool first = true;
    for (const auto& unitType : unitTypes) 
    {
      if (!first) 
      {
        cout << ",";
      }
      cout << unitType;
      first = false;
    }
    cout << ") :";
    string response;
    cin >> response;
    lowerCase(response);
    unordered_set<string> lowerUnitTypes;
    for (const auto& unitType : unitTypes) 
    {
      string lowerUnitType = unitType;
      lowerCase(lowerUnitType);
      lowerUnitTypes.insert(lowerUnitType);
    }

    if (lowerUnitTypes.find(response) != lowerUnitTypes.end()) 
    {
      while(true)
      {
        cout << playerName << " , which player do you want to attack? ("; 
        unordered_set<int> playerNumbers;
        for(int i = 1 ; i <= playerAmount ; i++)
        {
          if(i != activePlayer)
          {
            playerNumbers.insert(i);
          }
        }
        bool first = true;
        for (const auto& playerNumber : playerNumbers) 
        {
          if (!first) 
          {
            std::cout << ",";
          }
          std::cout << playerNumber;
          first = false;
        }
        std::cout << ") : ";
        cin >> response;
        int chosenPlayer = stoi(response);
        if(chosenPlayer == activePlayer || chosenPlayer > playerAmount)
        {
          cout << "You need to choose a valid player..." << endl;
        }
        else
        {
          string name = "Player " + chosenPlayer;
          if(playerSoldiers[name].size() < 1)
          {
            cout << "Your opponent doesn't have troops to defend itself you win...Yay!" << endl;
            running = false;
          }
          else
          {
            // while(true)
            // {
            //   cout << playerName << " , which unit do you want to attack? (";
            // }
            cout << "work in progress" << endl;
          }
          break;
        }
      }
      break;
    } 
    else 
    {
      cout << response << " is not a valid unit type to attack with." << endl;
    }
  }
}

void Game::buy()
{
  string playerName = "Player " + to_string(activePlayer);
  while(true)
  {
    cout << playerName << " , what do you want to buy (Infantry $"<< infantryPrice <<",ShieldBearer $"<< shieldBearerPrice <<",Boatman $"<< boatmanPrice <<") or return (back): ";
    string response;
    cin >> response;
    lowerCase(response);

    if(response == "infantry")
    {
      if(currency[playerName] >= infantryPrice)
      {
        currency[playerName] -= infantryPrice;
        InfantryFactory* factory = new InfantryFactory();
        Soldiers* soldier = factory->createUnit();
        soldier->setPlayerID(playerName);
        playerSoldiers[playerName].push_back(soldier);
        delete factory;
        break;
      }
      else
      {
        cout << "You do not have enough money for this unit..." << endl;
      }
    }
    else if(response == "shieldbearer")
    {
      if(currency[playerName] >= shieldBearerPrice)
      {
        currency[playerName] -= shieldBearerPrice;
        ShieldBearerFactory* factory = new ShieldBearerFactory();
        Soldiers* soldier = factory->createUnit();
        soldier->setPlayerID(playerName);
        playerSoldiers[playerName].push_back(soldier);
        delete factory;
        break;
      }
      else
      {
        cout << "You do not have enough money for this unit..." << endl;
      }
    }
    else if(response == "boatman")
    {
      if(currency[playerName] >= boatmanPrice)
      {
        currency[playerName] -= boatmanPrice;
        BoatmanFactory* factory = new BoatmanFactory();
        Soldiers* soldier = factory->createUnit();
        soldier->setPlayerID(playerName);
        playerSoldiers[playerName].push_back(soldier);
        delete factory;
        break;
      }
      else
      {
        cout << "You do not have enough money for this unit..." << endl;
      }
    }
    else if(response == "back")
    {
      Menu();
      break;
    }
    else
    {
      cout << "You did not choose a valid option..." << endl;
    }
  }
}

void Game::retreat()
{
  cout << "Player " << activePlayer << " has decided to retreat" << endl;
}

void Game::rest()
{
  cout << "Player " << activePlayer << " has decided to rest" << endl;
}

void Game::list()
{
  string playerName = "Player " + to_string(activePlayer);
  int size = playerSoldiers[playerName].size();
  if(size < 1)
  {
    cout << playerName << " , does not own any units, consider buying some..." << endl;
  }
  else
  {
    cout << playerName << " , owns the following units: " << endl;
    for(int i = 0 ; i < size ; i++)
    {
      cout << playerSoldiers[playerName].at(i)->getUnitName() << " , " << playerSoldiers[playerName].at(i)->getHealthPerSoldier() << "HP"<< endl;
    }
  }
}

void Game::save()
{
  for(int i = 1 ; i <= playerAmount ; i++)
  {
    string playerName = "Player " + to_string(i);
    int size = playerSoldiers[playerName].size();
    for(int j = 0 ; j < size ; j++)
    {
      Memento soldier = *playerSoldiers[playerName].at(j)->militusMemento();
      saveState.push_back(soldier);
    }
  }
  careTaker->addGameState(saveState,turnNumber);
  saveState.clear();
}

void Game::load(int turn)
{
  vector<Memento> save = careTaker->getGameState(turn - 1);
  this->clear();
  for(int i = 1 ; i <= playerAmount ; i++)
  {
    string playerName = "Player " + to_string(i);
    currency[playerName] = currencyHistory[playerName].at(turn-1);
  }
  if (save.empty())
  {
    return;
  }
  for(int j = 0 ; j < (int)save.size() ; j++)
  {
    Soldiers* soldier = new Infantry(0, 0, 0, 0, "DefaultName");
    soldier->vivificaMemento(&save.at(j));
    playerSoldiers[soldier->getPlayerID()].push_back(soldier);
  }
}

void Game::undo()
{
  if(turnNumber > 1)
  {
    load(--turnNumber);
    activePlayer = 0;
    cout << "Turn " << turnNumber << endl;
  }
}

void Game::redo()
{
  if(turnNumber < maxTurnNumber)
  {
    load(++turnNumber);
    activePlayer = 0;
    cout << "Turn " << turnNumber << endl;
    if(turnNumber == maxTurnNumber)
    {
      for(int i = 1 ; i <= playerAmount ; i++)
      {
        string playerName = "Player " + to_string(i);
        currency[playerName] += currencyPerTurn; 
      }
    }
  }
}

void Game::clear()
{
  for(int i = 1; i <= playerAmount; i++)
  {
    string playerName = "Player " + to_string(i);
    if(playerSoldiers.find(playerName) != playerSoldiers.end())
    {
      for(Soldiers* soldier : playerSoldiers[playerName])
      {
        delete soldier;
      }
      playerSoldiers[playerName].clear();
    }
  }
}

void Game::lowerCase(string& word)
{
  for(auto& x : word)
  {
    x = tolower(x);
  }
}

Game::~Game()
{
  clear();
}