#include <iostream>

#include "Game.h"
using namespace std;

int main()
{
  Game* game = new Game(2,50);
  game->run();
  delete game;
  return 0;
}