#include "BattleStrategy.h"

BattleStrategy::BattleStrategy(int player)
{
    this->player = player;
}