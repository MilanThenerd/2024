#include "LegionFactory.h"

LegionFactory::LegionFactory(int playerNo)
{
    player = playerNo;
}