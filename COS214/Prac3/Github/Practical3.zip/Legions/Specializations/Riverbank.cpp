#include "Riverbank.h"

Riverbank::Riverbank(const LegionUnit &unit) : LegionUnit(unit)
{
    specilization = "Riverbank";
}