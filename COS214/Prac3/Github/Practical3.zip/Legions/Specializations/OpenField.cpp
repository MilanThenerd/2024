#include "OpenField.h"

OpenField::OpenField(const LegionUnit &unit) : LegionUnit(unit)
{
    specilization = "OpenField";
}