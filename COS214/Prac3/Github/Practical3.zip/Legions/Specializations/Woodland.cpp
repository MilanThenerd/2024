#include "Woodland.h"

Woodland::Woodland(const LegionUnit &unit) : LegionUnit(unit)
{
    specilization = "Woodland";
}
