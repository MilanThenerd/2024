#ifndef SMARTTHERMOSTATINTEGRATOR_H
#define SMARTTHERMOSTATINTEGRATOR_H

#include "SmartThermostat.h"
#include "LegacyThermostat.h"
#include "cmath"

class SmartThermostatIntegrator : public SmartThermostat
{
private:
  LegacyThermostat *thermostat;

public:
  SmartThermostatIntegrator(LegacyThermostat *thermostat);
  void initialize();
  double getTemperature();
  void setTemperature(double temp);
  std::string printState();
};
#endif