#ifndef LIGHT_H
#define LIGHT_H

#include "Device.h"

class Light : public Device
{
public:
    Light();
    void performAction(std::string action);
    std::string printState();
};
#endif