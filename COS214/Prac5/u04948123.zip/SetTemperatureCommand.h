#ifndef SETTEMPERATURECOMMAND_H
#define SETTEMPERATURECOMMAND_H

#include "HomeCommand.h"

class SetTemperatureCommand : public HomeCommand
{
private:
  int temperature;

public:
  SetTemperatureCommand(Device *receiver, double temperature, std::string target = "");
  void execute();
};
#endif