#ifndef OPENSTATE_H
#define OPENSTATE_H

#include "DeviceState.h"

class OpenState : public DeviceState
{
public:
  OpenState()
  {
    this->type = "Lock";
    this->description = "Unlocked";
  };
};
#endif