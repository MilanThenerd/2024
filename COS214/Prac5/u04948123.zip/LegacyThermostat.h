#ifndef LEGACYTHERMOSTAT_H
#define LEGACYTHERMOSTAT_H

class  LegacyThermostat
{
  private:
    double temperature;
  public:
    LegacyThermostat(double temp);
    double getTemperature();
    void increaseTemperature();
    void decreaseTemperature();
};
#endif