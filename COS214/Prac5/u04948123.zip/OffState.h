#ifndef OFFSTATE_H
#define OFFSTATE_H

#include "DeviceState.h"

class OffState : public DeviceState
{
public:
  OffState()
  {
    this->type = "Power";
    this->description = "Off";
  };
};
#endif