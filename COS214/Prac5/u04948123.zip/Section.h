#ifndef SECTION_H
#define SECTION_H

#include <vector>

#include "Room.h"
#include "Device.h"

class Section : public Device
{
private:
  std::vector<Room *> rooms;
  std::string sectionName;

public:
  Section(std::string name = "");
  void addRoom(Room *room);
  void removeRoom(Room *room);
  void performAction(std::string action);
  std::string printState();
};
#endif