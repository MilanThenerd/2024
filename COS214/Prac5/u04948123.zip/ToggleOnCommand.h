#ifndef TOGGLEONCOMMAND_H
#define TOGGLEONCOMMAND_H

#include "HomeCommand.h"
#include "OnCommand.h"
#include "OffCommand.h"

class ToggleOnCommand : public HomeCommand
{
private:
  bool isOn = false;
  OnCommand *onCommand;
  OffCommand *offCommand;

public:
  ToggleOnCommand(Device *receiver, bool isOn, std::string target = "");
  ~ToggleOnCommand();
  void execute();
};
#endif