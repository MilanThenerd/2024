#ifndef ONSTATE_H
#define ONSTATE_H

#include "DeviceState.h"

class OnState : public DeviceState
{
public:
  OnState()
  {
    this->type = "Power";
    this->description = "On";
  };
};
#endif