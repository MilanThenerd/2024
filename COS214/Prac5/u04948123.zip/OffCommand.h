#ifndef OFFCOMMAND_H
#define OFFCOMMAND_H

#include "HomeCommand.h"

class OffCommand : public HomeCommand
{
public:
  OffCommand(Device *receiver, std::string target = "");
  void execute();
};
#endif