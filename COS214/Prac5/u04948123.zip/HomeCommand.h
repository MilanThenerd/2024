#ifndef HOMECOMMAND_H
#define HOMECOMMAND_H

#include "Device.h"

class HomeCommand
{

protected:
  Device *receiver;
  std::string target;

public:
  HomeCommand(Device *receiver, std::string target);
  virtual void execute() = 0;
  virtual ~HomeCommand();
};
#endif