#ifndef TEMPERATURESENSOR_H
#define TEMPERATURESENSOR_H

#include "Sensor.h"

class TemperatureSensor : public Sensor
{
private:
  double temperature;

public:
  TemperatureSensor();
  void setTemperature(double t);
  double getTemperature();
  void performAction(std::string action);
  std::string printState();
  void trigger();
};
#endif