#ifndef DEVICESTATE_H
#define DEVICESTATE_H

#include <string>

class DeviceState
{
protected:
  std::string type;
  std::string description;

public:
  std::string getDescription();
  std::string getType();
};
#endif