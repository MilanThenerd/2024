#ifndef SENSOR_H
#define SENSOR_H

#include "Device.h"
#include "NotifyCommand.h"
#include <vector>
#include <bits/stdc++.h>

class Sensor : public Device
{
protected:
  std::vector<NotifyCommand *> devices;

public:
  virtual void performAction(std::string action) = 0;
  virtual void trigger() = 0;
  void addDevice(NotifyCommand *com);
  void removeDevice(NotifyCommand *com);
};
#endif