#ifndef LOCKEDSTATE_H
#define LOCKEDSTATE_H

#include "DeviceState.h"

class LockedState : public DeviceState
{
public:
  LockedState()
  {
    this->type = "Lock";
    this->description = "Locked";
  };
};
#endif