#ifndef LOCKCOMMAND_H
#define LOCKCOMMAND_H

#include "HomeCommand.h"

class LockCommand : public HomeCommand
{
public:
  LockCommand(Device *receiver, std::string target = "");
  void execute();
};
#endif