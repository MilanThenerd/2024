#ifndef ONCOMMAND_H
#define ONCOMMAND_H

#include "HomeCommand.h"

class OnCommand : public HomeCommand
{
public:
  OnCommand(Device *receiver, std::string target = "");
  void execute();
};
#endif