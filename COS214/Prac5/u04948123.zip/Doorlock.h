#ifndef DOORLOCK_H
#define DOORLOCK_H

#include "Device.h"

class Doorlock : public Device
{
public:
    Doorlock();
    void performAction(std::string action);
    std::string printState();
};
#endif