#ifndef MACROROUTINE_H
#define MACROROUTINE_H

#include <string>
#include <vector>
#include <bits/stdc++.h>

#include "HomeCommand.h"

class MacroRoutine : public HomeCommand
{
private:
  std::string macroName;
  std::vector<HomeCommand *> commands;

public:
  MacroRoutine(Device *receiver, std::string name, std::string target = "");
  void execute();
  void addCommand(HomeCommand *command);
  void removeCommand(HomeCommand *command);
  std::string getName();
};
#endif