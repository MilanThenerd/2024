#ifndef NOTIFYCOMMAND_h
#define NOTIFYCOMMAND_h

#include "HomeCommand.h"
class NotifyCommand : public HomeCommand
{
private:
    std::string filter;
    HomeCommand *command;

public:
    NotifyCommand(Device *receiver, HomeCommand *command, std::string filter = "", std::string target = "");
    void execute();
    void filterExecute(std::string value = "");
};
#endif