#ifndef SMARTTHERMOSTAT_H
#define SMARTTHERMOSTAT_H

#include "Device.h"

class SmartThermostat : public Device
{
private:
    double temperature;

public:
    SmartThermostat(double temp);
    virtual void performAction(std::string action);
    virtual double getTemperature();
    virtual void setTemperature(double temp);
    virtual std::string printState();
};
#endif