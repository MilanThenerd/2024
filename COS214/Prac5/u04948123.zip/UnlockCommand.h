#ifndef UNLOCKCOMMAND_H
#define UNLOCKCOMMAND_H

#include "HomeCommand.h"

class UnlockCommand : public HomeCommand
{
public:
  UnlockCommand(Device *receiver, std::string target = "");
  void execute();
};
#endif