#ifndef SMARTHOMESYSTEM_H
#define SMARTHOMESYSTEM_H

#include "includes.h"
#include <map>
#include <vector>

class SmartHomeSystem
{
  private:
    std::vector<Device*> devices;
    std::map<std::string,Room> rooms;
    std::map<std::string,Section> sections;
    std::map<std::string,MacroRoutine> routines;
    void clearTerminal();
  public:
    SmartHomeSystem();
    void run();
    void addSection(std::string name);
    void removeSection(std::string name);
    void addRoom(std::string roomName , std::string sectionName);
    void removeRoom(std::string roomName , std::string sectionName);
    void addDevice(int type , std::string roomName);
    void removeDevice(std::string deviceID);
};
#endif