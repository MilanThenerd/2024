#ifndef DEVICE_H
#define DEVICE_H

#include "DeviceState.h"
#include "OnState.h"
#include "OffState.h"
#include "LockedState.h"
#include "OpenState.h"
#include <sstream>
#include <iostream>

class Device
{
protected:
  DeviceState state;
  std::string type;
  std::string id;
  void generateId();

public:
  std::string getId();
  std::string getStatus();
  virtual void performAction(std::string action) = 0;
  std::string getDeviceType();
  virtual void notify(); // TODO: check if we need to make this pure virtual
  void setState(DeviceState s);
  virtual std::string printState() = 0;
};
#endif