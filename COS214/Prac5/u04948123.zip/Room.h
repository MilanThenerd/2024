#ifndef ROOM_H
#define ROOM_H

#include <vector>
#include <bits/stdc++.h>
#include "Device.h"

class Room : public Device
{
private:
  std::vector<Device *> devices;
  std::string roomName;

public:
  Room(std::string name = "");
  void addDevice(Device *device);
  void removeDevice(Device *device);
  void performAction(std::string action);
  std::string printState();
};
#endif