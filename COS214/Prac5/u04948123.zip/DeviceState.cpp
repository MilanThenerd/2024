#include "DeviceState.h"

std::string DeviceState::getDescription()
{
  return this->description;
}

std::string DeviceState::getType()
{
  return this->type;
}