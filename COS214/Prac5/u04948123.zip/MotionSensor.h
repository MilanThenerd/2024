#ifndef MOTIONSENSOR_H
#define MOTIONSENSOR_H

#include "Sensor.h"

class MotionSensor : public Sensor
{
public:
    MotionSensor();
    void performAction(std::string action);
    std::string printState();
    void trigger();
};
#endif